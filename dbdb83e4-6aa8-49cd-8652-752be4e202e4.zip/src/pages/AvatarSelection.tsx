import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckIcon, ShieldCheckIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { AvatarFigure } from '../components/AvatarFigure';
import { Button } from '../components/ui/Button';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { AVATARS, getAvatar } from '../data/avatars';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';

export function AvatarSelection() {
  const navigate = useNavigate();
  const { profile, update } = useUser();
  const { t } = useT();
  const [avatarId, setAvatarId] = useState<string | null>(profile.avatar);

  const preview = getAvatar(avatarId);

  return (
    <Screen
      header={
      <ScreenHeader
        title={t('avatar.choose')}
        subtitle="2 / 3"
        onBack={() => navigate('/onboarding/language')} />

      }
      footer={
      <div className="space-y-3">
          <Button
          fullWidth
          disabled={!avatarId}
          onClick={() => {
            update({ gender: preview?.gender ?? null, avatar: avatarId });
            navigate(profile.assessmentComplete ? '/profile' : '/onboarding/path');
          }}>
          
            {t('common.continue')}
          </Button>
          <button
          type="button"
          onClick={() => {
            update({ gender: null, avatar: null });
            navigate('/onboarding/path');
          }}
          className="block min-h-[40px] w-full text-[13px] font-semibold text-navy-muted transition-colors duration-150 ease-out hover:text-brand-700">
          
            {t('avatar.skip')}
          </button>
        </div>
      }>
      
      {/* Preview */}
      <div className="flex flex-col items-center rounded-2xl bg-brand-50 py-6">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={preview?.id ?? 'none'}
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
            className="flex flex-col items-center">
            
            <AvatarFigure avatar={preview} size={132} ring />
            <p className="mt-3 text-[15px] font-bold text-navy">{preview?.name ?? 'Pick a character'}</p>
            <p className="text-[12px] text-brand-800/85">
              {preview?.stage ?? 'Your avatar appears across your dashboard and guidance'}
            </p>
          </motion.div>
        </AnimatePresence>
      </div>

      <h2 className="mb-3 mt-6 text-[14px] font-bold text-navy">{t('avatar.select')}</h2>

      <div className="grid grid-cols-2 gap-3" role="radiogroup" aria-label={t('avatar.select')}>
        {AVATARS.map((option) => {
          const selected = avatarId === option.id;
          return (
            <motion.button
              key={option.id}
              type="button"
              role="radio"
              aria-checked={selected}
              onClick={() => setAvatarId(option.id)}
              animate={{ scale: selected ? 1.02 : 1 }}
              whileTap={{ scale: 0.98 }}
              transition={{ duration: 0.16, ease: [0.23, 1, 0.32, 1] }}
              className={`relative flex min-h-[150px] flex-col items-center gap-2 rounded-2xl border bg-white p-3 transition-[border-color,box-shadow] duration-150 ease-out ${
              selected ?
              'border-brand-600 shadow-card ring-1 ring-brand-600' :
              'border-hairline hover:border-brand-300'}`
              }>
              
              {selected &&
              <span className="absolute right-2.5 top-2.5 flex h-5 w-5 items-center justify-center rounded-full bg-brand-600 text-white">
                  <CheckIcon size={13} strokeWidth={3} />
                </span>
              }
              <AvatarFigure avatar={option} size={82} />
              <span className={`text-[13px] font-semibold ${selected ? 'text-brand-800' : 'text-navy'}`}>
                {option.name}
              </span>
              <span className="text-center text-[11px] leading-tight text-navy-muted">{option.stage}</span>
            </motion.button>);

        })}
      </div>

      <p className="mt-5 flex items-start justify-center gap-2 text-center text-[11.5px] leading-relaxed text-navy-muted">
        <ShieldCheckIcon size={14} className="mt-0.5 shrink-0 text-brand-600" />
        Your avatar is a visual personalisation only — voice and conversation are future features.
      </p>
    </Screen>);

}