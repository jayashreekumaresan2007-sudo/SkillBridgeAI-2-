import React, { useState } from 'react';
import { BookmarkIcon, Building2Icon, GraduationCapIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { BookmarkButton } from '../components/ui/BookmarkButton';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { CAREERS } from '../data/careers';
import { CHECKLIST_TOTAL } from '../data/enrollmentChecklist';
import { INSTITUTIONS } from '../data/institutions';
import { ACADEMIES } from '../data/academies';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';

type Tab = 'careers' | 'institutions' | 'academies';

const TABS: {id: Tab;key: string;}[] = [
{ id: 'careers', key: 'nav.careers' },
{ id: 'institutions', key: 'inst.title' },
{ id: 'academies', key: 'acad.title' }];


export function Saved() {
  const navigate = useNavigate();
  const { profile, toggleSaved, enrollmentChecks } = useUser();
  const { t } = useT();
  const [tab, setTab] = useState<Tab>('careers');

  const checkLabel = (providerKey: string) => {
    const done = enrollmentChecks(providerKey).length;
    if (done === 0) return 'Clarity check not started';
    if (done === CHECKLIST_TOTAL) return 'Clarity check complete';
    return `Clarity check ${done}/${CHECKLIST_TOTAL}`;
  };

  const careers = profile.savedCareers.map((id) => CAREERS[id as keyof typeof CAREERS]).filter(Boolean);
  const institutions = INSTITUTIONS.filter((i) => profile.savedInstitutions.includes(i.id));
  const academies = ACADEMIES.filter((a) => profile.savedAcademies.includes(a.id));

  return (
    <Screen header={<ScreenHeader showBack={false} title={t('saved.title')} subtitle="Everything you bookmarked" />}>
      <div className="flex gap-2" role="tablist" aria-label="Saved categories">
        {TABS.map((option) =>
        <button
          key={option.id}
          type="button"
          role="tab"
          aria-selected={tab === option.id}
          onClick={() => setTab(option.id)}
          className={`min-h-[42px] flex-1 truncate rounded-full border px-2 text-[13px] font-semibold transition-colors duration-150 ease-out ${
          tab === option.id ?
          'border-brand-600 bg-brand-600 text-white' :
          'border-hairline bg-white text-navy-muted hover:border-brand-300'}`
          }>
          
            {t(option.key)}
          </button>
        )}
      </div>

      <div className="mt-4 space-y-3">
        {tab === 'careers' && (
        careers.length === 0 ?
        <EmptyState
          title="No saved careers"
          message="Bookmark a career while exploring and it will appear here."
          icon={<BookmarkIcon size={22} />}
          action={<Button onClick={() => navigate('/careers')}>Explore careers</Button>} /> :


        careers.map((career) =>
        <article key={career.id} className="flex items-center gap-3 rounded-2xl border border-hairline bg-white p-4">
                <button type="button" onClick={() => navigate(`/careers/${career.id}`)} className="min-w-0 flex-1 text-left">
                  <p className="truncate text-[14.5px] font-bold text-navy">{career.title}</p>
                  <p className="mt-0.5 truncate text-[12.5px] text-navy-muted">{career.tagline}</p>
                </button>
                <BookmarkButton compact saved onToggle={() => toggleSaved('savedCareers', career.id)} label={career.title} />
              </article>
        ))
        }

        {tab === 'institutions' && (
        institutions.length === 0 ?
        <EmptyState
          title="No saved institutions"
          message="Save institutions you want to look into later."
          icon={<Building2Icon size={22} />}
          action={<Button onClick={() => navigate('/institutions')}>Browse institutions</Button>} /> :


        institutions.map((institution) =>
        <article key={institution.id} className="flex items-center gap-3 rounded-2xl border border-hairline bg-white p-4">
                <button
            type="button"
            onClick={() => navigate(`/providers/institution/${institution.id}`)}
            className="min-w-0 flex-1 text-left">
            
                  <p className="truncate text-[14.5px] font-bold text-navy">{institution.name}</p>
                  <p className="mt-0.5 truncate text-[12.5px] text-navy-muted">
                    {institution.location} · {checkLabel(`institution:${institution.id}`)}
                  </p>
                </button>
                <BookmarkButton
            compact
            saved
            onToggle={() => toggleSaved('savedInstitutions', institution.id)}
            label={institution.name} />
          
              </article>
        ))
        }

        {tab === 'academies' && (
        academies.length === 0 ?
        <EmptyState
          title="No saved academies"
          message="Save courses that match the skills you need."
          icon={<GraduationCapIcon size={22} />}
          action={<Button onClick={() => navigate('/academies')}>Browse academies</Button>} /> :


        academies.map((academy) =>
        <article key={academy.id} className="flex items-center gap-3 rounded-2xl border border-hairline bg-white p-4">
                <button
            type="button"
            onClick={() => navigate(`/providers/academy/${academy.id}`)}
            className="min-w-0 flex-1 text-left">
            
                  <p className="truncate text-[14.5px] font-bold text-navy">{academy.course}</p>
                  <p className="mt-0.5 truncate text-[12.5px] text-navy-muted">
                    {academy.name} · {checkLabel(`academy:${academy.id}`)}
                  </p>
                </button>
                <BookmarkButton
            compact
            saved
            onToggle={() => toggleSaved('savedAcademies', academy.id)}
            label={academy.course} />
          
              </article>
        ))
        }
      </div>
    </Screen>);

}