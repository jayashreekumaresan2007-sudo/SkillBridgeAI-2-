import React, { useMemo, useState } from 'react';
import { ShieldCheckIcon, TriangleAlertIcon } from 'lucide-react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { listProviders } from '../utils/providers';
import { useUser } from '../contexts/UserContext';
import type { ProviderKind, ProviderView } from '../types';

const selectClass =
'min-h-[44px] w-full rounded-xl border border-hairline bg-white px-3 text-[12.5px] font-semibold text-navy focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-200';

export function ProviderCompare() {
  const navigate = useNavigate();
  const { kind } = useParams();
  const [params] = useSearchParams();
  const providerKind = (kind === 'academy' ? 'academy' : 'institution') as ProviderKind;
  const { skillGap } = useUser();

  const options = useMemo(() => listProviders(providerKind), [providerKind]);
  const initialLeft = params.get('from') ?? options[0]?.id ?? '';
  const [leftId, setLeftId] = useState(initialLeft);
  const [rightId, setRightId] = useState(options.find((o) => o.id !== initialLeft)?.id ?? '');

  const neededSkills = skillGap.filter((s) => s.level !== 'Strong').map((s) => s.name);
  const left = options.find((o) => o.id === leftId) ?? null;
  const right = options.find((o) => o.id === rightId) ?? null;

  if (options.length < 2 || !left || !right) {
    return (
      <Screen header={<ScreenHeader title="Compare options" onBack={() => navigate(-1)} />}>
        <EmptyState
          title="Not enough options to compare"
          message="Widen your filters to bring more providers into the list, then try again." />
        
      </Screen>);

  }

  const relevance = (provider: ProviderView) =>
  neededSkills.length === 0 ?
  '—' :
  `${provider.skills.filter((s) => neededSkills.includes(s)).length} of your ${neededSkills.length} gap skills`;

  const rows: {label: string;render: (p: ProviderView) => React.ReactNode;}[] = [
  { label: 'Course relevance', render: relevance },
  { label: 'Skills covered', render: (p) => p.skills.join(', ') },
  { label: 'Duration', render: (p) => p.duration ?? 'Not listed' },
  {
    label: 'Fee',
    render: () =>
    <span className="flex items-start gap-1.5 text-warn">
          <TriangleAlertIcon size={13} className="mt-0.5 shrink-0" />
          Not verified
        </span>

  },
  {
    label: 'Location',
    render: (p) => p.distanceKm !== null ? `${p.location} · ${p.distanceKm} km` : p.location
  },
  { label: 'Learning mode', render: (p) => p.mode },
  { label: 'Level', render: (p) => p.level ?? '—' },
  {
    label: 'Available evidence',
    render: (p) => `Listing, skills, mode and location (sample data). Rating ${p.rating} unconfirmed.`
  },
  {
    label: 'Verification status',
    render: () =>
    <span className="flex items-start gap-1.5 text-warn">
          <TriangleAlertIcon size={13} className="mt-0.5 shrink-0" />
          Confirm with provider
        </span>

  }];


  return (
    <Screen
      header={
      <ScreenHeader
        title="Compare options"
        subtitle="Same information, side by side"
        onBack={() => navigate(-1)} />

      }
      footer={
      <Button
        fullWidth
        onClick={() => navigate(`/providers/${providerKind}/${leftId}`)}
        icon={<ShieldCheckIcon size={17} />}>
        
          Run clarity check on {left.name}
        </Button>
      }>
      
      <div className="grid grid-cols-2 gap-2.5">
        <label className="text-[11.5px] font-semibold text-navy-muted">
          Option A
          <select value={leftId} onChange={(e) => setLeftId(e.target.value)} className={`mt-1 ${selectClass}`}>
            {options.map((option) =>
            <option key={option.id} value={option.id}>
                {option.headline}
              </option>
            )}
          </select>
        </label>
        <label className="text-[11.5px] font-semibold text-navy-muted">
          Option B
          <select value={rightId} onChange={(e) => setRightId(e.target.value)} className={`mt-1 ${selectClass}`}>
            {options.map((option) =>
            <option key={option.id} value={option.id}>
                {option.headline}
              </option>
            )}
          </select>
        </label>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2.5">
        {[left, right].map((provider, index) =>
        <div key={provider.id} className="rounded-xl bg-brand-50 p-3">
            <p className="text-[10.5px] font-bold uppercase tracking-wide text-brand-700">
              {index === 0 ? 'A' : 'B'}
            </p>
            <p className="mt-1 text-[13px] font-bold leading-snug text-navy">{provider.headline}</p>
            <p className="mt-0.5 text-[11.5px] text-navy-muted">{provider.name}</p>
          </div>
        )}
      </div>

      <dl className="mt-5 space-y-3.5">
        {rows.map((row) =>
        <div key={row.label} className="rounded-xl border border-hairline bg-white p-3.5">
            <dt className="text-[11.5px] font-semibold uppercase tracking-wide text-navy-muted">{row.label}</dt>
            <dd className="mt-2 grid grid-cols-2 gap-3">
              <span className="text-[12.5px] leading-relaxed text-navy">{row.render(left)}</span>
              <span className="border-l border-hairline pl-3 text-[12.5px] leading-relaxed text-navy">
                {row.render(right)}
              </span>
            </dd>
          </div>
        )}
      </dl>

      <p className="mt-4 text-[11.5px] leading-relaxed text-navy-muted">
        Fees, accreditation and availability are not held by SkillBridgeAI for these sample listings. Confirm
        them with each provider before comparing on cost.
      </p>
    </Screen>);

}