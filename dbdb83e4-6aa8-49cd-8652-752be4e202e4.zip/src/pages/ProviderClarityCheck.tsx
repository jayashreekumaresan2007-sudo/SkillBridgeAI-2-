import React, { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  BookmarkIcon,
  CheckIcon,
  ChevronDownIcon,
  ClockIcon,
  ExternalLinkIcon,
  GitCompareIcon,
  InfoIcon,
  MapPinIcon,
  ShieldCheckIcon,
  TriangleAlertIcon } from
'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { CHECKLIST_GROUPS, CHECKLIST_ITEMS, CHECKLIST_TOTAL, TRUST_MESSAGE } from '../data/enrollmentChecklist';
import { CAREERS } from '../data/careers';
import { buildEvidence, buildFit, getProvider } from '../utils/providers';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';
import type { ProviderKind } from '../types';

export function ProviderClarityCheck() {
  const navigate = useNavigate();
  const { kind, providerId } = useParams();
  const providerKind = (kind === 'academy' ? 'academy' : 'institution') as ProviderKind;
  const {
    profile,
    skillGap,
    toggleSaved,
    isSaved,
    enrollmentChecks,
    toggleEnrollmentCheck,
    markProviderVerified
  } = useUser();
  const { t } = useT();

  const provider = getProvider(providerKind, providerId ?? '');
  const [openGroup, setOpenGroup] = useState<string | null>(CHECKLIST_GROUPS[0].id);
  const [showEvidence, setShowEvidence] = useState(false);
  const [decided, setDecided] = useState(false);

  const providerKey = `${providerKind}:${providerId}`;
  const checked = enrollmentChecks(providerKey);

  const neededSkills = useMemo(
    () => skillGap.filter((s) => s.level !== 'Strong').map((s) => s.name),
    [skillGap]
  );

  if (!provider) {
    return (
      <Screen header={<ScreenHeader title={t('enroll.title')} onBack={() => navigate(-1)} />}>
        <EmptyState
          title="Provider not found"
          message="This listing is no longer available. Go back and pick another option." />
        
      </Screen>);

  }

  const evidence = buildEvidence(provider);
  const goalCareerId = profile.selectedCareer ?? profile.recommendations[0]?.careerId ?? null;
  const goalLabel = profile.focusSkill ?? (goalCareerId ? CAREERS[goalCareerId].title : null);
  const fit = buildFit(provider, neededSkills, goalLabel, goalCareerId);

  const complete = checked.length === CHECKLIST_TOTAL;
  const saved = isSaved(provider.saveKind, provider.id);
  const listed = evidence.items.filter((i) => i.status === 'listed');
  const toConfirm = evidence.items.filter((i) => i.status === 'unverified');

  const facts = [
  provider.duration ? { icon: <ClockIcon size={13} />, text: provider.duration } : null,
  { icon: <MapPinIcon size={13} />, text: `${provider.mode} · ${provider.location}` },
  provider.distanceKm !== null ? { icon: <MapPinIcon size={13} />, text: `${provider.distanceKm} km away` } : null].
  filter(Boolean) as {icon: React.ReactNode;text: string;}[];

  return (
    <Screen
      header={
      <ScreenHeader
        title={t('enroll.title')}
        subtitle={t('enroll.subtitle')}
        onBack={() => navigate(-1)} />

      }
      footer={
      <div className="flex gap-2.5">
          <Button
          variant="outline"
          className="flex-1"
          onClick={() => navigate(`/providers/${providerKind}/compare?from=${provider.id}`)}
          icon={<GitCompareIcon size={16} />}>
          
            Compare
          </Button>
          <Button
          variant={saved ? 'secondary' : 'outline'}
          className="flex-1"
          onClick={() => toggleSaved(provider.saveKind, provider.id)}
          icon={<BookmarkIcon size={16} fill={saved ? 'currentColor' : 'none'} />}>
          
            {saved ? 'Saved' : t('enroll.saveLater')}
          </Button>
        </div>
      }>
      
      <section className="rounded-2xl border border-hairline bg-white p-4 shadow-card">
        <p className="text-[12px] font-semibold uppercase tracking-wide text-brand-700">{provider.name}</p>
        <h2 className="mt-1 text-[16.5px] font-bold leading-snug text-navy">{provider.headline}</h2>
        <div className="mt-2.5 flex flex-wrap items-center gap-x-3.5 gap-y-1.5 text-[12px] text-navy-muted">
          {facts.map((fact) =>
          <span key={fact.text} className="flex items-center gap-1">
              {fact.icon}
              {fact.text}
            </span>
          )}
          {provider.level &&
          <span className="rounded-md bg-canvas px-2 py-0.5 text-[11.5px] font-semibold text-navy-soft">
              {provider.level}
            </span>
          }
        </div>
      </section>

      {/* Personalised fit — never a verdict, only what lines up and what does not. */}
      <section className="mt-4 rounded-2xl border border-hairline bg-white p-4">
        <h2 className="text-[15px] font-bold text-navy">{t('enroll.fit')}</h2>
        {goalLabel ?
        <p className="mt-1.5 text-[12.5px] leading-relaxed text-navy-muted">
            Your current goal is <span className="font-semibold text-navy">{goalLabel}</span>
            {fit.careerAligned ? ', and this provider lists programs in that direction.' : '.'}
          </p> :

        <p className="mt-1.5 text-[12.5px] leading-relaxed text-navy-muted">
            Complete your assessment to see how this compares against your own skill gap.
          </p>
        }

        {fit.matched.length > 0 &&
        <div className="mt-3.5">
            <h3 className="flex items-center gap-1.5 text-[12px] font-semibold uppercase tracking-wide text-good">
              <CheckIcon size={14} />
              Why this may fit you
            </h3>
            <p className="mt-1.5 text-[12.5px] leading-relaxed text-navy-soft">
              It covers {fit.matched.length} skill{fit.matched.length === 1 ? '' : 's'} currently on your
              roadmap: {fit.matched.join(', ')}.
            </p>
          </div>
        }

        {fit.notCovered.length > 0 &&
        <div className="mt-3.5">
            <h3 className="flex items-center gap-1.5 text-[12px] font-semibold uppercase tracking-wide text-warn">
              <TriangleAlertIcon size={14} />
              Things to consider
            </h3>
            <p className="mt-1.5 text-[12.5px] leading-relaxed text-navy-soft">
              It may not cover {fit.notCovered.slice(0, 3).join(', ')} — skills your roadmap currently
              identifies. Ask the provider whether the syllabus includes them.
            </p>
          </div>
        }

        {fit.extra.length > 0 &&
        <p className="mt-3.5 text-[12.5px] leading-relaxed text-navy-muted">
            <span className="font-semibold text-navy">Also teaches: </span>
            {fit.extra.join(', ')}
          </p>
        }
      </section>

      {/* Checklist */}
      <section className="mt-6">
        <div className="flex items-baseline justify-between gap-3">
          <h2 className="text-[16px] font-bold text-navy">{t('enroll.checklist')}</h2>
          <span className="shrink-0 text-[12px] font-semibold text-navy-muted">
            {checked.length} / {CHECKLIST_TOTAL} checked
          </span>
        </div>

        <div className="mt-3 space-y-2.5">
          {CHECKLIST_GROUPS.map((group) => {
            const open = openGroup === group.id;
            const groupDone = group.items.filter((item) => checked.includes(item.id)).length;
            return (
              <div key={group.id} className="overflow-hidden rounded-2xl border border-hairline bg-white">
                <button
                  type="button"
                  aria-expanded={open}
                  onClick={() => setOpenGroup(open ? null : group.id)}
                  className="flex min-h-[60px] w-full items-center gap-3 px-4 text-left">
                  
                  <span
                    className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[11.5px] font-bold ${
                    groupDone === group.items.length ?
                    'bg-goodSoft text-good' :
                    'bg-canvas text-navy-muted'}`
                    }>
                    
                    {groupDone === group.items.length ? <CheckIcon size={15} /> : `${groupDone}/${group.items.length}`}
                  </span>
                  <span className="min-w-0 flex-1 py-2.5">
                    <span className="block text-[14px] font-semibold text-navy">{group.title}</span>
                    <span className="block text-[12px] leading-relaxed text-navy-muted">{group.summary}</span>
                  </span>
                  <ChevronDownIcon
                    size={17}
                    className={`shrink-0 text-navy-muted transition-transform duration-200 ease-out ${
                    open ? 'rotate-180' : ''}`
                    } />
                  
                </button>

                <AnimatePresence initial={false}>
                  {open &&
                  <motion.ul
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
                    className="overflow-hidden border-t border-hairline">
                    
                      {group.items.map((item) => {
                      const isChecked = checked.includes(item.id);
                      return (
                        <li key={item.id} className="border-b border-hairline last:border-b-0">
                            <label className="flex min-h-[56px] cursor-pointer items-start gap-3 px-4 py-3">
                              <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={() => toggleEnrollmentCheck(providerKey, item.id)}
                              className="mt-0.5 h-5 w-5 shrink-0 cursor-pointer rounded border-hairline text-brand-600 focus:ring-2 focus:ring-brand-200" />
                            
                              <span className="min-w-0">
                                <span
                                className={`block text-[13.5px] font-medium leading-snug ${
                                isChecked ? 'text-navy-muted line-through' : 'text-navy'}`
                                }>
                                
                                  {item.label}
                                </span>
                                <span className="mt-0.5 block text-[12px] leading-relaxed text-navy-muted">
                                  {item.hint}
                                </span>
                              </span>
                            </label>
                          </li>);

                    })}
                    </motion.ul>
                  }
                </AnimatePresence>
              </div>);

          })}
        </div>
      </section>

      {/* Evidence */}
      <section className="mt-6 rounded-2xl border border-hairline bg-white">
        <button
          type="button"
          aria-expanded={showEvidence}
          onClick={() => setShowEvidence((v) => !v)}
          className="flex min-h-[60px] w-full items-center gap-3 px-4 text-left">
          
          <span className="min-w-0 flex-1 py-2.5">
            <span className="block text-[14px] font-semibold text-navy">{t('enroll.evidence')}</span>
            <span className="block text-[12px] text-navy-muted">
              {listed.length} listed · {toConfirm.length} to confirm
            </span>
          </span>
          <ChevronDownIcon
            size={17}
            className={`shrink-0 text-navy-muted transition-transform duration-200 ease-out ${
            showEvidence ? 'rotate-180' : ''}`
            } />
          
        </button>

        {showEvidence &&
        <div className="space-y-4 border-t border-hairline p-4">
            <div>
              <h3 className="flex items-center gap-1.5 text-[12px] font-semibold uppercase tracking-wide text-good">
                <ShieldCheckIcon size={14} />
                Information shown here
              </h3>
              <ul className="mt-2 space-y-2.5">
                {listed.map((item) =>
              <li key={item.label}>
                    <p className="text-[13px] font-semibold text-navy">{item.label}</p>
                    <p className="text-[12.5px] leading-relaxed text-navy-soft">{item.value}</p>
                    <p className="mt-0.5 text-[11.5px] text-navy-muted">Source: {item.source}</p>
                  </li>
              )}
              </ul>
            </div>

            <div className="border-t border-hairline pt-3.5">
              <h3 className="flex items-center gap-1.5 text-[12px] font-semibold uppercase tracking-wide text-warn">
                <TriangleAlertIcon size={14} />
                Not verified — confirm with the provider
              </h3>
              <ul className="mt-2 space-y-2.5">
                {toConfirm.map((item) =>
              <li key={item.label}>
                    <p className="text-[13px] font-semibold text-navy">{item.label}</p>
                    <p className="text-[12.5px] leading-relaxed text-navy-soft">{item.value}</p>
                    <p className="mt-0.5 text-[11.5px] text-navy-muted">{item.source}</p>
                  </li>
              )}
              </ul>
            </div>

            <div className="border-t border-hairline pt-3.5">
              <p className="text-[12.5px] leading-relaxed text-navy-muted">
                <span className="font-semibold text-navy">Official website: </span>
                {evidence.website ?? 'Not on file. Search for the provider’s own site and confirm there.'}
              </p>
              <p className="mt-1 text-[12.5px] leading-relaxed text-navy-muted">
                <span className="font-semibold text-navy">Last verified: </span>
                {evidence.lastVerifiedAt ?? 'Never — this listing has not been checked against a live source.'}
              </p>
            </div>
          </div>
        }
      </section>

      <p className="mt-4 flex gap-2 rounded-xl bg-brand-50 p-3.5 text-[11.5px] leading-relaxed text-brand-800">
        <InfoIcon size={15} className="mt-0.5 shrink-0" />
        {TRUST_MESSAGE}
      </p>

      {/* Decision — only offered once the checklist is done. */}
      <section className="mt-6 rounded-2xl border border-hairline bg-white p-4">
        <h2 className="text-[15px] font-bold text-navy">{t('enroll.ready')}</h2>
        <p className="mt-1.5 text-[12.5px] leading-relaxed text-navy-muted">
          {complete ?
          'You’ve been through every check. The decision is entirely yours.' :
          `Work through the checklist first — ${CHECKLIST_TOTAL - checked.length} item${
          CHECKLIST_TOTAL - checked.length === 1 ? '' : 's'} left. You can leave and come back; your progress is saved.`
          }
        </p>

        {decided &&
        <p
          role="status"
          className="mt-3 flex items-center gap-2 rounded-lg bg-goodSoft px-3 py-2.5 text-[12.5px] font-medium text-good">
          
            <ShieldCheckIcon size={15} className="shrink-0" />
            Marked as verified by you. This is your own record, not a SkillBridgeAI endorsement.
          </p>
        }

        <div className="mt-3.5 space-y-2.5">
          <Button
            fullWidth
            disabled={!complete}
            onClick={() => {
              markProviderVerified(providerKey, CHECKLIST_ITEMS.map((i) => i.id));
              setDecided(true);
            }}
            icon={<ShieldCheckIcon size={17} />}>
            
            {t('enroll.verified')}
          </Button>
          <Button
            variant="outline"
            fullWidth
            onClick={() => navigate(`/providers/${providerKind}/compare?from=${provider.id}`)}>
            
            {t('enroll.compareOther')}
          </Button>
          <Button
            variant="ghost"
            fullWidth
            onClick={() => {
              if (!saved) toggleSaved(provider.saveKind, provider.id);
              navigate(providerKind === 'academy' ? '/academies' : '/institutions');
            }}>
            
            {t('enroll.later')}
          </Button>
        </div>
      </section>

      <p className="mt-4 flex items-start gap-2 text-[11.5px] leading-relaxed text-navy-muted">
        <ExternalLinkIcon size={13} className="mt-0.5 shrink-0" />
        SkillBridgeAI never handles payments or applications. Anything you commit to happens directly with the
        provider.
      </p>
    </Screen>);

}