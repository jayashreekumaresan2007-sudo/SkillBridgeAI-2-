export type FeatureKey =
'interest_technology' |
'interest_design' |
'interest_business' |
'interest_data' |
'interest_science' |
'interest_communication' |
'creativity_score' |
'analytical_score' |
'communication_score' |
'leadership_score' |
'problem_solving_score' |
'technical_confidence' |
'teamwork_score' |
'coding_preference' |
'design_preference' |
'research_preference' |
'people_orientation' |
'business_orientation';

export type FeatureVector = Record<FeatureKey, number>;

export type CareerCategoryId =
'ai_ml' |
'software' |
'data' |
'cybersecurity' |
'uiux' |
'business' |
'marketing' |
'research' |
'cloud' |
'product';

export type SkillLevel = 'Strong' | 'Developing' | 'Needs Improvement';

export interface RequiredSkill {
  name: string;
  /** Feature used to estimate the user's current confidence in this skill. */
  source: FeatureKey;
  /** 0-1, how central the skill is to the role. */
  weight: number;
}

export interface Career {
  id: CareerCategoryId;
  title: string;
  family: string;
  tagline: string;
  overview: string;
  whatYouDo: string[];
  technicalSkills: string[];
  softSkills: string[];
  requiredSkills: RequiredSkill[];
  learningPath: string[];
  entryRoles: string[];
  growth: string[];
  responsibilities: string;
  related: CareerCategoryId[];
}

export interface CareerRecommendation {
  careerId: CareerCategoryId;
  /** Model probability, 0-1. */
  score: number;
  /** Percentage shown in the UI. */
  match: number;
  confidence: 'High' | 'Moderate' | 'Emerging';
  reasons: string[];
}

export interface SkillGapItem {
  name: string;
  level: SkillLevel;
  value: number;
  weight: number;
}

export interface RoadmapStep {
  id: string;
  title: string;
  goal: string;
  skills: string[];
  activity: string;
}

/** The three primary journeys chosen on the "What do you need help with?" screen. */
export type JourneyId = 'career' | 'skill' | 'not_sure';

export type UserCategoryId = 'school' | 'college' | 'graduate' | 'working' | 'switcher' | 'other';

export type QuestionType = 'multi' | 'single' | 'rating';

export interface QuestionOption {
  id: string;
  label: string;
  hint?: string;
  icon: string;
  weights: Partial<Record<FeatureKey, number>>;
}

export interface RatingItem {
  id: string;
  label: string;
  feature: FeatureKey;
}

export interface Question {
  id: string;
  type: QuestionType;
  kind: 'Interest' | 'Activity' | 'Category' | 'Scenario' | 'Rate yourself' | 'Skill confidence';
  title: string;
  helper: string;
  maxSelect?: number;
  options?: QuestionOption[];
  items?: RatingItem[];
  scenarioContext?: string;
}

/** answers: questionId -> string[] (choices) or Record<itemId, 1-5> */
export type AnswerValue = string[] | Record<string, number>;

/** A concrete job role inside a career category. */
export type RoleKind = 'core' | 'adjacent' | 'hidden' | 'emerging';

export interface Role {
  id: string;
  title: string;
  careerId: CareerCategoryId;
  kind: RoleKind;
  summary: string;
  /** Feature affinity used to re-rank roles inside a predicted career category. */
  affinity: Partial<Record<FeatureKey, number>>;
  skills: string[];
}

export interface RoleRecommendation {
  roleId: string;
  title: string;
  careerId: CareerCategoryId;
  kind: RoleKind;
  summary: string;
  match: number;
  confidence: 'High' | 'Moderate' | 'Emerging';
  why: string[];
  skills: string[];
}

export interface RoleDiscovery {
  bestFit: RoleRecommendation | null;
  alternative: RoleRecommendation | null;
  adjacent: RoleRecommendation | null;
  hidden: RoleRecommendation | null;
  emerging: RoleRecommendation | null;
}

export interface SkillProfileItem {
  id: string;
  name: string;
  feature: FeatureKey;
  level: SkillLevel;
  value: number;
  note: string;
}

export type SkillAdviceKind = 'strengthen' | 'improve' | 'learn' | 'complementary' | 'emerging';

export interface SkillRecommendation {
  id: string;
  name: string;
  kind: SkillAdviceKind;
  reason: string;
  careerId: CareerCategoryId;
  roleTitle: string;
  value: number;
}

export interface Institution {
  id: string;
  name: string;
  type: 'University' | 'College' | 'Polytechnic' | 'Research Institute';
  location: string;
  city: string;
  programs: string[];
  skills: string[];
  careers: CareerCategoryId[];
  relevance: string;
  modes: ('On campus' | 'Hybrid')[];
  rating: number;
  reviews: number;
  /** Mock distance for the MVP — no maps API is used. */
  distanceKm: number;
}

export interface Academy {
  id: string;
  name: string;
  course: string;
  skills: string[];
  careers: CareerCategoryId[];
  mode: 'Online' | 'Offline' | 'Hybrid';
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  duration: string;
  location: string;
  rating: number;
  reviews: number;
}

/** A single piece of provider information, and how far SkillBridgeAI can stand behind it. */
export interface EvidenceItem {
  label: string;
  value: string;
  /** 'listed' = present in the dataset shown here. 'unverified' = SkillBridgeAI cannot confirm it. */
  status: 'listed' | 'unverified';
  source: string;
}

export interface ProviderEvidence {
  /** Official website on file, or null when SkillBridgeAI does not hold one. */
  website: string | null;
  /** ISO date the listing was last checked, or null when it never has been. */
  lastVerifiedAt: string | null;
  items: EvidenceItem[];
}

/** Institutions and academies presented through one shape for the clarity flow. */
export type ProviderKind = 'institution' | 'academy';

export interface ProviderView {
  kind: ProviderKind;
  id: string;
  name: string;
  headline: string;
  location: string;
  mode: string;
  duration: string | null;
  level: string | null;
  fee: string | null;
  skills: string[];
  careers: CareerCategoryId[];
  rating: number;
  reviews: number;
  distanceKm: number | null;
  saveKind: 'savedInstitutions' | 'savedAcademies';
}

export interface ClarityAnswers {
  direction: number;
  skills: number;
  path: number;
  confidence: number;
}

export interface UserProfile {
  name: string;
  email: string;
  isGuest: boolean;
  language: string;
  userCategory: string;
  avatar: string | null;
  gender: 'male' | 'female' | 'neutral' | null;
  careerPath: string | null;
  assessmentAnswers: Record<string, AnswerValue>;
  assessmentComplete: boolean;
  features: FeatureVector | null;
  recommendations: CareerRecommendation[];
  selectedCareer: CareerCategoryId | null;
  roadmapProgress: Record<string, string[]>;
  savedCareers: string[];
  savedInstitutions: string[];
  savedAcademies: string[];
  clarityAnswers: ClarityAnswers | null;
  careerRelevance: 'yes' | 'maybe' | 'no' | null;
  /** Skill toolkit notes, keyed by skill name. */
  skillNotes: Record<string, string>;
  focusSkill: string | null;
  /** Pre-enrollment checklist state, keyed by "<kind>:<providerId>". */
  enrollmentChecks: Record<string, string[]>;
}