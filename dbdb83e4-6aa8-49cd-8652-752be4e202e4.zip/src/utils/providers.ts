import { ACADEMIES } from '../data/academies';
import { INSTITUTIONS } from '../data/institutions';
import type { Academy, Institution, ProviderEvidence, ProviderKind, ProviderView } from '../types';

function fromInstitution(institution: Institution): ProviderView {
  return {
    kind: 'institution',
    id: institution.id,
    name: institution.name,
    headline: institution.programs[0] ?? institution.type,
    location: institution.location,
    mode: institution.modes.join(' / '),
    duration: null,
    level: institution.type,
    fee: null,
    skills: institution.skills,
    careers: institution.careers,
    rating: institution.rating,
    reviews: institution.reviews,
    distanceKm: institution.distanceKm,
    saveKind: 'savedInstitutions'
  };
}

function fromAcademy(academy: Academy): ProviderView {
  return {
    kind: 'academy',
    id: academy.id,
    name: academy.name,
    headline: academy.course,
    location: academy.location,
    mode: academy.mode,
    duration: academy.duration,
    level: academy.level,
    fee: null,
    skills: academy.skills,
    careers: academy.careers,
    rating: academy.rating,
    reviews: academy.reviews,
    distanceKm: null,
    saveKind: 'savedAcademies'
  };
}

export function listProviders(kind: ProviderKind): ProviderView[] {
  return kind === 'institution' ? INSTITUTIONS.map(fromInstitution) : ACADEMIES.map(fromAcademy);
}

export function getProvider(kind: ProviderKind, id: string): ProviderView | null {
  return listProviders(kind).find((provider) => provider.id === id) ?? null;
}

/**
 * Builds the evidence panel from what the prototype actually holds. Anything
 * SkillBridgeAI cannot stand behind is marked unverified rather than dressed up
 * — no fabricated fees, accreditation, placement figures or availability.
 */
export function buildEvidence(provider: ProviderView): ProviderEvidence {
  const listedSource = 'SkillBridgeAI sample dataset (prototype)';
  const confirm = 'Not held by SkillBridgeAI — confirm directly with the provider';

  const items: ProviderEvidence['items'] = [
  {
    label: provider.kind === 'academy' ? 'Course listing' : 'Programs listed',
    value: provider.headline,
    status: 'listed',
    source: listedSource
  },
  {
    label: 'Skills covered',
    value: provider.skills.join(', '),
    status: 'listed',
    source: listedSource
  },
  {
    label: 'Location',
    value: provider.distanceKm !== null ? `${provider.location} · ${provider.distanceKm} km` : provider.location,
    status: 'listed',
    source: `${listedSource} — approximate, no maps provider connected`
  },
  {
    label: 'Delivery mode',
    value: provider.mode,
    status: 'listed',
    source: listedSource
  },
  {
    label: 'Course fee',
    value: provider.fee ?? 'Not published here',
    status: 'unverified',
    source: confirm
  },
  {
    label: 'Current availability',
    value: 'Unknown — no live feed connected',
    status: 'unverified',
    source: confirm
  },
  {
    label: 'Accreditation / certification',
    value: 'No accreditation record on file',
    status: 'unverified',
    source: confirm
  },
  {
    label: 'Placement claims',
    value: 'No placement data on file',
    status: 'unverified',
    source: confirm
  },
  {
    label: 'Rating',
    value: `${provider.rating} from ${provider.reviews} reviews`,
    status: 'unverified',
    source: 'Sample figure for this prototype — compare reviews from more than one source'
  }];


  return {
    // No official URLs are held for these sample providers, so none are invented.
    website: null,
    lastVerifiedAt: null,
    items
  };
}

export interface ProviderFit {
  goalLabel: string | null;
  matched: string[];
  notCovered: string[];
  extra: string[];
  careerAligned: boolean;
}

/** Compares what a provider teaches against the skills the user still needs. */
export function buildFit(
provider: ProviderView,
neededSkills: string[],
goalLabel: string | null,
careerId: string | null)
: ProviderFit {
  const matched = neededSkills.filter((skill) => provider.skills.includes(skill));
  const notCovered = neededSkills.filter((skill) => !provider.skills.includes(skill));
  const extra = provider.skills.filter((skill) => !neededSkills.includes(skill));
  return {
    goalLabel,
    matched,
    notCovered,
    extra,
    careerAligned: careerId ? provider.careers.includes(careerId as never) : false
  };
}