export interface ChecklistItem {
  id: string;
  label: string;
  hint: string;
}

export interface ChecklistGroup {
  id: string;
  title: string;
  summary: string;
  items: ChecklistItem[];
}

/**
 * The pre-enrollment checklist. Grouped into three short sections so the user
 * reads one idea at a time rather than eleven at once.
 */
export const CHECKLIST_GROUPS: ChecklistGroup[] = [
{
  id: 'course',
  title: 'The course itself',
  summary: 'Confirm it exists, runs now, and teaches what you came for.',
  items: [
  {
    id: 'available',
    label: 'The course is currently available',
    hint: 'Batches listed online are often out of date. Ask for the next start date.'
  },
  {
    id: 'syllabus',
    label: 'The syllabus matches the skills you want',
    hint: 'Ask for the module list in writing and compare it to your skill gap.'
  },
  {
    id: 'website',
    label: 'You have checked the official website',
    hint: 'Go to the provider’s own site, not a re-seller or an advert.'
  },
  {
    id: 'schedule',
    label: 'The duration and schedule suit you',
    hint: 'Check the weekly hours, not just the total length.'
  }]

},
{
  id: 'cost',
  title: 'Cost and policy',
  summary: 'Know the full amount and what happens if you leave.',
  items: [
  {
    id: 'fee',
    label: 'You have confirmed the current fee',
    hint: 'Fees change between batches. Get the figure for your intake in writing.'
  },
  {
    id: 'hidden',
    label: 'You have asked about additional charges',
    hint: 'Exam fees, materials, certification and platform charges are often separate.'
  },
  {
    id: 'refund',
    label: 'You have read the refund and cancellation policy',
    hint: 'Ask what happens if you withdraw in week one versus week six.'
  }]

},
{
  id: 'trust',
  title: 'Claims and evidence',
  summary: 'Test the claims that are easiest to overstate.',
  items: [
  {
    id: 'accreditation',
    label: 'You have verified certification or accreditation claims',
    hint: 'Check the awarding body directly, where one is named.'
  },
  {
    id: 'placement',
    label: 'You have checked any placement claims',
    hint: 'Ask how the figure is calculated and over what period.'
  },
  {
    id: 'reviews',
    label: 'You have read reviews from more than one source',
    hint: 'Look for recent reviews from past students, not only testimonials on the site.'
  },
  {
    id: 'contact',
    label: 'You have contacted the provider directly',
    hint: 'A short call answers most of the above and tells you how they treat enquiries.'
  }]

}];


export const CHECKLIST_ITEMS: ChecklistItem[] = CHECKLIST_GROUPS.flatMap((group) => group.items);
export const CHECKLIST_TOTAL = CHECKLIST_ITEMS.length;

export const TRUST_MESSAGE =
'SkillBridgeAI recommends options based on available information. We do not guarantee course quality, outcomes, placement, or future career success. Always verify important details directly with the provider before paying or enrolling.';