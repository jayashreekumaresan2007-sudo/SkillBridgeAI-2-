export interface AvatarOption {
  id: string;
  gender: 'male' | 'female' | 'neutral';
  name: string;
  /** The learning stage the character portrays — shown as a quiet caption. */
  stage: string;
  image: string;
}

/**
 * The SkillBridgeAI character family — one coherent set of semi-realistic
 * portraits drawn in a single style, spanning school through early career.
 *
 * VISUAL PERSONALISATION ONLY in this MVP. No voice, conversation, animation
 * or lip-sync behaviour is attached to them.
 */
export const AVATARS: AvatarOption[] = [
{
  id: 'sb-1',
  gender: 'female',
  name: 'Ilakkiya',
  stage: 'School student',
  image: "/1f8d59e5-7abb-441b-929a-4f9e4cb2881b.jpg"
},
{
  id: 'sb-2',
  gender: 'male',
  name: 'Arun',
  stage: 'School student',
  image: "/b4cf8749-06fe-4c88-af4c-93fd11088729.jpg"
},
{
  id: 'sb-3',
  gender: 'female',
  name: 'Meera',
  stage: 'College student',
  image: "/6d134326-09a3-4f80-a983-51cb623da7a6.jpg"
},
{
  id: 'sb-4',
  gender: 'male',
  name: 'Nikhil',
  stage: 'College student',
  image: "/d08a1742-9279-4a97-a23d-432ebef06297.jpg"
},
{
  id: 'sb-5',
  gender: 'male',
  name: 'Daniel',
  stage: 'Graduate',
  image: "/02dd336f-bf51-42b9-bd7c-a4bf8bfe39a5.jpg"
},
{
  id: 'sb-6',
  gender: 'female',
  name: 'Divya',
  stage: 'Young professional',
  image: "/31fb09fd-11f8-4c2e-8b9e-b1ac05d574cd.jpg"
},
{
  id: 'sb-7',
  gender: 'male',
  name: 'Vikram',
  stage: 'Young professional',
  image: "/a8fe54e7-5986-40d9-8b1a-b44c16a26831.jpg"
},
{
  id: 'sb-8',
  gender: 'neutral',
  name: 'Ari',
  stage: 'Learner',
  image: "/023bd752-04ac-45a0-8a0f-ca014440b29f.jpg"
}];


export const getAvatar = (id: string | null) => AVATARS.find((a) => a.id === id) ?? null;

export const LANGUAGES = ['English', 'Tamil', 'Hindi', 'Malayalam'];

export const USER_CATEGORIES = [
{ id: 'school', labelKey: 'cat.school', icon: 'School' },
{ id: 'college', labelKey: 'cat.college', icon: 'GraduationCap' },
{ id: 'graduate', labelKey: 'cat.graduate', icon: 'Award' },
{ id: 'working', labelKey: 'cat.working', icon: 'Briefcase' },
{ id: 'switcher', labelKey: 'cat.switcher', icon: 'Route' },
{ id: 'other', labelKey: 'cat.other', icon: 'CircleEllipsis' }];