import React from 'react';
import { BrowserRouter, Navigate, Outlet, Route, Routes } from 'react-router-dom';
import { BottomNav } from './components/BottomNav';
import { PhoneFrame } from './components/PhoneFrame';
import { UserProvider } from './contexts/UserContext';
import { Academies } from './pages/Academies';
import { Assessment } from './pages/Assessment';
import { AssessmentComplete } from './pages/AssessmentComplete';
import { AssessmentIntro } from './pages/AssessmentIntro';
import { AvatarSelection } from './pages/AvatarSelection';
import { CareerCompare } from './pages/CareerCompare';
import { CareerDetail } from './pages/CareerDetail';
import { CareerExplore } from './pages/CareerExplore';
import { CareerResults } from './pages/CareerResults';
import { ClarityCheck } from './pages/ClarityCheck';
import { CreateAccount } from './pages/CreateAccount';
import { Dashboard } from './pages/Dashboard';
import { ForgotPassword } from './pages/ForgotPassword';
import { Institutions } from './pages/Institutions';
import { LanguageCategory } from './pages/LanguageCategory';
import { Login } from './pages/Login';
import { PathSelection } from './pages/PathSelection';
import { Profile } from './pages/Profile';
import { Roadmap } from './pages/Roadmap';
import { Saved } from './pages/Saved';
import { ProviderClarityCheck } from './pages/ProviderClarityCheck';
import { ProviderCompare } from './pages/ProviderCompare';
import { SkillDetail } from './pages/SkillDetail';
import { SkillGap } from './pages/SkillGap';
import { SkillResults } from './pages/SkillResults';
import { Splash } from './pages/Splash';
import { Walkthrough } from './pages/Walkthrough';

function TabLayout() {
  return (
    <div className="flex h-full w-full flex-col">
      <div className="min-h-0 flex-1">
        <Outlet />
      </div>
      <BottomNav />
    </div>);

}

export function App() {
  return (
    <UserProvider>
      <BrowserRouter>
        <PhoneFrame>
          <Routes>
            <Route path="/" element={<Splash />} />
            <Route path="/walkthrough" element={<Walkthrough />} />
            <Route path="/login" element={<Login />} />
            <Route path="/create-account" element={<CreateAccount />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />

            <Route path="/onboarding/language" element={<LanguageCategory />} />
            <Route path="/onboarding/avatar" element={<AvatarSelection />} />
            <Route path="/onboarding/path" element={<PathSelection />} />

            <Route path="/assessment/intro" element={<AssessmentIntro />} />
            <Route path="/assessment" element={<Assessment />} />
            <Route path="/assessment/complete" element={<AssessmentComplete />} />

            <Route path="/results" element={<CareerResults />} />
            <Route path="/careers/:careerId" element={<CareerDetail />} />
            <Route path="/compare" element={<CareerCompare />} />
            <Route path="/providers/:kind/compare" element={<ProviderCompare />} />
            <Route path="/providers/:kind/:providerId" element={<ProviderClarityCheck />} />
            <Route path="/skill-results" element={<SkillResults />} />
            <Route path="/skills/:skillId" element={<SkillDetail />} />
            <Route path="/skill-gap" element={<SkillGap />} />
            <Route path="/roadmap" element={<Roadmap />} />
            <Route path="/clarity" element={<ClarityCheck />} />

            <Route element={<TabLayout />}>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/careers" element={<CareerExplore />} />
              <Route path="/institutions" element={<Institutions />} />
              <Route path="/academies" element={<Academies />} />
              <Route path="/saved" element={<Saved />} />
              <Route path="/profile" element={<Profile />} />
            </Route>

            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </PhoneFrame>
      </BrowserRouter>
    </UserProvider>);

}