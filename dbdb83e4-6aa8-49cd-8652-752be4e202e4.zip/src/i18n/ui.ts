export type LanguageCode = 'English' | 'Tamil' | 'Hindi' | 'Malayalam';

export const LANGUAGE_CODES: LanguageCode[] = ['English', 'Tamil', 'Hindi', 'Malayalam'];

export const LANGUAGE_NATIVE: Record<LanguageCode, string> = {
  English: 'English',
  Tamil: 'தமிழ்',
  Hindi: 'हिंदी',
  Malayalam: 'മലയാളം'
};

type Entry = Record<LanguageCode, string>;

/**
 * UI string table. Priority per product spec: navigation, headings, buttons,
 * questions, options, error messages and core feature labels are translated.
 * Long supporting paragraphs stay in English in this MVP.
 */
export const UI: Record<string, Entry> = {
  // Navigation
  'nav.home': { English: 'Home', Tamil: 'முகப்பு', Hindi: 'होम', Malayalam: 'ഹോം' },
  'nav.careers': { English: 'Careers', Tamil: 'தொழில்கள்', Hindi: 'करियर', Malayalam: 'കരിയർ' },
  'nav.learn': { English: 'Learn', Tamil: 'கற்க', Hindi: 'सीखें', Malayalam: 'പഠിക്കുക' },
  'nav.saved': { English: 'Saved', Tamil: 'சேமித்தவை', Hindi: 'सहेजा', Malayalam: 'സേവ് ചെയ്തവ' },
  'nav.profile': { English: 'Profile', Tamil: 'சுயவிவரம்', Hindi: 'प्रोफ़ाइल', Malayalam: 'പ്രൊഫൈൽ' },

  // Common actions
  'common.next': { English: 'Next', Tamil: 'அடுத்து', Hindi: 'आगे', Malayalam: 'അടുത്തത്' },
  'common.back': { English: 'Back', Tamil: 'பின்', Hindi: 'पीछे', Malayalam: 'തിരികെ' },
  'common.skip': { English: 'Skip', Tamil: 'தவிர்', Hindi: 'छोड़ें', Malayalam: 'ഒഴിവാക്കുക' },
  'common.getStarted': { English: 'Get started', Tamil: 'தொடங்குங்கள்', Hindi: 'शुरू करें', Malayalam: 'ആരംഭിക്കുക' },
  'common.continue': { English: 'Continue', Tamil: 'தொடர்க', Hindi: 'जारी रखें', Malayalam: 'തുടരുക' },
  'common.finish': { English: 'Finish', Tamil: 'முடிக்க', Hindi: 'समाप्त', Malayalam: 'പൂർത്തിയാക്കുക' },
  'common.save': { English: 'Save', Tamil: 'சேமி', Hindi: 'सहेजें', Malayalam: 'സേവ് ചെയ്യുക' },
  'common.cancel': { English: 'Cancel', Tamil: 'ரத்து', Hindi: 'रद्द करें', Malayalam: 'റദ്ദാക്കുക' },
  'common.viewDetails': { English: 'View details', Tamil: 'விவரங்களைக் காண', Hindi: 'विवरण देखें', Malayalam: 'വിശദാംശങ്ങൾ' },
  'common.hideDetails': { English: 'Hide details', Tamil: 'விவரங்களை மறை', Hindi: 'विवरण छिपाएँ', Malayalam: 'വിശദാംശങ്ങൾ മറയ്ക്കുക' },
  'common.clearFilters': { English: 'Clear filters', Tamil: 'வடிகட்டிகளை அழி', Hindi: 'फ़िल्टर हटाएँ', Malayalam: 'ഫിൽട്ടറുകൾ മായ്ക്കുക' },
  'common.seeAll': { English: 'See all', Tamil: 'அனைத்தும்', Hindi: 'सभी देखें', Malayalam: 'എല്ലാം കാണുക' },
  'common.viewAll': { English: 'View all', Tamil: 'அனைத்தையும் காண', Hindi: 'सभी देखें', Malayalam: 'എല്ലാം കാണുക' },
  'common.of': { English: 'of', Tamil: 'இல்', Hindi: 'में से', Malayalam: 'ൽ' },
  'common.selected': { English: 'selected', Tamil: 'தேர்ந்தெடுக்கப்பட்டது', Hindi: 'चयनित', Malayalam: 'തിരഞ്ഞെടുത്തു' },
  'common.loading': {
    English: 'Preparing your personalized guidance…',
    Tamil: 'உங்கள் தனிப்பயன் வழிகாட்டல் தயாராகிறது…',
    Hindi: 'आपका व्यक्तिगत मार्गदर्शन तैयार हो रहा है…',
    Malayalam: 'നിങ്ങളുടെ വ്യക്തിഗത മാർഗനിർദ്ദേശം തയ്യാറാകുന്നു…'
  },

  // Walkthrough
  'walk.1.title': {
    English: 'From Confusion\nto Career Clarity',
    Tamil: 'குழப்பத்திலிருந்து\nதொழில் தெளிவுக்கு',
    Hindi: 'भ्रम से\nकरियर स्पष्टता तक',
    Malayalam: 'ആശയക്കുഴപ്പത്തിൽ നിന്ന്\nകരിയർ വ്യക്തതയിലേക്ക്'
  },
  'walk.2.title': {
    English: 'Discover Your\nTrue Potential',
    Tamil: 'உங்கள் உண்மையான\nதிறனை கண்டறியுங்கள்',
    Hindi: 'अपनी असली\nक्षमता खोजें',
    Malayalam: 'നിങ്ങളുടെ യഥാർത്ഥ\nകഴിവ് കണ്ടെത്തുക'
  },
  'walk.3.title': {
    English: 'Personalized Guidance\nJust for You',
    Tamil: 'உங்களுக்காக மட்டும்\nதனிப்பயன் வழிகாட்டல்',
    Hindi: 'सिर्फ़ आपके लिए\nव्यक्तिगत मार्गदर्शन',
    Malayalam: 'നിങ്ങൾക്കായി മാത്രം\nവ്യക്തിഗത മാർഗനിർദ്ദേശം'
  },

  // Auth
  'auth.welcome': { English: 'Welcome back', Tamil: 'மீண்டும் வருக', Hindi: 'वापसी पर स्वागत है', Malayalam: 'വീണ്ടും സ്വാഗതം' },
  'auth.email': { English: 'Email', Tamil: 'மின்னஞ்சல்', Hindi: 'ईमेल', Malayalam: 'ഇമെയിൽ' },
  'auth.password': { English: 'Password', Tamil: 'கடவுச்சொல்', Hindi: 'पासवर्ड', Malayalam: 'പാസ്‌വേഡ്' },
  'auth.fullName': { English: 'Full name', Tamil: 'முழு பெயர்', Hindi: 'पूरा नाम', Malayalam: 'പൂർണ്ണ നാമം' },
  'auth.confirmPassword': { English: 'Confirm password', Tamil: 'கடவுச்சொல்லை உறுதிப்படுத்து', Hindi: 'पासवर्ड की पुष्टि करें', Malayalam: 'പാസ്‌വേഡ് സ്ഥിരീകരിക്കുക' },
  'auth.remember': { English: 'Remember me', Tamil: 'என்னை நினைவில் கொள்', Hindi: 'मुझे याद रखें', Malayalam: 'എന്നെ ഓർക്കുക' },
  'auth.forgot': { English: 'Forgot password?', Tamil: 'கடவுச்சொல் மறந்ததா?', Hindi: 'पासवर्ड भूल गए?', Malayalam: 'പാസ്‌വേഡ് മറന്നോ?' },
  'auth.login': { English: 'Log in', Tamil: 'உள்நுழை', Hindi: 'लॉग इन', Malayalam: 'ലോഗിൻ' },
  'auth.createAccount': { English: 'Create account', Tamil: 'கணக்கை உருவாக்கு', Hindi: 'खाता बनाएँ', Malayalam: 'അക്കൗണ്ട് സൃഷ്ടിക്കുക' },
  'auth.orContinue': { English: 'or continue with', Tamil: 'அல்லது தொடரவும்', Hindi: 'या जारी रखें', Malayalam: 'അല്ലെങ്കിൽ തുടരുക' },
  'auth.guest': { English: 'Explore as guest', Tamil: 'விருந்தினராக பார்வையிடு', Hindi: 'अतिथि के रूप में देखें', Malayalam: 'അതിഥിയായി കാണുക' },
  'auth.haveAccount': { English: 'Already have an account?', Tamil: 'ஏற்கனவே கணக்கு உள்ளதா?', Hindi: 'पहले से खाता है?', Malayalam: 'ഇതിനകം അക്കൗണ്ട് ഉണ്ടോ?' },
  'auth.chooseAccount': { English: 'Choose an account', Tamil: 'ஒரு கணக்கைத் தேர்ந்தெடுக்கவும்', Hindi: 'एक खाता चुनें', Malayalam: 'ഒരു അക്കൗണ്ട് തിരഞ്ഞെടുക്കുക' },
  'auth.useAnother': { English: 'Use another account', Tamil: 'வேறு கணக்கைப் பயன்படுத்து', Hindi: 'दूसरा खाता उपयोग करें', Malayalam: 'മറ്റൊരു അക്കൗണ്ട് ഉപയോഗിക്കുക' },
  'auth.terms': {
    English: 'I agree to the Terms of Use and Privacy Policy.',
    Tamil: 'பயன்பாட்டு விதிகள் மற்றும் தனியுரிமைக் கொள்கையை ஏற்கிறேன்.',
    Hindi: 'मैं उपयोग की शर्तें और गोपनीयता नीति से सहमत हूँ।',
    Malayalam: 'ഉപയോഗ നിബന്ധനകളും സ്വകാര്യതാ നയവും ഞാൻ അംഗീകരിക്കുന്നു.'
  },

  // Errors
  'err.email': { English: 'Enter a valid email address.', Tamil: 'சரியான மின்னஞ்சலை உள்ளிடவும்.', Hindi: 'मान्य ईमेल पता दर्ज करें।', Malayalam: 'സാധുവായ ഇമെയിൽ നൽകുക.' },
  'err.passwordShort': { English: 'Password must be at least 6 characters.', Tamil: 'கடவுச்சொல் குறைந்தது 6 எழுத்துகள்.', Hindi: 'पासवर्ड कम से कम 6 अक्षर का हो।', Malayalam: 'പാസ്‌വേഡ് കുറഞ്ഞത് 6 അക്ഷരം വേണം.' },
  'err.password8': { English: 'Use at least 8 characters.', Tamil: 'குறைந்தது 8 எழுத்துகள் பயன்படுத்தவும்.', Hindi: 'कम से कम 8 अक्षर उपयोग करें।', Malayalam: 'കുറഞ്ഞത് 8 അക്ഷരം ഉപയോഗിക്കുക.' },
  'err.passwordNumber': { English: 'Include at least one number.', Tamil: 'குறைந்தது ஒரு எண் சேர்க்கவும்.', Hindi: 'कम से कम एक अंक शामिल करें।', Malayalam: 'ഒരു അക്കമെങ്കിലും ഉൾപ്പെടുത്തുക.' },
  'err.mismatch': { English: 'Passwords do not match.', Tamil: 'கடவுச்சொற்கள் பொருந்தவில்லை.', Hindi: 'पासवर्ड मेल नहीं खाते।', Malayalam: 'പാസ്‌വേഡുകൾ പൊരുത്തപ്പെടുന്നില്ല.' },
  'err.credentials': { English: "Email or password doesn't match.", Tamil: 'மின்னஞ்சல் அல்லது கடவுச்சொல் பொருந்தவில்லை.', Hindi: 'ईमेल या पासवर्ड मेल नहीं खाता।', Malayalam: 'ഇമെയിലോ പാസ്‌വേഡോ പൊരുത്തപ്പെടുന്നില്ല.' },
  'err.name': { English: 'Enter your full name.', Tamil: 'உங்கள் முழு பெயரை உள்ளிடவும்.', Hindi: 'अपना पूरा नाम दर्ज करें।', Malayalam: 'നിങ്ങളുടെ പൂർണ്ണ നാമം നൽകുക.' },
  'err.terms': { English: 'Please accept the Terms and Privacy Policy.', Tamil: 'விதிகளையும் தனியுரிமைக் கொள்கையையும் ஏற்கவும்.', Hindi: 'कृपया शर्तें और गोपनीयता नीति स्वीकार करें।', Malayalam: 'നിബന്ധനകളും സ്വകാര്യതാ നയവും അംഗീകരിക്കുക.' },
  'err.selectOption': { English: 'Please select an option to continue.', Tamil: 'தொடர ஒரு விருப்பத்தைத் தேர்ந்தெடுக்கவும்.', Hindi: 'जारी रखने के लिए एक विकल्प चुनें।', Malayalam: 'തുടരാൻ ഒരു ഓപ്ഷൻ തിരഞ്ഞെടുക്കുക.' },
  'err.noInstitutions': { English: "We couldn't find a match nearby.", Tamil: 'அருகில் பொருத்தம் கிடைக்கவில்லை.', Hindi: 'आसपास कोई मेल नहीं मिला।', Malayalam: 'അടുത്ത് പൊരുത്തം കണ്ടെത്തിയില്ല.' },
  'err.noAcademies': { English: 'No academies found.', Tamil: 'அகாடமிகள் எதுவும் இல்லை.', Hindi: 'कोई अकादमी नहीं मिली।', Malayalam: 'അക്കാദമികളൊന്നും കണ്ടെത്തിയില്ല.' },
  'err.noCareers': { English: 'No careers found.', Tamil: 'தொழில்கள் எதுவும் இல்லை.', Hindi: 'कोई करियर नहीं मिला।', Malayalam: 'കരിയറുകളൊന്നും കണ്ടെത്തിയില്ല.' },

  // Onboarding
  'onb.personalise': { English: 'Personalise your experience', Tamil: 'உங்கள் அனுபவத்தை தனிப்பயனாக்குங்கள்', Hindi: 'अपना अनुभव व्यक्तिगत बनाएँ', Malayalam: 'നിങ്ങളുടെ അനുഭവം വ്യക്തിഗതമാക്കുക' },
  'onb.language': { English: 'Choose your language', Tamil: 'உங்கள் மொழியைத் தேர்ந்தெடுக்கவும்', Hindi: 'अपनी भाषा चुनें', Malayalam: 'നിങ്ങളുടെ ഭാഷ തിരഞ്ഞെടുക്കുക' },
  'onb.languageHint': { English: 'The interface updates immediately.', Tamil: 'இடைமுகம் உடனடியாக மாறும்.', Hindi: 'इंटरफ़ेस तुरंत बदल जाएगा।', Malayalam: 'ഇന്റർഫേസ് ഉടൻ മാറും.' },
  'onb.describe': { English: 'What describes you best?', Tamil: 'உங்களை சிறப்பாக விவரிப்பது எது?', Hindi: 'आपको सबसे अच्छा क्या बताता है?', Malayalam: 'നിങ്ങളെ ഏറ്റവും നന്നായി വിവരിക്കുന്നത്?' },
  'cat.school': { English: 'School Student', Tamil: 'பள்ளி மாணவர்', Hindi: 'स्कूल छात्र', Malayalam: 'സ്കൂൾ വിദ്യാർത്ഥി' },
  'cat.college': { English: 'College Student', Tamil: 'கல்லூரி மாணவர்', Hindi: 'कॉलेज छात्र', Malayalam: 'കോളേജ് വിദ്യാർത്ഥി' },
  'cat.graduate': { English: 'Graduate', Tamil: 'பட்டதாரி', Hindi: 'स्नातक', Malayalam: 'ബിരുദധാരി' },
  'cat.working': { English: 'Working Professional', Tamil: 'பணிபுரிபவர்', Hindi: 'कार्यरत पेशेवर', Malayalam: 'ജോലി ചെയ്യുന്നയാൾ' },
  'cat.switcher': { English: 'Career Switcher', Tamil: 'தொழில் மாற்றுபவர்', Hindi: 'करियर बदलने वाले', Malayalam: 'കരിയർ മാറ്റുന്നയാൾ' },
  'cat.other': { English: 'Other', Tamil: 'மற்றவை', Hindi: 'अन्य', Malayalam: 'മറ്റുള്ളവ' },

  // Avatar
  'avatar.knowYou': { English: 'Let’s get to know you', Tamil: 'உங்களை அறிந்து கொள்வோம்', Hindi: 'आपको जानते हैं', Malayalam: 'നിങ്ങളെ അറിയാം' },
  'avatar.gender': { English: 'What’s your gender?', Tamil: 'உங்கள் பாலினம்?', Hindi: 'आपका लिंग?', Malayalam: 'നിങ്ങളുടെ ലിംഗം?' },
  'avatar.male': { English: 'Male', Tamil: 'ஆண்', Hindi: 'पुरुष', Malayalam: 'പുരുഷൻ' },
  'avatar.female': { English: 'Female', Tamil: 'பெண்', Hindi: 'महिला', Malayalam: 'സ്ത്രീ' },
  'avatar.choose': { English: 'Choose your avatar', Tamil: 'உங்கள் அவதாரத்தைத் தேர்வுசெய்க', Hindi: 'अपना अवतार चुनें', Malayalam: 'നിങ്ങളുടെ അവതാർ തിരഞ്ഞെടുക്കുക' },
  'avatar.select': { English: 'Select your avatar', Tamil: 'அவதாரத்தைத் தேர்ந்தெடுக்கவும்', Hindi: 'अवतार चुनें', Malayalam: 'അവതാർ തിരഞ്ഞെടുക്കുക' },
  'avatar.skip': { English: 'Prefer not to say — skip avatar', Tamil: 'சொல்ல விரும்பவில்லை — தவிர்', Hindi: 'नहीं बताना चाहते — छोड़ें', Malayalam: 'പറയേണ്ട — ഒഴിവാക്കുക' },

  // Path selection
  'path.title': { English: 'What do you need help with?', Tamil: 'உங்களுக்கு எதில் உதவி வேண்டும்?', Hindi: 'आपको किसमें मदद चाहिए?', Malayalam: 'നിങ്ങൾക്ക് എന്തിലാണ് സഹായം വേണ്ടത്?' },
  'path.career': { English: 'Career Guidance', Tamil: 'தொழில் வழிகாட்டல்', Hindi: 'करियर मार्गदर्शन', Malayalam: 'കരിയർ മാർഗനിർദ്ദേശം' },
  'path.careerDesc': { English: 'Find careers that fit you.', Tamil: 'உங்களுக்கு ஏற்ற தொழில்களைக் கண்டறியுங்கள்.', Hindi: 'आपके अनुकूल करियर खोजें।', Malayalam: 'നിങ്ങൾക്ക് ചേരുന്ന കരിയർ കണ്ടെത്തുക.' },
  'path.skill': { English: 'Skill Development', Tamil: 'திறன் மேம்பாடு', Hindi: 'कौशल विकास', Malayalam: 'നൈപുണ്യ വികസനം' },
  'path.skillDesc': { English: 'Identify skills and build a learning path.', Tamil: 'திறன்களை அறிந்து கற்றல் பாதையை உருவாக்குங்கள்.', Hindi: 'कौशल पहचानें और सीखने का रास्ता बनाएँ।', Malayalam: 'നൈപുണ്യങ്ങൾ തിരിച്ചറിഞ്ഞ് പഠന പാത ഉണ്ടാക്കുക.' },
  'path.unsure': { English: 'I’m Not Sure', Tamil: 'எனக்குத் தெரியவில்லை', Hindi: 'मुझे यकीन नहीं', Malayalam: 'എനിക്ക് ഉറപ്പില്ല' },
  'path.unsureDesc': { English: 'Let SkillBridgeAI help identify where to begin.', Tamil: 'எங்கு தொடங்குவது என்பதை SkillBridgeAI உதவட்டும்.', Hindi: 'SkillBridgeAI तय करने में मदद करेगा।', Malayalam: 'എവിടെ തുടങ്ങണമെന്ന് SkillBridgeAI സഹായിക്കും.' },

  // Skill journey
  'skill.profile': { English: 'Your skill profile', Tamil: 'உங்கள் திறன் சுயவிவரம்', Hindi: 'आपकी कौशल प्रोफ़ाइल', Malayalam: 'നിങ്ങളുടെ നൈപുണ്യ പ്രൊഫൈൽ' },
  'skill.toWorkOn': { English: 'Skills to work on', Tamil: 'மேம்படுத்த வேண்டிய திறன்கள்', Hindi: 'सुधारने योग्य कौशल', Malayalam: 'മെച്ചപ്പെടുത്തേണ്ട നൈപുണ്യങ്ങൾ' },
  'skill.toolkit': { English: 'Skill toolkit', Tamil: 'திறன் கருவித்தொகுப்பு', Hindi: 'कौशल टूलकिट', Malayalam: 'നൈപുണ്യ ടൂൾകിറ്റ്' },
  'skill.whereToLearn': { English: 'Where to learn it', Tamil: 'எங்கு கற்பது', Hindi: 'इसे कहाँ सीखें', Malayalam: 'എവിടെ പഠിക്കാം' },
  'skill.why': { English: 'Why this skill?', Tamil: 'ஏன் இந்த திறன்?', Hindi: 'यह कौशल क्यों?', Malayalam: 'എന്തുകൊണ്ട് ഈ നൈപുണ്യം?' },
  'role.explore': { English: 'Roles worth exploring', Tamil: 'ஆராயத்தக்க பணிகள்', Hindi: 'देखने योग्य भूमिकाएँ', Malayalam: 'പര്യവേക്ഷണം ചെയ്യാവുന്ന റോളുകൾ' },
  'verify.title': { English: 'Before you decide', Tamil: 'முடிவெடுப்பதற்கு முன்', Hindi: 'निर्णय लेने से पहले', Malayalam: 'തീരുമാനിക്കുന്നതിന് മുൻപ്' },
  'enroll.title': { English: 'Before You Enroll', Tamil: 'சேருவதற்கு முன்', Hindi: 'नामांकन से पहले', Malayalam: 'ചേരുന്നതിന് മുൻപ്' },
  'enroll.subtitle': { English: 'Take a quick clarity check before making your decision.', Tamil: 'முடிவெடுப்பதற்கு முன் ஒரு விரைவான தெளிவுச் சரிபார்ப்பு.', Hindi: 'निर्णय लेने से पहले एक त्वरित स्पष्टता जाँच करें।', Malayalam: 'തീരുമാനിക്കും മുൻപ് ഒരു വേഗത്തിലുള്ള വ്യക്തതാ പരിശോധന നടത്തുക.' },
  'enroll.check': { English: 'Clarity check', Tamil: 'தெளிவுச் சரிபார்ப்பு', Hindi: 'स्पष्टता जाँच', Malayalam: 'വ്യക്തതാ പരിശോധന' },
  'enroll.fit': { English: 'Does this option fit your current goal?', Tamil: 'இந்த தேர்வு உங்கள் இலக்குக்கு பொருந்துமா?', Hindi: 'क्या यह विकल्प आपके लक्ष्य से मेल खाता है?', Malayalam: 'ഈ ഓപ്ഷൻ നിങ്ങളുടെ ലക്ഷ്യത്തിന് യോജിക്കുന്നുണ്ടോ?' },
  'enroll.checklist': { English: 'Your clarity checklist', Tamil: 'உங்கள் சரிபார்ப்புப் பட்டியல்', Hindi: 'आपकी जाँच सूची', Malayalam: 'നിങ്ങളുടെ പരിശോധനാ പട്ടിക' },
  'enroll.evidence': { English: 'Evidence and sources', Tamil: 'ஆதாரமும் மூலங்களும்', Hindi: 'साक्ष्य और स्रोत', Malayalam: 'തെളിവും ഉറവിടങ്ങളും' },
  'enroll.ready': { English: 'Ready to make your decision?', Tamil: 'முடிவெடுக்கத் தயாரா?', Hindi: 'क्या आप निर्णय लेने को तैयार हैं?', Malayalam: 'തീരുമാനമെടുക്കാൻ തയ്യാറാണോ?' },
  'enroll.verified': { English: 'I’ve verified the details', Tamil: 'விவரங்களைச் சரிபார்த்துவிட்டேன்', Hindi: 'मैंने विवरण सत्यापित कर लिए हैं', Malayalam: 'ഞാൻ വിവരങ്ങൾ പരിശോധിച്ചു' },
  'enroll.compareOther': { English: 'Compare other options', Tamil: 'மற்ற தேர்வுகளை ஒப்பிடு', Hindi: 'अन्य विकल्पों की तुलना करें', Malayalam: 'മറ്റ് ഓപ്ഷനുകൾ താരതമ്യം ചെയ്യുക' },
  'enroll.later': { English: 'I’ll decide later', Tamil: 'பிறகு முடிவு செய்கிறேன்', Hindi: 'मैं बाद में तय करूँगा', Malayalam: 'ഞാൻ പിന്നീട് തീരുമാനിക്കാം' },
  'enroll.saveLater': { English: 'Save for later', Tamil: 'பின்னர் பார்க்க சேமி', Hindi: 'बाद के लिए सहेजें', Malayalam: 'പിന്നീടേക്ക് സേവ് ചെയ്യുക' },

  // Assessment
  'asmt.title': { English: 'Career assessment', Tamil: 'தொழில் மதிப்பீடு', Hindi: 'करियर मूल्यांकन', Malayalam: 'കരിയർ വിലയിരുത്തൽ' },
  'asmt.question': { English: 'Question', Tamil: 'கேள்வி', Hindi: 'प्रश्न', Malayalam: 'ചോദ്യം' },
  'asmt.start': { English: 'Start assessment', Tamil: 'மதிப்பீட்டைத் தொடங்கு', Hindi: 'मूल्यांकन शुरू करें', Malayalam: 'വിലയിരുത്തൽ ആരംഭിക്കുക' },
  'asmt.resume': { English: 'Resume assessment', Tamil: 'மதிப்பீட்டைத் தொடர்க', Hindi: 'मूल्यांकन जारी रखें', Malayalam: 'വിലയിരുത്തൽ തുടരുക' },
  'asmt.resumeQ': { English: 'Resume assessment?', Tamil: 'மதிப்பீட்டைத் தொடரவா?', Hindi: 'मूल्यांकन जारी रखें?', Malayalam: 'വിലയിരുത്തൽ തുടരണോ?' },
  'asmt.startOver': { English: 'Start over', Tamil: 'மீண்டும் தொடங்கு', Hindi: 'फिर से शुरू करें', Malayalam: 'വീണ്ടും തുടങ്ങുക' },
  'asmt.completed': { English: 'Assessment completed', Tamil: 'மதிப்பீடு முடிந்தது', Hindi: 'मूल्यांकन पूरा हुआ', Malayalam: 'വിലയിരുത്തൽ പൂർത്തിയായി' },
  'asmt.answered': { English: 'Questions answered', Tamil: 'பதிலளித்த கேள்விகள்', Hindi: 'उत्तर दिए गए प्रश्न', Malayalam: 'ഉത്തരം നൽകിയ ചോദ്യങ്ങൾ' },
  'asmt.profile': { English: 'Profile generated', Tamil: 'சுயவிவரம் உருவாக்கப்பட்டது', Hindi: 'प्रोफ़ाइल बनाई गई', Malayalam: 'പ്രൊഫൈൽ തയ്യാറായി' },
  'asmt.nextStep': { English: 'Next step', Tamil: 'அடுத்த படி', Hindi: 'अगला कदम', Malayalam: 'അടുത്ത ഘട്ടം' },
  'asmt.viewResults': { English: 'View my results', Tamil: 'என் முடிவுகளைக் காண', Hindi: 'मेरे परिणाम देखें', Malayalam: 'എന്റെ ഫലങ്ങൾ കാണുക' },

  // Results
  'res.title': { English: 'Your career match', Tamil: 'உங்கள் தொழில் பொருத்தம்', Hindi: 'आपका करियर मैच', Malayalam: 'നിങ്ങളുടെ കരിയർ മാച്ച്' },
  'res.profile': { English: 'Career interest profile', Tamil: 'தொழில் ஆர்வ சுயவிவரம்', Hindi: 'करियर रुचि प्रोफ़ाइल', Malayalam: 'കരിയർ താൽപ്പര്യ പ്രൊഫൈൽ' },
  'res.strengths': { English: 'Your strengths', Tamil: 'உங்கள் பலங்கள்', Hindi: 'आपकी ताकत', Malayalam: 'നിങ്ങളുടെ ശക്തികൾ' },
  'res.confidence': { English: 'Skill confidence', Tamil: 'திறன் நம்பிக்கை', Hindi: 'कौशल आत्मविश्वास', Malayalam: 'നൈപുണ്യ ആത്മവിശ്വാസം' },
  'res.recommended': { English: 'Recommended careers', Tamil: 'பரிந்துரைக்கப்பட்ட தொழில்கள்', Hindi: 'अनुशंसित करियर', Malayalam: 'ശുപാർശ ചെയ്ത കരിയറുകൾ' },
  'res.why': { English: 'Why it matches', Tamil: 'ஏன் பொருந்துகிறது', Hindi: 'यह क्यों मेल खाता है', Malayalam: 'എന്തുകൊണ്ട് ചേരുന്നു' },
  'res.match': { English: 'Profile match', Tamil: 'சுயவிவர பொருத்தம்', Hindi: 'प्रोफ़ाइल मैच', Malayalam: 'പ്രൊഫൈൽ മാച്ച്' },
  'res.compare': { English: 'Compare', Tamil: 'ஒப்பிடு', Hindi: 'तुलना करें', Malayalam: 'താരതമ്യം' },
  'res.explore': { English: 'Explore this career', Tamil: 'இந்த தொழிலை ஆராய', Hindi: 'यह करियर देखें', Malayalam: 'ഈ കരിയർ പര്യവേക്ഷണം ചെയ്യുക' },

  // Skill gap & roadmap
  'gap.title': { English: 'Skill gap', Tamil: 'திறன் இடைவெளி', Hindi: 'कौशल अंतर', Malayalam: 'നൈപുണ്യ വിടവ്' },
  'gap.strong': { English: 'Strong', Tamil: 'வலிமையானது', Hindi: 'मज़बूत', Malayalam: 'ശക്തം' },
  'gap.developing': { English: 'Developing', Tamil: 'வளர்ந்து வருகிறது', Hindi: 'विकासशील', Malayalam: 'വികസിക്കുന്നു' },
  'gap.needs': { English: 'Needs Improvement', Tamil: 'மேம்பாடு தேவை', Hindi: 'सुधार आवश्यक', Malayalam: 'മെച്ചപ്പെടുത്തണം' },
  'gap.build': { English: 'Build my roadmap', Tamil: 'என் திட்டவரைபடத்தை உருவாக்கு', Hindi: 'मेरा रोडमैप बनाएँ', Malayalam: 'എന്റെ റോഡ്‌മാപ്പ് ഉണ്ടാക്കുക' },
  'road.title': { English: 'My roadmap', Tamil: 'என் திட்டவரைபடம்', Hindi: 'मेरा रोडमैप', Malayalam: 'എന്റെ റോഡ്‌മാപ്പ്' },
  'road.progress': { English: 'Roadmap progress', Tamil: 'திட்ட முன்னேற்றம்', Hindi: 'रोडमैप प्रगति', Malayalam: 'റോഡ്‌മാപ്പ് പുരോഗതി' },
  'road.markComplete': { English: 'Mark as complete', Tamil: 'முடிந்ததாகக் குறி', Hindi: 'पूर्ण चिह्नित करें', Malayalam: 'പൂർത്തിയായി അടയാളപ്പെടുത്തുക' },
  'road.markIncomplete': { English: 'Mark as not done', Tamil: 'முடிக்கவில்லை எனக் குறி', Hindi: 'अपूर्ण चिह्नित करें', Malayalam: 'പൂർത്തിയായില്ല എന്ന് അടയാളപ്പെടുത്തുക' },

  // Institutions / academies
  'inst.title': { English: 'Institutions', Tamil: 'நிறுவனங்கள்', Hindi: 'संस्थान', Malayalam: 'സ്ഥാപനങ്ങൾ' },
  'inst.nearby': { English: 'Nearby', Tamil: 'அருகில்', Hindi: 'नज़दीक', Malayalam: 'അടുത്ത്' },
  'acad.title': { English: 'Academies', Tamil: 'அகாடமிகள்', Hindi: 'अकादमियाँ', Malayalam: 'അക്കാദമികൾ' },
  'filter.career': { English: 'Career', Tamil: 'தொழில்', Hindi: 'करियर', Malayalam: 'കരിയർ' },
  'filter.location': { English: 'Location', Tamil: 'இடம்', Hindi: 'स्थान', Malayalam: 'സ്ഥലം' },
  'filter.level': { English: 'Level', Tamil: 'நிலை', Hindi: 'स्तर', Malayalam: 'നിലവാരം' },
  'filter.all': { English: 'All', Tamil: 'அனைத்தும்', Hindi: 'सभी', Malayalam: 'എല്ലാം' },

  // Clarity
  'clarity.title': { English: 'Career clarity check', Tamil: 'தொழில் தெளிவு சோதனை', Hindi: 'करियर स्पष्टता जाँच', Malayalam: 'കരിയർ വ്യക്തതാ പരിശോധന' },
  'clarity.score': { English: 'Career clarity', Tamil: 'தொழில் தெளிவு', Hindi: 'करियर स्पष्टता', Malayalam: 'കരിയർ വ്യക്തത' },
  'clarity.q1': { English: 'How clear are you about your career direction now?', Tamil: 'உங்கள் தொழில் திசை இப்போது எவ்வளவு தெளிவாக உள்ளது?', Hindi: 'अब आपकी करियर दिशा कितनी स्पष्ट है?', Malayalam: 'ഇപ്പോൾ കരിയർ ദിശ എത്ര വ്യക്തമാണ്?' },
  'clarity.q2': { English: 'Do you understand which skills you need to develop?', Tamil: 'எந்த திறன்களை வளர்க்க வேண்டும் என்று புரிகிறதா?', Hindi: 'क्या आप समझते हैं कौन से कौशल विकसित करने हैं?', Malayalam: 'ഏതു നൈപുണ്യങ്ങൾ വളർത്തണമെന്ന് മനസ്സിലായോ?' },
  'clarity.q3': { English: 'Do you know which career path you want to explore?', Tamil: 'எந்த தொழில் பாதையை ஆராய விரும்புகிறீர்கள் என்று தெரியுமா?', Hindi: 'क्या आप जानते हैं कौन सा करियर पथ देखना है?', Malayalam: 'ഏത് കരിയർ പാത പര്യവേക്ഷണം ചെയ്യണമെന്ന് അറിയാമോ?' },
  'clarity.q4': { English: 'Do you feel confident about your next step?', Tamil: 'உங்கள் அடுத்த படி குறித்து நம்பிக்கை உள்ளதா?', Hindi: 'क्या आप अगले कदम को लेकर आश्वस्त हैं?', Malayalam: 'അടുത്ത ഘട്ടത്തിൽ ആത്മവിശ്വാസമുണ്ടോ?' },
  'clarity.relevance': { English: 'Does this recommendation feel relevant to you?', Tamil: 'இந்த பரிந்துரை உங்களுக்குப் பொருத்தமாக உள்ளதா?', Hindi: 'क्या यह सिफ़ारिश आपके लिए प्रासंगिक लगती है?', Malayalam: 'ഈ ശുപാർശ നിങ്ങൾക്ക് പ്രസക്തമായി തോന്നുന്നുണ്ടോ?' },
  'clarity.yes': { English: 'Yes', Tamil: 'ஆம்', Hindi: 'हाँ', Malayalam: 'അതെ' },
  'clarity.maybe': { English: 'Maybe', Tamil: 'ஒருவேளை', Hindi: 'शायद', Malayalam: 'ഒരുപക്ഷേ' },
  'clarity.no': { English: 'No', Tamil: 'இல்லை', Hindi: 'नहीं', Malayalam: 'ഇല്ല' },
  'clarity.before': { English: 'Before SkillBridgeAI', Tamil: 'SkillBridgeAI-க்கு முன்', Hindi: 'SkillBridgeAI से पहले', Malayalam: 'SkillBridgeAI-ന് മുൻപ്' },
  'clarity.after': { English: 'After SkillBridgeAI', Tamil: 'SkillBridgeAI-க்கு பின்', Hindi: 'SkillBridgeAI के बाद', Malayalam: 'SkillBridgeAI-ന് ശേഷം' },

  // Dashboard & profile
  'dash.welcome': { English: 'Welcome back', Tamil: 'மீண்டும் வருக', Hindi: 'वापसी पर स्वागत', Malayalam: 'വീണ്ടും സ്വാഗതം' },
  'dash.journey': { English: 'Your journey starts here.', Tamil: 'உங்கள் பயணம் இங்கே தொடங்குகிறது.', Hindi: 'आपकी यात्रा यहाँ शुरू होती है।', Malayalam: 'നിങ്ങളുടെ യാത്ര ഇവിടെ തുടങ്ങുന്നു.' },
  'dash.completeAssessment': { English: 'Complete your assessment', Tamil: 'உங்கள் மதிப்பீட்டை முடிக்கவும்', Hindi: 'अपना मूल्यांकन पूरा करें', Malayalam: 'വിലയിരുത്തൽ പൂർത്തിയാക്കുക' },
  'dash.continueRoadmap': { English: 'Continue my roadmap', Tamil: 'என் திட்டத்தைத் தொடர்க', Hindi: 'मेरा रोडमैप जारी रखें', Malayalam: 'എന്റെ റോഡ്‌മാപ്പ് തുടരുക' },
  'dash.topMatch': { English: 'Your top career match', Tamil: 'உங்கள் சிறந்த தொழில் பொருத்தம்', Hindi: 'आपका शीर्ष करियर मैच', Malayalam: 'നിങ്ങളുടെ മികച്ച കരിയർ മാച്ച്' },
  'dash.institutions': { English: 'Recommended institutions', Tamil: 'பரிந்துரைக்கப்பட்ட நிறுவனங்கள்', Hindi: 'अनुशंसित संस्थान', Malayalam: 'ശുപാർശ ചെയ്ത സ്ഥാപനങ്ങൾ' },
  'dash.academies': { English: 'Recommended academies', Tamil: 'பரிந்துரைக்கப்பட்ட அகாடமிகள்', Hindi: 'अनुशंसित अकादमियाँ', Malayalam: 'ശുപാർശ ചെയ്ത അക്കാദമികൾ' },
  'prof.title': { English: 'Profile & settings', Tamil: 'சுயவிவரம் & அமைப்புகள்', Hindi: 'प्रोफ़ाइल और सेटिंग्स', Malayalam: 'പ്രൊഫൈൽ & ക്രമീകരണങ്ങൾ' },
  'prof.edit': { English: 'Edit profile', Tamil: 'சுயவிவரத்தைத் திருத்து', Hindi: 'प्रोफ़ाइल संपादित करें', Malayalam: 'പ്രൊഫൈൽ എഡിറ്റ് ചെയ്യുക' },
  'prof.changeAvatar': { English: 'Change avatar', Tamil: 'அவதாரத்தை மாற்று', Hindi: 'अवतार बदलें', Malayalam: 'അവതാർ മാറ്റുക' },
  'prof.language': { English: 'Language', Tamil: 'மொழி', Hindi: 'भाषा', Malayalam: 'ഭാഷ' },
  'prof.privacy': { English: 'Privacy', Tamil: 'தனியுரிமை', Hindi: 'गोपनीयता', Malayalam: 'സ്വകാര്യത' },
  'prof.terms': { English: 'Terms of use', Tamil: 'பயன்பாட்டு விதிகள்', Hindi: 'उपयोग की शर्तें', Malayalam: 'ഉപയോഗ നിബന്ധനകൾ' },
  'prof.logout': { English: 'Log out', Tamil: 'வெளியேறு', Hindi: 'लॉग आउट', Malayalam: 'ലോഗ് ഔട്ട്' },
  'saved.title': { English: 'Saved items', Tamil: 'சேமித்தவை', Hindi: 'सहेजे गए आइटम', Malayalam: 'സേവ് ചെയ്തവ' }
};