import type { LanguageCode } from './ui';

type Entry = Record<LanguageCode, string>;

/**
 * Assessment questions, options and rating labels.
 * Keys: `q.<questionId>` for titles, `o.<questionId>.<optionId>` for options,
 * `i.<questionId>.<itemId>` for rating rows.
 */
export const ASSESSMENT_STRINGS: Record<string, Entry> = {
  'q.interest': {
    English: 'Which areas are you most curious to explore?',
    Tamil: 'எந்தத் துறைகளை ஆராய நீங்கள் அதிகம் ஆர்வமாக உள்ளீர்கள்?',
    Hindi: 'आप किन क्षेत्रों को जानने में सबसे अधिक उत्सुक हैं?',
    Malayalam: 'ഏതൊക്കെ മേഖലകൾ പര്യവേക്ഷണം ചെയ്യാൻ നിങ്ങൾക്ക് താൽപ്പര്യമുണ്ട്?'
  },
  'o.interest.tech': { English: 'Technology & AI', Tamil: 'தொழில்நுட்பம் & AI', Hindi: 'तकनीक और AI', Malayalam: 'സാങ്കേതികവിദ്യ & AI' },
  'o.interest.design': { English: 'Design & Creativity', Tamil: 'வடிவமைப்பு & படைப்பாற்றல்', Hindi: 'डिज़ाइन और रचनात्मकता', Malayalam: 'ഡിസൈൻ & സർഗ്ഗാത്മകത' },
  'o.interest.business': { English: 'Business & Management', Tamil: 'வணிகம் & மேலாண்மை', Hindi: 'व्यवसाय और प्रबंधन', Malayalam: 'ബിസിനസ് & മാനേജ്‌മെന്റ്' },
  'o.interest.data': { English: 'Data & Analytics', Tamil: 'தரவு & பகுப்பாய்வு', Hindi: 'डेटा और एनालिटिक्स', Malayalam: 'ഡാറ്റ & അനലിറ്റിക്‌സ്' },
  'o.interest.science': { English: 'Science & Research', Tamil: 'அறிவியல் & ஆராய்ச்சி', Hindi: 'विज्ञान और शोध', Malayalam: 'ശാസ്ത്രം & ഗവേഷണം' },
  'o.interest.media': { English: 'Media & Communication', Tamil: 'ஊடகம் & தொடர்பு', Hindi: 'मीडिया और संचार', Malayalam: 'മീഡിയ & കമ്മ്യൂണിക്കേഷൻ' },

  'q.activity': {
    English: 'What kind of activity would you naturally enjoy spending time on?',
    Tamil: 'எந்த வகையான செயலில் நேரம் செலவிட நீங்கள் இயல்பாக விரும்புவீர்கள்?',
    Hindi: 'आप स्वाभाविक रूप से किस तरह की गतिविधि में समय बिताना पसंद करेंगे?',
    Malayalam: 'ഏത് തരം പ്രവർത്തനത്തിൽ സമയം ചെലവഴിക്കാനാണ് നിങ്ങൾക്ക് ഇഷ്ടം?'
  },
  'o.activity.designing': { English: 'Designing & creating', Tamil: 'வடிவமைத்தல் & உருவாக்குதல்', Hindi: 'डिज़ाइन और सृजन', Malayalam: 'ഡിസൈൻ & നിർമ്മാണം' },
  'o.activity.coding': { English: 'Building & coding', Tamil: 'கட்டமைத்தல் & குறியீடு', Hindi: 'बनाना और कोडिंग', Malayalam: 'നിർമ്മാണം & കോഡിംഗ്' },
  'o.activity.solving': { English: 'Solving problems', Tamil: 'சிக்கல்களைத் தீர்த்தல்', Hindi: 'समस्याएँ हल करना', Malayalam: 'പ്രശ്നപരിഹാരം' },
  'o.activity.analysing': { English: 'Analysing data', Tamil: 'தரவை பகுப்பாய்வு செய்தல்', Hindi: 'डेटा का विश्लेषण', Malayalam: 'ഡാറ്റ വിശകലനം' },
  'o.activity.people': { English: 'Helping & working with people', Tamil: 'மக்களுடன் பணியாற்றுதல்', Hindi: 'लोगों की मदद और उनके साथ काम', Malayalam: 'ആളുകളെ സഹായിക്കുക' },
  'o.activity.research': { English: 'Researching & exploring', Tamil: 'ஆராய்ச்சி & ஆய்வு', Hindi: 'शोध और खोज', Malayalam: 'ഗവേഷണം & പര്യവേക്ഷണം' },

  'q.project': {
    English: 'Which type of project would excite you the most?',
    Tamil: 'எந்த வகையான திட்டம் உங்களை அதிகம் உற்சாகப்படுத்தும்?',
    Hindi: 'किस तरह की परियोजना आपको सबसे अधिक उत्साहित करेगी?',
    Malayalam: 'ഏത് തരം പ്രോജക്റ്റാണ് നിങ്ങളെ ഏറ്റവും ആവേശഭരിതരാക്കുക?'
  },
  'o.project.app': { English: 'Building an app or website', Tamil: 'செயலி அல்லது வலைத்தளம் உருவாக்குதல்', Hindi: 'ऐप या वेबसाइट बनाना', Malayalam: 'ആപ്പ് അല്ലെങ്കിൽ വെബ്‌സൈറ്റ് നിർമ്മാണം' },
  'o.project.digital': { English: 'Designing a digital product', Tamil: 'டிஜிட்டல் தயாரிப்பை வடிவமைத்தல்', Hindi: 'डिजिटल उत्पाद डिज़ाइन करना', Malayalam: 'ഡിജിറ്റൽ ഉൽപ്പന്നം ഡിസൈൻ ചെയ്യുക' },
  'o.project.realdata': { English: 'Analysing real-world data', Tamil: 'நிஜ உலக தரவை பகுப்பாய்வு', Hindi: 'वास्तविक डेटा का विश्लेषण', Malayalam: 'യഥാർത്ഥ ഡാറ്റ വിശകലനം' },
  'o.project.social': { English: 'Solving a social problem', Tamil: 'சமூக பிரச்சினையைத் தீர்த்தல்', Hindi: 'सामाजिक समस्या हल करना', Malayalam: 'സാമൂഹിക പ്രശ്നം പരിഹരിക്കുക' },
  'o.project.innovative': { English: 'Creating something innovative', Tamil: 'புதுமையான ஒன்றை உருவாக்குதல்', Hindi: 'कुछ नवाचारी बनाना', Malayalam: 'നൂതനമായ എന്തെങ്കിലും സൃഷ്ടിക്കുക' },
  'o.project.team': { English: 'Leading a team project', Tamil: 'குழு திட்டத்தை வழிநடத்துதல்', Hindi: 'टीम परियोजना का नेतृत्व', Malayalam: 'ടീം പ്രോജക്റ്റ് നയിക്കുക' },

  'q.scenario_ideas': {
    English: 'Your team has two different ideas with strong arguments. What would you most likely do?',
    Tamil: 'உங்கள் குழுவில் இரு வேறுபட்ட வலுவான யோசனைகள் உள்ளன. நீங்கள் என்ன செய்வீர்கள்?',
    Hindi: 'आपकी टीम में दो अलग-अलग मज़बूत विचार हैं। आप क्या करेंगे?',
    Malayalam: 'നിങ്ങളുടെ ടീമിൽ ശക്തമായ രണ്ട് ആശയങ്ങളുണ്ട്. നിങ്ങൾ എന്ത് ചെയ്യും?'
  },
  'o.scenario_ideas.evidence': { English: 'Choose the idea with stronger evidence', Tamil: 'வலுவான சான்று உள்ள யோசனையைத் தேர்வு', Hindi: 'मज़बूत प्रमाण वाला विचार चुनें', Malayalam: 'ശക്തമായ തെളിവുള്ള ആശയം തിരഞ്ഞെടുക്കുക' },
  'o.scenario_ideas.combine': { English: 'Combine both ideas', Tamil: 'இரு யோசனைகளையும் இணைக்க', Hindi: 'दोनों विचारों को मिलाएँ', Malayalam: 'രണ്ട് ആശയങ്ങളും സംയോജിപ്പിക്കുക' },
  'o.scenario_ideas.discuss': { English: 'Discuss and decide together', Tamil: 'விவாதித்து ஒன்றாக முடிவெடுக்க', Hindi: 'चर्चा कर साथ में तय करें', Malayalam: 'ചർച്ച ചെയ്ത് ഒരുമിച്ച് തീരുമാനിക്കുക' },
  'o.scenario_ideas.prototype': { English: 'Build quick versions and compare', Tamil: 'விரைவு பதிப்புகளை உருவாக்கி ஒப்பிட', Hindi: 'त्वरित संस्करण बनाकर तुलना करें', Malayalam: 'വേഗത്തിൽ പതിപ്പുകൾ ഉണ്ടാക്കി താരതമ്യം ചെയ്യുക' },

  'q.scenario_deadline': {
    English: 'A project is behind schedule two days before the deadline. What is your first move?',
    Tamil: 'காலக்கெடுவுக்கு இரண்டு நாட்கள் முன் திட்டம் பின்தங்கியுள்ளது. உங்கள் முதல் நடவடிக்கை?',
    Hindi: 'समय-सीमा से दो दिन पहले परियोजना पीछे है। आपका पहला कदम?',
    Malayalam: 'അവസാന തീയതിക്ക് രണ്ട് ദിവസം മുൻപ് പ്രോജക്റ്റ് പിന്നിലാണ്. നിങ്ങളുടെ ആദ്യ നടപടി?'
  },
  'o.scenario_deadline.replan': { English: 'Re-plan the work and assign priorities', Tamil: 'வேலையை மறுதிட்டமிட்டு முன்னுரிமை வழங்க', Hindi: 'काम की फिर से योजना बनाकर प्राथमिकता दें', Malayalam: 'ജോലി വീണ്ടും ആസൂത്രണം ചെയ്ത് മുൻഗണന നൽകുക' },
  'o.scenario_deadline.root': { English: 'Find the root cause of the delay', Tamil: 'தாமதத்தின் மூல காரணத்தைக் கண்டறிய', Hindi: 'देरी का मूल कारण खोजें', Malayalam: 'കാലതാമസത്തിന്റെ മൂലകാരണം കണ്ടെത്തുക' },
  'o.scenario_deadline.help': { English: 'Check in with teammates who are stuck', Tamil: 'சிக்கலில் உள்ள சகாக்களுடன் பேச', Hindi: 'अटके साथियों से बात करें', Malayalam: 'കുടുങ്ങിയ സഹപ്രവർത്തകരോട് സംസാരിക്കുക' },
  'o.scenario_deadline.ship': { English: 'Cut scope and ship the essential part', Tamil: 'நோக்கத்தை குறைத்து முக்கியப் பகுதியை வழங்க', Hindi: 'दायरा घटाकर ज़रूरी हिस्सा दें', Malayalam: 'വ്യാപ്തി കുറച്ച് പ്രധാന ഭാഗം നൽകുക' },

  'q.rate_core': {
    English: 'How would you rate yourself right now?',
    Tamil: 'இப்போது உங்களை எப்படி மதிப்பிடுவீர்கள்?',
    Hindi: 'अभी आप स्वयं को कैसे आँकेंगे?',
    Malayalam: 'ഇപ്പോൾ നിങ്ങൾ സ്വയം എങ്ങനെ വിലയിരുത്തും?'
  },
  'i.rate_core.communication': { English: 'Communication', Tamil: 'தொடர்பு திறன்', Hindi: 'संचार', Malayalam: 'ആശയവിനിമയം' },
  'i.rate_core.problem_solving': { English: 'Problem solving', Tamil: 'சிக்கல் தீர்த்தல்', Hindi: 'समस्या समाधान', Malayalam: 'പ്രശ്നപരിഹാരം' },
  'i.rate_core.creativity': { English: 'Creativity', Tamil: 'படைப்பாற்றல்', Hindi: 'रचनात्मकता', Malayalam: 'സർഗ്ഗാത്മകത' },
  'i.rate_core.leadership': { English: 'Leadership', Tamil: 'தலைமைத்துவம்', Hindi: 'नेतृत्व', Malayalam: 'നേതൃത്വം' },

  'q.rate_more': {
    English: 'A few more about how you work',
    Tamil: 'நீங்கள் எப்படி வேலை செய்கிறீர்கள் என்பது பற்றி மேலும் சில',
    Hindi: 'आप कैसे काम करते हैं, इस पर कुछ और',
    Malayalam: 'നിങ്ങൾ എങ്ങനെ പ്രവർത്തിക്കുന്നു എന്നതിനെക്കുറിച്ച് കുറച്ചുകൂടി'
  },
  'i.rate_more.analytical': { English: 'Analytical thinking', Tamil: 'பகுப்பாய்வு சிந்தனை', Hindi: 'विश्लेषणात्मक सोच', Malayalam: 'വിശകലന ചിന്ത' },
  'i.rate_more.technical': { English: 'Technical confidence', Tamil: 'தொழில்நுட்ப நம்பிக்கை', Hindi: 'तकनीकी आत्मविश्वास', Malayalam: 'സാങ്കേതിക ആത്മവിശ്വാസം' },
  'i.rate_more.teamwork': { English: 'Teamwork', Tamil: 'குழுப்பணி', Hindi: 'टीम वर्क', Malayalam: 'ടീം വർക്ക്' },
  'i.rate_more.research': { English: 'Research ability', Tamil: 'ஆராய்ச்சி திறன்', Hindi: 'शोध क्षमता', Malayalam: 'ഗവേഷണ ശേഷി' },

  'q.confidence_tools': {
    English: 'How confident are you with these today?',
    Tamil: 'இன்று இவற்றில் உங்களுக்கு எவ்வளவு நம்பிக்கை?',
    Hindi: 'आज आप इनमें कितने आश्वस्त हैं?',
    Malayalam: 'ഇന്ന് ഇവയിൽ നിങ്ങൾക്ക് എത്ര ആത്മവിശ്വാസമുണ്ട്?'
  },
  'i.confidence_tools.coding_conf': { English: 'Writing code or scripts', Tamil: 'குறியீடு எழுதுதல்', Hindi: 'कोड लिखना', Malayalam: 'കോഡ് എഴുതൽ' },
  'i.confidence_tools.design_conf': { English: 'Designing screens or visuals', Tamil: 'திரைகள் வடிவமைத்தல்', Hindi: 'स्क्रीन डिज़ाइन करना', Malayalam: 'സ്‌ക്രീൻ ഡിസൈൻ' },
  'i.confidence_tools.data_conf': { English: 'Working with numbers and data', Tamil: 'எண்கள் & தரவுடன் பணி', Hindi: 'संख्या और डेटा के साथ काम', Malayalam: 'സംഖ്യകളും ഡാറ്റയും' },
  'i.confidence_tools.present_conf': { English: 'Presenting ideas to a group', Tamil: 'குழுவில் யோசனைகளை முன்வைத்தல்', Hindi: 'समूह में विचार प्रस्तुत करना', Malayalam: 'ഗ്രൂപ്പിൽ ആശയങ്ങൾ അവതരിപ്പിക്കൽ' },

  'q.environment': {
    English: 'Where would you do your best work?',
    Tamil: 'எங்கு நீங்கள் சிறப்பாக வேலை செய்வீர்கள்?',
    Hindi: 'आप अपना सर्वश्रेष्ठ कार्य कहाँ करेंगे?',
    Malayalam: 'നിങ്ങൾ ഏറ്റവും നന്നായി പ്രവർത്തിക്കുന്നത് എവിടെ?'
  },
  'o.environment.lab': { English: 'A research lab or study group', Tamil: 'ஆராய்ச்சி ஆய்வகம் அல்லது படிப்புக் குழு', Hindi: 'शोध प्रयोगशाला या अध्ययन समूह', Malayalam: 'ഗവേഷണ ലാബ് അല്ലെങ്കിൽ പഠന ഗ്രൂപ്പ്' },
  'o.environment.startup': { English: 'A fast-moving product team', Tamil: 'வேகமான தயாரிப்புக் குழு', Hindi: 'तेज़ी से चलती प्रोडक्ट टीम', Malayalam: 'വേഗതയേറിയ പ്രോഡക്റ്റ് ടീം' },
  'o.environment.studio': { English: 'A creative studio', Tamil: 'படைப்பாற்றல் ஸ்டுடியோ', Hindi: 'क्रिएटिव स्टूडियो', Malayalam: 'ക്രിയേറ്റീവ് സ്റ്റുഡിയോ' },
  'o.environment.enterprise': { English: 'A structured organisation', Tamil: 'கட்டமைக்கப்பட்ட நிறுவனம்', Hindi: 'संरचित संगठन', Malayalam: 'ചിട്ടയായ സ്ഥാപനം' },

  'q.motivation': {
    English: 'What matters most in your first job?',
    Tamil: 'உங்கள் முதல் வேலையில் மிக முக்கியமானது எது?',
    Hindi: 'आपकी पहली नौकरी में सबसे ज़रूरी क्या है?',
    Malayalam: 'നിങ്ങളുടെ ആദ്യ ജോലിയിൽ ഏറ്റവും പ്രധാനം എന്ത്?'
  },
  'o.motivation.learning': { English: 'Learning deeply in one field', Tamil: 'ஒரு துறையில் ஆழமாகக் கற்றல்', Hindi: 'एक क्षेत्र में गहराई से सीखना', Malayalam: 'ഒരു മേഖലയിൽ ആഴത്തിൽ പഠിക്കുക' },
  'o.motivation.impact': { English: 'Seeing real impact from my work', Tamil: 'என் வேலையின் உண்மையான தாக்கம்', Hindi: 'काम का वास्तविक प्रभाव देखना', Malayalam: 'ജോലിയുടെ യഥാർത്ഥ ഫലം കാണുക' },
  'o.motivation.build': { English: 'Building things people use', Tamil: 'மக்கள் பயன்படுத்துவதை உருவாக்குதல்', Hindi: 'ऐसी चीज़ें बनाना जो लोग उपयोग करें', Malayalam: 'ആളുകൾ ഉപയോഗിക്കുന്നത് നിർമ്മിക്കുക' },
  'o.motivation.lead': { English: 'Growing into a leadership role', Tamil: 'தலைமைப் பொறுப்புக்கு வளர்தல்', Hindi: 'नेतृत्व की भूमिका में बढ़ना', Malayalam: 'നേതൃത്വ റോളിലേക്ക് വളരുക' }
};