import { useCallback } from 'react';
import { UI } from './ui';
import type { LanguageCode } from './ui';
import { ASSESSMENT_STRINGS } from './assessmentStrings';
import { useUser } from '../contexts/UserContext';

export type { LanguageCode };
export { LANGUAGE_CODES, LANGUAGE_NATIVE } from './ui';

const TABLE: Record<string, Record<LanguageCode, string>> = { ...UI, ...ASSESSMENT_STRINGS };

export function translate(key: string, language: LanguageCode, fallback?: string): string {
  const entry = TABLE[key];
  if (!entry) return fallback ?? key;
  return entry[language] || entry.English || fallback || key;
}

/** Reads the language stored on the user profile and returns a `t()` helper. */
export function useT() {
  const { profile } = useUser();
  const language = profile.language as LanguageCode || 'English';
  const t = useCallback(
    (key: string, fallback?: string) => translate(key, language, fallback),
    [language]
  );
  return { t, language };
}