import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { XIcon } from 'lucide-react';
import { Button } from './ui/Button';
import { TextField } from './ui/TextField';
import { useT } from '../i18n';

export type AuthProvider = 'google' | 'microsoft';

interface AuthAccountSheetProps {
  provider: AuthProvider;
  onClose: () => void;
  onSelect: (account: {name: string;email: string;}) => void;
}

const DEMO_ACCOUNTS = [
{ name: 'Jayashree R', email: 'jayashree@example.com' },
{ name: 'Arun Kumar', email: 'arun.k@example.com' }];


const PROVIDER_LABEL: Record<AuthProvider, string> = {
  google: 'Google',
  microsoft: 'Microsoft'
};

/**
 * Simulated OAuth account chooser for the MVP. No real provider credentials are
 * used — this mirrors the familiar pattern so the flow can be demonstrated.
 */
export function AuthAccountSheet({ provider, onClose, onSelect }: AuthAccountSheetProps) {
  const { t } = useT();
  const [manual, setManual] = useState(false);
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  const submitManual = () => {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError(t('err.email'));
      return;
    }
    onSelect({ name: email.split('@')[0].replace(/\b\w/g, (c) => c.toUpperCase()), email });
  };

  return (
    <div
      className="absolute inset-0 z-50 flex items-end bg-navy/50 px-3 pb-3"
      role="dialog"
      aria-modal="true"
      aria-labelledby="account-sheet-title">
      
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.22, ease: [0.23, 1, 0.32, 1] }}
        className="w-full overflow-hidden rounded-2xl bg-white shadow-lift">
        
        <div className="flex items-center gap-3 border-b border-hairline px-4 py-3.5">
          <span className="flex h-8 w-8 items-center justify-center rounded-full bg-canvas">
            {provider === 'google' ?
            <svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true">
                <path fill="#4285F4" d="M23 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.2a5.3 5.3 0 0 1-2.3 3.5v2.9h3.7c2.2-2 3.4-5 3.4-8.6Z" />
                <path fill="#34A853" d="M12 23.5c3.1 0 5.7-1 7.6-2.8l-3.7-2.9c-1 .7-2.3 1.1-3.9 1.1-3 0-5.5-2-6.4-4.7H1.8v3A11.5 11.5 0 0 0 12 23.5Z" />
                <path fill="#FBBC05" d="M5.6 14.2a6.9 6.9 0 0 1 0-4.4v-3H1.8a11.5 11.5 0 0 0 0 10.4l3.8-3Z" />
                <path fill="#EA4335" d="M12 5.4c1.7 0 3.2.6 4.4 1.7l3.3-3.3A11.5 11.5 0 0 0 1.8 6.8l3.8 3c.9-2.7 3.4-4.4 6.4-4.4Z" />
              </svg> :

            <svg width="15" height="15" viewBox="0 0 23 23" aria-hidden="true">
                <path fill="#F25022" d="M1 1h10v10H1z" />
                <path fill="#7FBA00" d="M12 1h10v10H12z" />
                <path fill="#00A4EF" d="M1 12h10v10H1z" />
                <path fill="#FFB900" d="M12 12h10v10H12z" />
              </svg>
            }
          </span>
          <div className="min-w-0 flex-1">
            <h2 id="account-sheet-title" className="text-[15px] font-bold text-navy">
              {t('auth.chooseAccount')}
            </h2>
            <p className="truncate text-[12px] text-navy-muted">
              {PROVIDER_LABEL[provider]} · to continue to SkillBridgeAI
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="flex h-10 w-10 items-center justify-center rounded-full text-navy-muted hover:bg-canvas">
            
            <XIcon size={18} />
          </button>
        </div>

        {manual ?
        <div className="space-y-3 p-4">
            <TextField
            label={t('auth.email')}
            type="email"
            inputMode="email"
            placeholder="you@example.com"
            value={email}
            error={error}
            onChange={(e) => setEmail(e.target.value)} />
          
            <div className="flex gap-2.5">
              <Button variant="outline" onClick={() => setManual(false)}>
                {t('common.back')}
              </Button>
              <Button fullWidth onClick={submitManual}>
                {t('common.continue')}
              </Button>
            </div>
          </div> :

        <ul className="p-2">
            {DEMO_ACCOUNTS.map((account) =>
          <li key={account.email}>
                <button
              type="button"
              onClick={() => onSelect(account)}
              className="flex min-h-[60px] w-full items-center gap-3 rounded-xl px-3 text-left transition-colors duration-150 ease-out hover:bg-canvas">
              
                  <span className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-600 text-[14px] font-bold text-white">
                    {account.name.charAt(0)}
                  </span>
                  <span className="min-w-0">
                    <span className="block truncate text-[14px] font-semibold text-navy">{account.name}</span>
                    <span className="block truncate text-[12.5px] text-navy-muted">{account.email}</span>
                  </span>
                </button>
              </li>
          )}
            <li>
              <button
              type="button"
              onClick={() => setManual(true)}
              className="flex min-h-[56px] w-full items-center gap-3 rounded-xl px-3 text-left text-[14px] font-semibold text-brand-700 transition-colors duration-150 ease-out hover:bg-canvas">
              
                <span className="flex h-9 w-9 items-center justify-center rounded-full border border-hairline text-navy-muted">
                  +
                </span>
                {t('auth.useAnother')}
              </button>
            </li>
          </ul>
        }

        <p className="border-t border-hairline px-4 py-2.5 text-[11px] leading-relaxed text-navy-muted">
          Simulated sign-in for this prototype — no real {PROVIDER_LABEL[provider]} account is accessed.
        </p>
      </motion.div>
    </div>);

}