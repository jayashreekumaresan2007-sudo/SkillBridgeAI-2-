import React from 'react';
import { useT } from '../i18n';
import type { AuthProvider } from './AuthAccountSheet';

interface SocialAuthButtonsProps {
  onSelect: (provider: AuthProvider) => void;
}

/** Opens the simulated provider account chooser — no real OAuth in the MVP. */
export function SocialAuthButtons({ onSelect }: SocialAuthButtonsProps) {
  const { t } = useT();
  return (
    <div className="mt-6">
      <div className="flex items-center gap-3">
        <span className="h-px flex-1 bg-hairline" />
        <span className="text-[11.5px] font-medium uppercase tracking-wide text-navy-muted">
          {t('auth.orContinue')}
        </span>
        <span className="h-px flex-1 bg-hairline" />
      </div>
      <div className="mt-4 grid grid-cols-2 gap-3">
        <button
          type="button"
          onClick={() => onSelect('google')}
          className="flex min-h-[48px] items-center justify-center gap-2 rounded-xl border border-hairline bg-white text-[14px] font-semibold text-navy transition-colors duration-150 ease-out hover:bg-brand-50/60">
          
          <svg width="17" height="17" viewBox="0 0 24 24" aria-hidden="true">
            <path fill="#4285F4" d="M23 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.2a5.3 5.3 0 0 1-2.3 3.5v2.9h3.7c2.2-2 3.4-5 3.4-8.6Z" />
            <path fill="#34A853" d="M12 23.5c3.1 0 5.7-1 7.6-2.8l-3.7-2.9c-1 .7-2.3 1.1-3.9 1.1-3 0-5.5-2-6.4-4.7H1.8v3A11.5 11.5 0 0 0 12 23.5Z" />
            <path fill="#FBBC05" d="M5.6 14.2a6.9 6.9 0 0 1 0-4.4v-3H1.8a11.5 11.5 0 0 0 0 10.4l3.8-3Z" />
            <path fill="#EA4335" d="M12 5.4c1.7 0 3.2.6 4.4 1.7l3.3-3.3A11.5 11.5 0 0 0 1.8 6.8l3.8 3c.9-2.7 3.4-4.4 6.4-4.4Z" />
          </svg>
          Google
        </button>
        <button
          type="button"
          onClick={() => onSelect('microsoft')}
          className="flex min-h-[48px] items-center justify-center gap-2 rounded-xl border border-hairline bg-white text-[14px] font-semibold text-navy transition-colors duration-150 ease-out hover:bg-brand-50/60">
          
          <svg width="16" height="16" viewBox="0 0 23 23" aria-hidden="true">
            <path fill="#F25022" d="M1 1h10v10H1z" />
            <path fill="#7FBA00" d="M12 1h10v10H12z" />
            <path fill="#00A4EF" d="M1 12h10v10H1z" />
            <path fill="#FFB900" d="M12 12h10v10H12z" />
          </svg>
          Microsoft
        </button>
      </div>
    </div>);

}