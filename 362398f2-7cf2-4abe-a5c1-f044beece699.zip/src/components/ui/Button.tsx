import React from 'react';

type Variant = 'primary' | 'secondary' | 'ghost' | 'outline' | 'danger';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  fullWidth?: boolean;
  loading?: boolean;
  icon?: React.ReactNode;
  iconRight?: React.ReactNode;
}

const VARIANTS: Record<Variant, string> = {
  primary: 'bg-brand-600 text-white hover:bg-brand-700 active:bg-brand-800 disabled:bg-brand-200',
  secondary: 'bg-brand-50 text-brand-700 hover:bg-brand-100 disabled:text-brand-300',
  outline: 'border border-hairline bg-white text-navy hover:border-brand-300 hover:bg-brand-50/60',
  ghost: 'text-brand-700 hover:bg-brand-50',
  danger: 'border border-badSoft bg-badSoft text-bad hover:bg-[#f6dedb]'
};

export function Button({
  variant = 'primary',
  fullWidth,
  loading,
  icon,
  iconRight,
  children,
  className = '',
  disabled,
  ...rest
}: ButtonProps) {
  return (
    <button
      {...rest}
      disabled={disabled || loading}
      className={`inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl px-5 text-[15px] font-semibold transition-colors duration-150 ease-out disabled:cursor-not-allowed ${
      VARIANTS[variant]} ${
      fullWidth ? 'w-full' : ''} ${className}`}>
      
      {loading ?
      <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" aria-hidden="true" /> :

      icon
      }
      <span>{children}</span>
      {!loading && iconRight}
    </button>);

}