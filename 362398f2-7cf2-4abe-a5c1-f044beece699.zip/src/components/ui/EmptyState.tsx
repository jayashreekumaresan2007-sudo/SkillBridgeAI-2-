import React from 'react';
import { SearchXIcon } from 'lucide-react';

interface EmptyStateProps {
  title: string;
  message: string;
  icon?: React.ReactNode;
  action?: React.ReactNode;
}

export function EmptyState({ title, message, icon, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center rounded-2xl border border-dashed border-hairline bg-white px-6 py-10 text-center">
      <span className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-brand-50 text-brand-600">
        {icon ?? <SearchXIcon size={22} />}
      </span>
      <h3 className="text-[15px] font-semibold text-navy">{title}</h3>
      <p className="mt-1.5 max-w-[260px] text-[13px] leading-relaxed text-navy-muted">{message}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>);

}