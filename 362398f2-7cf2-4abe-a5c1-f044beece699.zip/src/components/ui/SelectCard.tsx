import React from 'react';
import { CheckIcon } from 'lucide-react';

interface SelectCardProps {
  selected: boolean;
  onSelect: () => void;
  title: string;
  description?: string;
  icon?: React.ReactNode;
  layout?: 'row' | 'tile';
  multi?: boolean;
  disabled?: boolean;
}

export function SelectCard({
  selected,
  onSelect,
  title,
  description,
  icon,
  layout = 'row',
  multi = false,
  disabled
}: SelectCardProps) {
  return (
    <button
      type="button"
      role={multi ? 'checkbox' : 'radio'}
      aria-checked={selected}
      disabled={disabled}
      onClick={onSelect}
      className={`group relative flex w-full min-h-[56px] items-center gap-3 rounded-xl border bg-white p-3.5 text-left transition-colors duration-150 ease-out disabled:opacity-45 ${
      layout === 'tile' ? 'flex-col items-start gap-2 min-h-[104px]' : ''} ${

      selected ?
      'border-brand-600 bg-brand-50 ring-1 ring-brand-600' :
      'border-hairline hover:border-brand-300'}`
      }>
      
      {icon &&
      <span
        className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg transition-colors duration-150 ease-out ${
        selected ? 'bg-brand-600 text-white' : 'bg-brand-50 text-brand-700'}`
        }>
        
          {icon}
        </span>
      }
      <span className="min-w-0 flex-1">
        <span className={`block text-[14.5px] font-semibold ${selected ? 'text-brand-800' : 'text-navy'}`}>
          {title}
        </span>
        {description && <span className="mt-0.5 block text-[12.5px] leading-snug text-navy-muted">{description}</span>}
      </span>
      <span
        aria-hidden="true"
        className={`flex h-6 w-6 shrink-0 items-center justify-center border transition-colors duration-150 ease-out ${
        multi ? 'rounded-md' : 'rounded-full'} ${
        selected ? 'border-brand-600 bg-brand-600 text-white' : 'border-hairline bg-white'} ${
        layout === 'tile' ? 'absolute' : ''}`
        }
        style={layout === 'tile' ? { position: 'absolute', top: 12, right: 12 } : undefined}>
        
        {selected && <CheckIcon size={15} strokeWidth={3} />}
      </span>
    </button>);

}