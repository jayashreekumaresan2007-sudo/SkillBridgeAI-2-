import React, { useState } from 'react';
import { AlertCircleIcon, EyeIcon, EyeOffIcon } from 'lucide-react';

interface TextFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
  hint?: string;
  showToggle?: boolean;
}

export function TextField({ label, error, hint, showToggle, id, type = 'text', ...rest }: TextFieldProps) {
  const [visible, setVisible] = useState(false);
  const inputId = id ?? `field-${label.toLowerCase().replace(/\s+/g, '-')}`;
  const describedBy = error ? `${inputId}-error` : hint ? `${inputId}-hint` : undefined;
  const resolvedType = showToggle ? visible ? 'text' : 'password' : type;

  return (
    <div className="w-full">
      <label htmlFor={inputId} className="mb-1.5 block text-[13px] font-semibold text-navy">
        {label}
      </label>
      <div className="relative">
        <input
          {...rest}
          id={inputId}
          type={resolvedType}
          aria-invalid={Boolean(error)}
          aria-describedby={describedBy}
          className={`min-h-[50px] w-full rounded-xl border bg-white px-4 text-[15px] text-navy placeholder:text-navy-muted/70 transition-colors duration-150 ease-out focus:outline-none focus:ring-2 ${
          error ?
          'border-bad focus:border-bad focus:ring-bad/25' :
          'border-hairline focus:border-brand-400 focus:ring-brand-200'} ${
          showToggle ? 'pr-12' : ''}`} />
        
        {showToggle &&
        <button
          type="button"
          onClick={() => setVisible((v) => !v)}
          aria-label={visible ? 'Hide password' : 'Show password'}
          className="absolute right-1 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-lg text-navy-muted transition-colors duration-150 ease-out hover:text-brand-700">
          
            {visible ? <EyeOffIcon size={18} /> : <EyeIcon size={18} />}
          </button>
        }
      </div>
      {error ?
      <p id={`${inputId}-error`} className="mt-1.5 flex items-center gap-1.5 text-[12.5px] font-medium text-bad">
          <AlertCircleIcon size={14} aria-hidden="true" />
          {error}
        </p> :
      hint ?
      <p id={`${inputId}-hint`} className="mt-1.5 text-[12.5px] text-navy-muted">
          {hint}
        </p> :
      null}
    </div>);

}