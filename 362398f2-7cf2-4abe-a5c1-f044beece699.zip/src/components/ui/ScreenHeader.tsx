import React from 'react';
import { ArrowLeftIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface ScreenHeaderProps {
  title?: string;
  subtitle?: string;
  onBack?: () => void;
  showBack?: boolean;
  action?: React.ReactNode;
  border?: boolean;
}

export function ScreenHeader({
  title,
  subtitle,
  onBack,
  showBack = true,
  action,
  border = true
}: ScreenHeaderProps) {
  const navigate = useNavigate();
  return (
    <header
      className={`flex shrink-0 items-center gap-3 bg-surface px-5 pb-3 pt-[max(20px,env(safe-area-inset-top))] sm:pt-9 ${
      border ? 'border-b border-hairline' : ''}`
      }>
      
      {showBack &&
      <button
        type="button"
        onClick={() => onBack ? onBack() : navigate(-1)}
        aria-label="Go back"
        className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-hairline text-navy transition-colors duration-150 ease-out hover:bg-brand-50">
        
          <ArrowLeftIcon size={19} />
        </button>
      }
      <div className="min-w-0 flex-1">
        {title && <h1 className="truncate text-[17px] font-bold text-navy">{title}</h1>}
        {subtitle && <p className="truncate text-xs text-navy-muted">{subtitle}</p>}
      </div>
      {action}
    </header>);

}