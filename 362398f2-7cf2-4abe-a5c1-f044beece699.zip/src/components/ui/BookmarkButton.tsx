import React from 'react';
import { BookmarkIcon } from 'lucide-react';

interface BookmarkButtonProps {
  saved: boolean;
  onToggle: () => void;
  label: string;
  compact?: boolean;
}

export function BookmarkButton({ saved, onToggle, label, compact }: BookmarkButtonProps) {
  return (
    <button
      type="button"
      aria-pressed={saved}
      aria-label={saved ? `Remove ${label} from saved` : `Save ${label}`}
      onClick={(event) => {
        event.stopPropagation();
        onToggle();
      }}
      className={`flex shrink-0 items-center justify-center rounded-full border transition-colors duration-150 ease-out ${
      compact ? 'h-9 w-9' : 'h-11 w-11'} ${

      saved ?
      'border-brand-600 bg-brand-600 text-white' :
      'border-hairline bg-white text-navy-muted hover:border-brand-300 hover:text-brand-700'}`
      }>
      
      <BookmarkIcon size={compact ? 16 : 18} fill={saved ? 'currentColor' : 'none'} />
    </button>);

}