import React from 'react';

interface ProgressBarProps {
  value: number;
  label?: string;
  tone?: 'brand' | 'good';
  size?: 'sm' | 'md';
}

export function ProgressBar({ value, label, tone = 'brand', size = 'md' }: ProgressBarProps) {
  const clamped = Math.min(100, Math.max(0, value));
  return (
    <div
      role="progressbar"
      aria-valuenow={clamped}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={label ?? 'Progress'}
      className={`w-full overflow-hidden rounded-full bg-brand-100 ${size === 'sm' ? 'h-1.5' : 'h-2.5'}`}>
      
      <div
        className={`h-full rounded-full transition-[width] duration-300 ease-out ${
        tone === 'good' ? 'bg-good' : 'bg-brand-600'}`
        }
        style={{ width: `${clamped}%` }} />
      
    </div>);

}