import React from 'react';
import { AlertTriangleIcon, CheckCircle2Icon, CircleDashedIcon } from 'lucide-react';
import type { SkillLevel } from '../../types';
import { useT } from '../../i18n';

const STYLES: Record<SkillLevel, {className: string;icon: React.ReactNode;key: string;}> = {
  Strong: { className: 'bg-goodSoft text-good', icon: <CheckCircle2Icon size={13} />, key: 'gap.strong' },
  Developing: { className: 'bg-warnSoft text-warn', icon: <CircleDashedIcon size={13} />, key: 'gap.developing' },
  'Needs Improvement': { className: 'bg-badSoft text-bad', icon: <AlertTriangleIcon size={13} />, key: 'gap.needs' }
};

/** Status is always communicated with an icon + text, never colour alone. */
export function LevelTag({ level }: {level: SkillLevel;}) {
  const style = STYLES[level];
  const { t } = useT();
  return (
    <span
      className={`inline-flex shrink-0 items-center gap-1 rounded-full px-2.5 py-1 text-[11.5px] font-semibold ${style.className}`}>
      
      {style.icon}
      {t(style.key, level)}
    </span>);

}