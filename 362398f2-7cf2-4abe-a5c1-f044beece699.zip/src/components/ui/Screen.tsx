import React from 'react';

interface ScreenProps {
  header?: React.ReactNode;
  footer?: React.ReactNode;
  children: React.ReactNode;
  padded?: boolean;
  tone?: 'canvas' | 'white' | 'navy';
}

const TONES = {
  canvas: 'bg-canvas',
  white: 'bg-surface',
  navy: 'bg-navy'
};

export function Screen({ header, footer, children, padded = true, tone = 'canvas' }: ScreenProps) {
  return (
    <div className={`flex h-full w-full flex-col ${TONES[tone]}`}>
      {header}
      <main className={`no-scrollbar flex-1 overflow-y-auto ${padded ? 'px-5 pb-8 pt-5' : ''}`}>
        {children}
      </main>
      {footer &&
      <div className="shrink-0 border-t border-hairline bg-surface px-5 pb-[max(16px,env(safe-area-inset-bottom))] pt-3.5">
          {footer}
        </div>
      }
    </div>);

}