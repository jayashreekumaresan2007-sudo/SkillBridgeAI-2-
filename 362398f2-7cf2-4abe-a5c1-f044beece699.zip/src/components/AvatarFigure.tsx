import React from 'react';
import { UserRoundIcon } from 'lucide-react';
import { getAvatar } from '../data/avatars';
import type { AvatarOption } from '../data/avatars';

interface AvatarFigureProps {
  avatar?: AvatarOption | null;
  avatarId?: string | null;
  size?: number;
  ring?: boolean;
}

/**
 * Visual-only avatar. The MVP intentionally has no voice, animation or
 * conversational behaviour attached to it.
 */
export function AvatarFigure({ avatar, avatarId, size = 64, ring = false }: AvatarFigureProps) {
  const data = avatar ?? getAvatar(avatarId ?? null);

  if (!data) {
    return (
      <span
        className="inline-flex items-center justify-center rounded-full bg-brand-50 text-brand-600"
        style={{ width: size, height: size }}
        aria-hidden="true">
        
        <UserRoundIcon size={size * 0.5} />
      </span>);

  }

  return (
    <img
      src={data.image}
      alt={`Avatar ${data.name}`}
      width={size}
      height={size}
      loading="lazy"
      className={`shrink-0 rounded-full bg-brand-50 object-cover ${ring ? 'ring-4 ring-brand-100' : ''}`}
      style={{ width: size, height: size }} />);


}