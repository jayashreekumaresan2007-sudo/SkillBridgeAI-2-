import React from 'react';

interface LogoProps {
  size?: number;
  tone?: 'brand' | 'light';
  withWordmark?: boolean;
}

export function Logo({ size = 40, tone = 'brand', withWordmark = false }: LogoProps) {
  const mark = tone === 'brand' ? '#1E48CC' : '#FFFFFF';
  const inner = tone === 'brand' ? '#FFFFFF' : '#0E1B3D';

  return (
    <span className="inline-flex items-center gap-2.5">
      <svg width={size} height={size} viewBox="0 0 48 48" role="img" aria-label="SkillBridgeAI logo">
        <path d="M24 2.5 43 13.25v21.5L24 45.5 5 34.75v-21.5L24 2.5Z" fill={mark} />
        <path
          d="M31.5 17.5H21.8l4.4 3.6-9.7 0-4.4-3.6 9.7-7.2 9.7 7.2Z"
          fill={inner}
          transform="translate(0,3)" />
        
        <path
          d="M16.5 30.5h9.7l-4.4-3.6 9.7 0 4.4 3.6-9.7 7.2-9.7-7.2Z"
          fill={inner}
          transform="translate(0,-3)" />
        
      </svg>
      {withWordmark &&
      <span
        className="text-[17px] font-bold tracking-tight"
        style={{ color: tone === 'brand' ? '#0E1B3D' : '#FFFFFF' }}>
        
          SkillBridge<span style={{ color: tone === 'brand' ? '#1E48CC' : '#8FAAFF' }}>AI</span>
        </span>
      }
    </span>);

}