import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  BookmarkIcon,
  CompassIcon,
  GraduationCapIcon,
  LayoutDashboardIcon,
  UserRoundIcon } from
'lucide-react';
import { useT } from '../i18n';

const ITEMS = [
{ to: '/dashboard', key: 'nav.home', Icon: LayoutDashboardIcon },
{ to: '/careers', key: 'nav.careers', Icon: CompassIcon },
{ to: '/academies', key: 'nav.learn', Icon: GraduationCapIcon },
{ to: '/saved', key: 'nav.saved', Icon: BookmarkIcon },
{ to: '/profile', key: 'nav.profile', Icon: UserRoundIcon }];


export function BottomNav() {
  const { t } = useT();
  return (
    <nav
      aria-label="Primary"
      className="shrink-0 border-t border-hairline bg-surface pb-[max(8px,env(safe-area-inset-bottom))] pt-1.5">
      
      <ul className="flex items-stretch justify-around">
        {ITEMS.map(({ to, key, Icon }) =>
        <li key={to} className="flex-1">
            <NavLink
            to={to}
            className={({ isActive }) =>
            `flex min-h-[52px] flex-col items-center justify-center gap-1 rounded-lg px-1 text-[11px] font-semibold transition-colors duration-150 ease-out ${
            isActive ? 'text-brand-700' : 'text-navy-muted hover:text-navy'}`

            }>
            
              {({ isActive }) =>
            <>
                  <Icon size={21} strokeWidth={isActive ? 2.4 : 1.9} aria-hidden="true" />
                  <span className="truncate">{t(key)}</span>
                </>
            }
            </NavLink>
          </li>
        )}
      </ul>
    </nav>);

}