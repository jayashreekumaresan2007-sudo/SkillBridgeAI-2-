import React, { useState } from 'react';
import { CheckIcon, ChevronDownIcon, CircleIcon, ChevronRightIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { ROLE_KIND_LABEL } from '../data/roles';
import { CAREERS } from '../data/careers';
import { featureForSkill } from '../ml/skillProfile';
import { useUser } from '../contexts/UserContext';
import type { RoleRecommendation } from '../types';

const KIND_STYLES: Record<RoleRecommendation['kind'], string> = {
  core: 'bg-brand-600 text-white',
  adjacent: 'bg-brand-50 text-brand-800',
  hidden: 'bg-warnSoft text-warn',
  emerging: 'bg-goodSoft text-good'
};

interface RoleDiscoveryCardProps {
  role: RoleRecommendation;
  /** Slot label — "Best fit", "Alternative" etc. Falls back to the role's own kind. */
  label?: string;
  /** The lead recommendation is expanded by default; the rest disclose on demand. */
  emphasis?: boolean;
}

export function RoleDiscoveryCard({ role, label, emphasis = false }: RoleDiscoveryCardProps) {
  const navigate = useNavigate();
  const { profile } = useUser();
  const [open, setOpen] = useState(emphasis);

  const features = profile.features;
  const graded = role.skills.map((skill) => ({
    skill,
    value: features ? features[featureForSkill(skill)] : 0
  }));
  const have = graded.filter((s) => s.value >= 0.55);
  const build = graded.filter((s) => s.value < 0.55);

  return (
    <article
      className={`rounded-2xl border bg-white p-4 shadow-card ${
      emphasis ? 'border-brand-300 ring-1 ring-brand-200' : 'border-hairline'}`
      }>
      
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <span className={`inline-block rounded-full px-2.5 py-1 text-[11px] font-semibold ${KIND_STYLES[role.kind]}`}>
            {label ?? ROLE_KIND_LABEL[role.kind]}
          </span>
          <h3 className={`mt-2 font-bold leading-snug text-navy ${emphasis ? 'text-[19px]' : 'text-[16px]'}`}>
            {role.title}
          </h3>
          <p className="mt-1 text-[12.5px] text-navy-muted">{CAREERS[role.careerId].title}</p>
        </div>
        <div className="shrink-0 text-right">
          <p className={`font-bold leading-none text-brand-700 ${emphasis ? 'text-[28px]' : 'text-[22px]'}`}>
            {role.match}%
          </p>
          <p className="mt-1 text-[11px] font-semibold text-navy-muted">{role.confidence} confidence</p>
        </div>
      </div>

      <p className="mt-3 text-[13px] leading-relaxed text-navy-soft">{role.summary}</p>

      {open &&
      <div className="mt-4 space-y-4 border-t border-hairline pt-4">
          <div>
            <h4 className="text-[11.5px] font-semibold uppercase tracking-wide text-navy-muted">Why this fits you</h4>
            <ul className="mt-2 space-y-1.5">
              {role.why.map((reason) =>
            <li key={reason} className="flex gap-2 text-[12.5px] leading-relaxed text-navy-soft">
                  <CheckIcon size={14} className="mt-0.5 shrink-0 text-good" />
                  {reason}
                </li>
            )}
            </ul>
          </div>

          {have.length > 0 &&
        <div>
              <h4 className="text-[11.5px] font-semibold uppercase tracking-wide text-navy-muted">
                Strengths you already bring
              </h4>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {have.map((item) =>
            <span
              key={item.skill}
              className="flex items-center gap-1 rounded-md bg-goodSoft px-2 py-1 text-[11.5px] font-medium text-good">
              
                    <CheckIcon size={12} />
                    {item.skill}
                  </span>
            )}
              </div>
            </div>
        }

          {build.length > 0 &&
        <div>
              <h4 className="text-[11.5px] font-semibold uppercase tracking-wide text-navy-muted">Areas to improve</h4>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {build.map((item) =>
            <span
              key={item.skill}
              className="flex items-center gap-1 rounded-md bg-canvas px-2 py-1 text-[11.5px] font-medium text-navy-soft">
              
                    <CircleIcon size={11} />
                    {item.skill}
                  </span>
            )}
              </div>
            </div>
        }

          <button
          type="button"
          onClick={() => navigate(`/careers/${role.careerId}`)}
          className="flex min-h-[44px] w-full items-center justify-center gap-1.5 rounded-xl bg-brand-50 text-[13.5px] font-semibold text-brand-700 transition-colors duration-150 ease-out hover:bg-brand-100">
          
            Explore {CAREERS[role.careerId].title}
            <ChevronRightIcon size={16} />
          </button>
        </div>
      }

      {!emphasis &&
      <button
        type="button"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
        className="mt-3 flex min-h-[44px] w-full items-center justify-center gap-1.5 text-[13px] font-semibold text-navy-muted transition-colors duration-150 ease-out hover:text-brand-700">
        
          {open ? 'Show less' : 'Why this was suggested'}
          <ChevronDownIcon
          size={15}
          className={`transition-transform duration-200 ease-out ${open ? 'rotate-180' : ''}`} />
        
        </button>
      }
    </article>);

}