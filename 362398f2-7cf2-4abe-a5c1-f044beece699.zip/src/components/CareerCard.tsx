import React from 'react';
import { ChevronRightIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { BookmarkButton } from './ui/BookmarkButton';
import { ProgressBar } from './ui/ProgressBar';
import { CAREERS, CAREER_FAMILY_COLORS } from '../data/careers';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';
import type { CareerCategoryId } from '../types';

interface CareerCardProps {
  careerId: CareerCategoryId;
  match?: number;
  reasons?: string[];
  rank?: number;
}

export function CareerCard({ careerId, match, reasons, rank }: CareerCardProps) {
  const navigate = useNavigate();
  const { toggleSaved, isSaved } = useUser();
  const { t } = useT();
  const career = CAREERS[careerId];

  return (
    <article className="rounded-2xl border border-hairline bg-white p-4 shadow-card">
      <div className="flex items-start gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            {typeof rank === 'number' &&
            <span className="rounded-md bg-navy px-1.5 py-0.5 text-[11px] font-bold text-white">#{rank}</span>
            }
            <span
              className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${
              CAREER_FAMILY_COLORS[career.family] ?? 'bg-brand-50 text-brand-700'}`
              }>
              
              {career.family}
            </span>
          </div>
          <h3 className="mt-2 text-[16px] font-bold leading-snug text-navy">{career.title}</h3>
          <p className="mt-1 text-[12.5px] leading-relaxed text-navy-muted">{career.tagline}</p>
        </div>
        <BookmarkButton
          compact
          saved={isSaved('savedCareers', career.id)}
          onToggle={() => toggleSaved('savedCareers', career.id)}
          label={career.title} />
        
      </div>

      {typeof match === 'number' &&
      <div className="mt-3.5">
          <div className="mb-1.5 flex items-baseline justify-between">
            <span className="text-[12px] font-semibold text-navy-muted">{t('res.match')}</span>
            <span className="text-[15px] font-bold text-brand-700">{match}%</span>
          </div>
          <ProgressBar value={match} size="sm" label={`${career.title} match`} />
        </div>
      }

      {reasons && reasons.length > 0 &&
      <ul className="mt-3.5 space-y-1.5 rounded-xl bg-canvas p-3">
          <li className="text-[11.5px] font-semibold uppercase tracking-wide text-navy-muted">{t('res.why')}</li>
          {reasons.slice(0, 3).map((reason) =>
        <li key={reason} className="flex gap-2 text-[12.5px] leading-relaxed text-navy">
              <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-500" aria-hidden="true" />
              {reason}
            </li>
        )}
        </ul>
      }

      <div className="mt-3.5 flex flex-wrap gap-1.5">
        {career.technicalSkills.slice(0, 3).map((skill) =>
        <span key={skill} className="rounded-md bg-brand-50 px-2 py-1 text-[11.5px] font-medium text-brand-800">
            {skill}
          </span>
        )}
      </div>

      <button
        type="button"
        onClick={() => navigate(`/careers/${career.id}`)}
        className="mt-3.5 flex min-h-[44px] w-full items-center justify-center gap-1 rounded-xl bg-brand-50 text-[14px] font-semibold text-brand-700 transition-colors duration-150 ease-out hover:bg-brand-100">
        
        {t('res.explore')}
        <ChevronRightIcon size={16} />
      </button>
    </article>);

}