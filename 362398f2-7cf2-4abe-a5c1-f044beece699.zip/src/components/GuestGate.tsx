import React from 'react';
import { LockIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from './ui/Button';

interface GuestGateProps {
  feature: string;
  description: string;
}

/** Shown when a guest reaches a personalised feature that needs an account. */
export function GuestGate({ feature, description }: GuestGateProps) {
  const navigate = useNavigate();
  return (
    <section className="rounded-2xl border border-hairline bg-white p-6 text-center shadow-card">
      <span className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-brand-50 text-brand-600">
        <LockIcon size={22} />
      </span>
      <h2 className="text-[16px] font-bold text-navy">{feature} needs an account</h2>
      <p className="mx-auto mt-2 max-w-[270px] text-[13px] leading-relaxed text-navy-muted">{description}</p>
      <div className="mt-5 space-y-2.5">
        <Button fullWidth onClick={() => navigate('/create-account')}>
          Create free account
        </Button>
        <Button variant="outline" fullWidth onClick={() => navigate('/login')}>
          I already have an account
        </Button>
      </div>
    </section>);

}