import React from 'react';
import { motion } from 'framer-motion';
import { CheckIcon, ShieldAlertIcon } from 'lucide-react';
import { Button } from './ui/Button';

const CHECKS = [
'Visit the provider’s official website',
'Confirm the course actually exists and is running',
'Contact the provider directly before paying',
'Ask for the full fee structure in writing',
'Check the refund and withdrawal policy',
'Confirm accreditation or recognition where it matters',
'Verify the physical location if it is offline',
'Compare at least one other provider',
'Never pay based only on a social media advertisement',
'Never share banking or ID details before verifying'];


interface VerifySheetProps {
  providerName: string;
  onConfirm: () => void;
  onBack: () => void;
}

/**
 * Shown before any enrol / contact action. SkillBridgeAI recommends — it does
 * not vouch for a provider, and it never pressures a decision.
 */
export function VerifySheet({ providerName, onConfirm, onBack }: VerifySheetProps) {
  return (
    <div
      className="absolute inset-0 z-40 flex items-end bg-navy/45 px-4 pb-6"
      role="dialog"
      aria-modal="true"
      aria-labelledby="verify-title">
      
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.24, ease: [0.23, 1, 0.32, 1] }}
        className="max-h-[80%] w-full overflow-y-auto rounded-2xl bg-white p-5 shadow-lift">
        
        <div className="flex items-start gap-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-warnSoft text-warn">
            <ShieldAlertIcon size={20} />
          </span>
          <div className="min-w-0">
            <h2 id="verify-title" className="text-[17px] font-bold text-navy">
              Before you decide
            </h2>
            <p className="mt-1 text-[12.5px] leading-relaxed text-navy-muted">
              Check these with {providerName} yourself. SkillBridgeAI provides recommendations, not
              guarantees.
            </p>
          </div>
        </div>

        <ul className="mt-4 space-y-2">
          {CHECKS.map((check) =>
          <li key={check} className="flex gap-2 text-[12.5px] leading-relaxed text-navy-soft">
              <CheckIcon size={14} className="mt-0.5 shrink-0 text-good" />
              {check}
            </li>
          )}
        </ul>

        <div className="mt-5 space-y-2.5">
          <Button fullWidth onClick={onConfirm}>
            I’ve checked the details
          </Button>
          <Button variant="outline" fullWidth onClick={onBack}>
            Go back and compare
          </Button>
        </div>
      </motion.div>
    </div>);

}