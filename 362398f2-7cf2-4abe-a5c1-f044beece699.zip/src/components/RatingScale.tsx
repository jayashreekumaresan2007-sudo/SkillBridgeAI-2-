import React from 'react';

interface RatingScaleProps {
  label: string;
  value?: number;
  onChange: (value: number) => void;
}

const LABELS = ['Still learning', 'Basic', 'Okay', 'Confident', 'Very confident'];

export function RatingScale({ label, value, onChange }: RatingScaleProps) {
  return (
    <fieldset className="rounded-xl border border-hairline bg-white p-3.5">
      <legend className="sr-only">{label}</legend>
      <div className="mb-2.5 flex items-baseline justify-between gap-3">
        <span className="text-[14px] font-semibold text-navy">{label}</span>
        <span className="text-[11.5px] font-medium text-navy-muted">
          {value ? LABELS[value - 1] : 'Not rated'}
        </span>
      </div>
      <div className="flex gap-2" role="radiogroup" aria-label={label}>
        {[1, 2, 3, 4, 5].map((n) => {
          const selected = value === n;
          return (
            <button
              key={n}
              type="button"
              role="radio"
              aria-checked={selected}
              aria-label={`${label}: ${n} — ${LABELS[n - 1]}`}
              onClick={() => onChange(n)}
              className={`flex h-11 flex-1 items-center justify-center rounded-lg border text-[14px] font-semibold transition-colors duration-150 ease-out ${
              selected ?
              'border-brand-600 bg-brand-600 text-white' :
              'border-hairline bg-white text-navy-muted hover:border-brand-300 hover:text-navy'}`
              }>
              
              {n}
            </button>);

        })}
      </div>
    </fieldset>);

}