import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { CheckIcon, CircleCheckBigIcon, SparklesIcon, UserRoundCheckIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { Screen } from '../components/ui/Screen';
import { JOURNEY_META } from '../data/assessment';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';

export function AssessmentComplete() {
  const navigate = useNavigate();
  const { profile, runRecommendation, questions, journey } = useUser();
  const { t } = useT();
  const [processing, setProcessing] = useState(true);
  const answered = questions.filter((q) => profile.assessmentAnswers[q.id]).length;
  const meta = JOURNEY_META[journey];

  useEffect(() => {
    const timer = window.setTimeout(() => {
      runRecommendation();
      setProcessing(false);
    }, 900);
    return () => window.clearTimeout(timer);
  }, [runRecommendation]);

  const steps = [
  { icon: <CircleCheckBigIcon size={17} />, label: t('asmt.answered'), value: `${answered} / ${questions.length}` },
  { icon: <UserRoundCheckIcon size={17} />, label: t('asmt.profile'), value: 'Interests, strengths, confidence' },
  { icon: <SparklesIcon size={17} />, label: t('asmt.nextStep'), value: meta.outcome }];


  return (
    <Screen
      footer={
      <Button fullWidth loading={processing} onClick={() => navigate(meta.resultRoute, { replace: true })}>
          {journey === 'skill' ? 'View my skill profile' : t('asmt.viewResults')}
        </Button>
      }>
      
      <div className="flex flex-col items-center pt-8 text-center">
        <motion.span
          initial={{ scale: 0.96, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.26, ease: [0.23, 1, 0.32, 1] }}
          className="flex h-16 w-16 items-center justify-center rounded-full bg-goodSoft text-good">
          
          <CheckIcon size={32} strokeWidth={3} />
        </motion.span>
        <h1 className="mt-5 text-[22px] font-bold text-navy">{t('asmt.completed')}</h1>
        <p className="mt-2 max-w-[290px] text-[13.5px] leading-relaxed text-navy-muted">
          {processing ?
          'SkillBridgeAI is analysing your profile…' :
          'Nice work — your profile is ready.'}
        </p>
      </div>

      <ul className="mt-8 space-y-2.5">
        {steps.map((step) =>
        <li key={step.label} className="flex items-center gap-3 rounded-xl border border-hairline bg-white p-3.5">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-brand-700">
              {step.icon}
            </span>
            <div className="min-w-0">
              <p className="text-[13.5px] font-semibold text-navy">{step.label}</p>
              <p className="text-[12.5px] leading-relaxed text-navy-muted">{step.value}</p>
            </div>
          </li>
        )}
      </ul>
    </Screen>);

}