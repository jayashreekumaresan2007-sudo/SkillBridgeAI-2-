import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Logo } from '../components/Logo';
import { useUser } from '../contexts/UserContext';

export function Splash() {
  const navigate = useNavigate();
  const { profile, isAuthenticated } = useUser();

  useEffect(() => {
    const timer = window.setTimeout(() => {
      if (isAuthenticated || profile.isGuest) navigate('/dashboard', { replace: true });else
      navigate('/walkthrough', { replace: true });
    }, 1500);
    return () => window.clearTimeout(timer);
  }, [navigate, isAuthenticated, profile.isGuest]);

  return (
    <div className="flex h-full w-full flex-col items-center justify-center bg-surface px-8">
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.28, ease: [0.23, 1, 0.32, 1] }}
        className="flex flex-col items-center">
        
        <Logo size={76} />
        <h1 className="mt-6 text-[26px] font-bold tracking-tight text-navy">
          SkillBridge<span className="text-brand-600">AI</span>
        </h1>
        <p className="mt-2 text-[13.5px] font-medium text-navy-muted">From Confusion to Career Clarity</p>
      </motion.div>

      <div className="absolute bottom-10 flex flex-col items-center gap-3">
        <span className="h-1 w-24 overflow-hidden rounded-full bg-brand-100">
          <motion.span
            className="block h-full w-full origin-left bg-brand-600"
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 1.4, ease: 'linear' }} />
          
        </span>
        <p className="text-[11px] text-navy-muted">Preparing your guidance experience</p>
      </div>
    </div>);

}