import React, { useState } from 'react';
import { CheckCircle2Icon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { TextField } from '../components/ui/TextField';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { SocialAuthButtons } from '../components/SocialAuthButtons';
import { AuthAccountSheet } from '../components/AuthAccountSheet';
import type { AuthProvider } from '../components/AuthAccountSheet';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

interface Errors {
  name?: string;
  email?: string;
  password?: string;
  confirm?: string;
  terms?: string;
}

export function CreateAccount() {
  const navigate = useNavigate();
  const { login } = useUser();
  const { t } = useT();
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' });
  const [terms, setTerms] = useState(false);
  const [errors, setErrors] = useState<Errors>({});
  const [loading, setLoading] = useState(false);
  const [created, setCreated] = useState(false);
  const [provider, setProvider] = useState<AuthProvider | null>(null);

  const set = (key: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
  setForm((prev) => ({ ...prev, [key]: e.target.value }));

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    const next: Errors = {};
    if (form.name.trim().length < 2) next.name = t('err.name');
    if (!EMAIL_RE.test(form.email)) next.email = t('err.email');
    if (form.password.length < 8) next.password = t('err.password8');else
    if (!/\d/.test(form.password)) next.password = t('err.passwordNumber');
    if (form.confirm !== form.password) next.confirm = t('err.mismatch');
    if (!terms) next.terms = t('err.terms');
    setErrors(next);
    if (Object.keys(next).length) return;

    setLoading(true);
    window.setTimeout(() => {
      setLoading(false);
      setCreated(true);
      login(form.name.trim(), form.email);
    }, 800);
  };

  if (created) {
    return (
      <Screen header={<ScreenHeader showBack={false} border={false} />}>
        <div className="flex h-full flex-col items-center justify-center px-2 text-center">
          <span className="flex h-16 w-16 items-center justify-center rounded-full bg-goodSoft text-good">
            <CheckCircle2Icon size={32} />
          </span>
          <h1 className="mt-5 text-[22px] font-bold text-navy">Account created</h1>
          <p className="mt-2 max-w-[280px] text-[13.5px] leading-relaxed text-navy-muted">
            Welcome, {form.name.split(' ')[0]}. Let's personalise SkillBridgeAI for you — it takes about a
            minute.
          </p>
          <Button className="mt-7" fullWidth onClick={() => navigate('/onboarding/language', { replace: true })}>
            {t('common.continue')}
          </Button>
        </div>
      </Screen>);

  }

  return (
    <div className="relative h-full w-full">
      <Screen header={<ScreenHeader title={t('auth.createAccount')} subtitle="Your details" />} tone="white">
        <form onSubmit={submit} noValidate className="space-y-4">
          <TextField label={t('auth.fullName')} autoComplete="name" placeholder="Your name" value={form.name} error={errors.name} onChange={set('name')} />
          <TextField
            label={t('auth.email')}
            type="email"
            inputMode="email"
            autoComplete="email"
            placeholder="you@example.com"
            value={form.email}
            error={errors.email}
            onChange={set('email')} />
          
          <TextField
            label={t('auth.password')}
            showToggle
            autoComplete="new-password"
            placeholder="••••••••"
            hint="At least 8 characters, including a number"
            value={form.password}
            error={errors.password}
            onChange={set('password')} />
          
          <TextField
            label={t('auth.confirmPassword')}
            showToggle
            autoComplete="new-password"
            placeholder="••••••••"
            value={form.confirm}
            error={errors.confirm}
            onChange={set('confirm')} />
          

          <div>
            <label className="flex cursor-pointer items-start gap-2.5 py-1 text-[13px] leading-relaxed text-navy">
              <input
                type="checkbox"
                checked={terms}
                onChange={(e) => setTerms(e.target.checked)}
                aria-invalid={Boolean(errors.terms)}
                className="mt-0.5 h-[18px] w-[18px] shrink-0 rounded border-hairline text-brand-600 focus:ring-brand-300" />
              
              <span>{t('auth.terms')}</span>
            </label>
            {errors.terms && <p className="mt-1 text-[12.5px] font-medium text-bad">{errors.terms}</p>}
          </div>

          <Button type="submit" fullWidth loading={loading}>
            {t('auth.createAccount')}
          </Button>
        </form>

        <SocialAuthButtons onSelect={setProvider} />

        <button
          type="button"
          onClick={() => navigate('/login')}
          className="mt-6 min-h-[44px] w-full text-[13.5px] font-semibold text-navy-muted hover:text-brand-700">
          
          {t('auth.haveAccount')} <span className="text-brand-700">{t('auth.login')}</span>
        </button>
      </Screen>

      {provider &&
      <AuthAccountSheet
        provider={provider}
        onClose={() => setProvider(null)}
        onSelect={(account) => {
          setProvider(null);
          login(account.name, account.email);
          navigate('/onboarding/language', { replace: true });
        }} />

      }
    </div>);

}