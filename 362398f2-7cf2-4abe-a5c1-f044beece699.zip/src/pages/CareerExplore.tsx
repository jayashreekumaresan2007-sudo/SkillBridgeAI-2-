import React, { useMemo, useState } from 'react';
import { SearchIcon, SparklesIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { CareerCard } from '../components/CareerCard';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { CAREER_LIST } from '../data/careers';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';

const FAMILIES = ['All', 'Technology', 'Data', 'Design', 'Business', 'Communication', 'Science', 'Product'];

export function CareerExplore() {
  const navigate = useNavigate();
  const { profile } = useUser();
  const { t } = useT();
  const [query, setQuery] = useState('');
  const [family, setFamily] = useState('All');

  const matchFor = (id: string) => profile.recommendations.find((r) => r.careerId === id)?.match;

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return CAREER_LIST.filter((career) => {
      const familyOk = family === 'All' || career.family === family;
      const queryOk =
      !q ||
      career.title.toLowerCase().includes(q) ||
      career.tagline.toLowerCase().includes(q) ||
      career.technicalSkills.some((s) => s.toLowerCase().includes(q));
      return familyOk && queryOk;
    }).sort((a, b) => (matchFor(b.id) ?? 0) - (matchFor(a.id) ?? 0));
  }, [query, family, profile.recommendations]);

  return (
    <Screen
      header={
      <ScreenHeader
        showBack={false}
        title={t('nav.careers')}
        subtitle={profile.assessmentComplete ? 'Sorted by your profile match' : 'Browse all career paths'} />

      }>
      
      {!profile.assessmentComplete &&
      <section className="mb-4 flex items-start gap-3 rounded-2xl border border-brand-200 bg-brand-50 p-4">
          <SparklesIcon size={18} className="mt-0.5 shrink-0 text-brand-700" />
          <div>
            <h2 className="text-[13.5px] font-bold text-brand-800">See which of these fit you</h2>
            <p className="mt-1 text-[12.5px] leading-relaxed text-brand-800/85">
              Take the assessment to get personalised matches, a skill gap and a roadmap.
            </p>
            <Button
            variant="secondary"
            className="mt-3 min-h-[42px] bg-white"
            onClick={() => navigate(profile.isGuest ? '/create-account' : '/assessment/intro')}>
            
              {profile.isGuest ? t('auth.createAccount') : t('asmt.start')}
            </Button>
          </div>
        </section>
      }

      <div className="relative">
        <SearchIcon size={17} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-navy-muted" aria-hidden="true" />
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search careers or skills"
          aria-label="Search careers"
          className="min-h-[48px] w-full rounded-xl border border-hairline bg-white pl-10 pr-4 text-[14px] text-navy placeholder:text-navy-muted/75 focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-200" />
        
      </div>

      <div className="no-scrollbar -mx-5 mt-3 flex gap-2 overflow-x-auto px-5 pb-1">
        {FAMILIES.map((option) =>
        <button
          key={option}
          type="button"
          aria-pressed={family === option}
          onClick={() => setFamily(option)}
          className={`min-h-[38px] shrink-0 rounded-full border px-3.5 text-[13px] font-semibold transition-colors duration-150 ease-out ${
          family === option ?
          'border-brand-600 bg-brand-600 text-white' :
          'border-hairline bg-white text-navy-muted hover:border-brand-300'}`
          }>
          
            {option}
          </button>
        )}
      </div>

      <div className="mt-4 space-y-3.5">
        {results.length === 0 ?
        <EmptyState
          title={t('err.noCareers')}
          message="Try a different search term or clear the filter."
          action={
          <Button
            variant="outline"
            onClick={() => {
              setQuery('');
              setFamily('All');
            }}>
            
                {t('common.clearFilters')}
              </Button>
          } /> :


        results.map((career) =>
        <CareerCard key={career.id} careerId={career.id} match={matchFor(career.id)} />
        )
        }
      </div>
    </Screen>);

}