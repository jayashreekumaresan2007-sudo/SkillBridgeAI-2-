import React, { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { AlertCircleIcon, ChevronLeftIcon, ChevronRightIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { DynamicIcon } from '../components/ui/DynamicIcon';
import { ProgressBar } from '../components/ui/ProgressBar';
import { RatingScale } from '../components/RatingScale';
import { SelectCard } from '../components/ui/SelectCard';
import { JOURNEY_META } from '../data/assessment';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';
import type { AnswerValue } from '../types';

function isAnswered(value: AnswerValue | undefined, itemCount: number, isRating: boolean) {
  if (!value) return false;
  if (isRating) return Object.keys(value as Record<string, number>).length === itemCount;
  return (value as string[]).length > 0;
}

export function Assessment() {
  const navigate = useNavigate();
  const { profile, setAnswer, resetAssessment, questions, journey } = useUser();
  const { t } = useT();
  const QUESTIONS = questions;
  const TOTAL_QUESTIONS = questions.length;
  const answeredCount = QUESTIONS.filter((q) => profile.assessmentAnswers[q.id]).length;
  const [showResume, setShowResume] = useState(answeredCount > 0 && !profile.assessmentComplete);
  const [index, setIndex] = useState(0);
  const [validation, setValidation] = useState('');

  const question = QUESTIONS[Math.min(index, QUESTIONS.length - 1)];
  const answer = profile.assessmentAnswers[question.id];
  const ratingValues = answer as Record<string, number> ?? {};
  const selected = Array.isArray(answer) ? answer : [];

  const answered = useMemo(
    () => isAnswered(answer, question.items?.length ?? 0, question.type === 'rating'),
    [answer, question]
  );

  const resumeIndex = () => {
    const next = QUESTIONS.findIndex(
      (q) => !isAnswered(profile.assessmentAnswers[q.id], q.items?.length ?? 0, q.type === 'rating')
    );
    return next === -1 ? QUESTIONS.length - 1 : next;
  };

  const toggleOption = (optionId: string) => {
    setValidation('');
    if (question.type === 'single') {
      setAnswer(question.id, [optionId]);
      window.setTimeout(() => setIndex((i) => Math.min(i + 1, QUESTIONS.length - 1)), 180);
      return;
    }
    const max = question.maxSelect ?? 99;
    const next = selected.includes(optionId) ?
    selected.filter((id) => id !== optionId) :
    selected.length >= max ?
    selected :
    [...selected, optionId];
    setAnswer(question.id, next);
  };

  const goNext = () => {
    if (!answered) {
      setValidation(t('err.selectOption'));
      return;
    }
    setValidation('');
    if (index === QUESTIONS.length - 1) navigate('/assessment/complete');else
    setIndex((i) => i + 1);
  };

  const goBack = () => {
    setValidation('');
    if (index === 0) navigate('/assessment/intro');else
    setIndex((i) => i - 1);
  };

  return (
    <div className="relative flex h-full w-full flex-col bg-canvas">
      <header className="shrink-0 bg-surface px-5 pb-3.5 pt-[max(20px,env(safe-area-inset-top))] sm:pt-9">
        <div className="mb-2.5 flex items-center justify-between gap-3">
          <span className="truncate rounded-full bg-brand-50 px-2.5 py-1 text-[11px] font-semibold text-brand-700">
            {JOURNEY_META[journey].label} · {question.kind}
          </span>
          <span className="text-[12px] font-semibold text-navy-muted">
            {t('asmt.question')} {index + 1} {t('common.of')} {TOTAL_QUESTIONS}
          </span>
        </div>
        <ProgressBar value={(index + (answered ? 1 : 0)) / TOTAL_QUESTIONS * 100} label="Assessment progress" size="sm" />
      </header>

      <main className="no-scrollbar flex-1 overflow-y-auto px-5 pb-6 pt-5">
        <AnimatePresence mode="wait">
          <motion.div
            key={question.id}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.18, ease: [0.23, 1, 0.32, 1] }}>
            
            {question.scenarioContext &&
            <p className="mb-1.5 text-[12px] font-semibold uppercase tracking-wide text-brand-600">
                {question.scenarioContext}
              </p>
            }
            <h1 className="text-[19px] font-bold leading-snug text-navy">
              {t(`q.${question.id}`, question.title)}
            </h1>
            <p className="mt-1.5 text-[12.5px] leading-relaxed text-navy-muted">{question.helper}</p>

            <div className="mt-5 space-y-2.5">
              {question.type === 'rating' &&
              question.items?.map((item) =>
              <RatingScale
                key={item.id}
                label={t(`i.${question.id}.${item.id}`, item.label)}
                value={ratingValues[item.id]}
                onChange={(value) => {
                  setValidation('');
                  setAnswer(question.id, { ...ratingValues, [item.id]: value });
                }} />

              )}

              {question.type !== 'rating' &&
              question.options?.map((option) =>
              <SelectCard
                key={option.id}
                title={t(`o.${question.id}.${option.id}`, option.label)}
                icon={<DynamicIcon name={option.icon} />}
                multi={question.type === 'multi'}
                selected={selected.includes(option.id)}
                disabled={
                question.type === 'multi' &&
                !selected.includes(option.id) &&
                selected.length >= (question.maxSelect ?? 99)
                }
                onSelect={() => toggleOption(option.id)} />

              )}
            </div>

            {question.type === 'multi' &&
            <p className="mt-3 text-center text-[12px] font-medium text-navy-muted">
                {selected.length} / {question.maxSelect} {t('common.selected')}
              </p>
            }
          </motion.div>
        </AnimatePresence>
      </main>

      <div className="shrink-0 border-t border-hairline bg-surface px-5 pb-[max(16px,env(safe-area-inset-bottom))] pt-3.5">
        {validation &&
        <p role="alert" className="mb-2.5 flex items-center gap-1.5 text-[12.5px] font-semibold text-bad">
            <AlertCircleIcon size={14} />
            {validation}
          </p>
        }
        <div className="flex gap-3">
          <Button variant="outline" onClick={goBack} icon={<ChevronLeftIcon size={17} />}>
            {t('common.back')}
          </Button>
          <Button fullWidth onClick={goNext} iconRight={<ChevronRightIcon size={17} />}>
            {index === QUESTIONS.length - 1 ? t('common.finish') : t('common.next')}
          </Button>
        </div>
      </div>

      {showResume &&
      <div
        className="absolute inset-0 z-40 flex items-end bg-navy/45 px-4 pb-6"
        role="dialog"
        aria-modal="true"
        aria-labelledby="resume-title">
        
          <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.24, ease: [0.23, 1, 0.32, 1] }}
          className="w-full rounded-2xl bg-white p-5 shadow-lift">
          
            <h2 id="resume-title" className="text-[17px] font-bold text-navy">
              {t('asmt.resumeQ')}
            </h2>
            <p className="mt-1.5 text-[13px] leading-relaxed text-navy-muted">
              {answeredCount} / {TOTAL_QUESTIONS} — continue where you left off or start again.
            </p>
            <div className="mt-5 space-y-2.5">
              <Button
              fullWidth
              onClick={() => {
                setIndex(resumeIndex());
                setShowResume(false);
              }}>
              
                {t('common.continue')}
              </Button>
              <Button
              variant="outline"
              fullWidth
              onClick={() => {
                resetAssessment();
                setIndex(0);
                setShowResume(false);
              }}>
              
                {t('asmt.startOver')}
              </Button>
            </div>
          </motion.div>
        </div>
      }
    </div>);

}