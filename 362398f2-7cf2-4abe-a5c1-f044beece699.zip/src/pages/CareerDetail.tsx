import React from 'react';
import { ArrowRightIcon, BriefcaseIcon, ListChecksIcon, TrendingUpIcon } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { AvatarFigure } from '../components/AvatarFigure';
import { BookmarkButton } from '../components/ui/BookmarkButton';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { ProgressBar } from '../components/ui/ProgressBar';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { CAREERS } from '../data/careers';
import { useUser } from '../contexts/UserContext';
import type { CareerCategoryId } from '../types';

function SkillPills({ items }: {items: string[];}) {
  return (
    <div className="flex flex-wrap gap-1.5">
      {items.map((item) =>
      <span key={item} className="rounded-md bg-brand-50 px-2.5 py-1 text-[12px] font-medium text-brand-800">
          {item}
        </span>
      )}
    </div>);

}

export function CareerDetail() {
  const { careerId } = useParams<{careerId: CareerCategoryId;}>();
  const navigate = useNavigate();
  const { profile, update, toggleSaved, isSaved } = useUser();
  const career = careerId ? CAREERS[careerId] : undefined;

  if (!career) {
    return (
      <Screen header={<ScreenHeader title="Career" />}>
        <EmptyState title="Career not found" message="This career is no longer available." />
      </Screen>);

  }

  const recommendation = profile.recommendations.find((r) => r.careerId === career.id);

  return (
    <Screen
      header={
      <ScreenHeader
        title={career.title}
        subtitle={career.family}
        action={
        <BookmarkButton
          saved={isSaved('savedCareers', career.id)}
          onToggle={() => toggleSaved('savedCareers', career.id)}
          label={career.title} />

        } />

      }
      footer={
      <Button
        fullWidth
        onClick={() => {
          update({ selectedCareer: career.id });
          navigate(profile.isGuest ? '/skill-gap' : '/roadmap');
        }}
        iconRight={<ArrowRightIcon size={17} />}>
        
          Build my roadmap
        </Button>
      }>
      
      <section className="rounded-2xl bg-brand-50 p-4">
        <div className="flex items-start gap-3">
          <div className="min-w-0 flex-1">
            {recommendation &&
            <span className="inline-block rounded-full bg-white px-2.5 py-1 text-[11.5px] font-bold text-brand-700">
                {recommendation.match}% match · {recommendation.confidence} confidence
              </span>
            }
            <h2 className="mt-2 text-[20px] font-bold leading-tight text-navy">{career.title}</h2>
            <p className="mt-1.5 text-[13px] leading-relaxed text-navy-soft">{career.tagline}</p>
          </div>
          {profile.avatar && <AvatarFigure avatarId={profile.avatar} size={54} />}
        </div>
        {recommendation &&
        <div className="mt-3.5">
            <ProgressBar value={recommendation.match} size="sm" label="Match" />
          </div>
        }
      </section>

      {recommendation && recommendation.reasons.length > 0 &&
      <section className="mt-5 rounded-2xl border border-hairline bg-white p-4">
          <h2 className="text-[14px] font-bold text-navy">Why this career was suggested</h2>
          <ul className="mt-2.5 space-y-1.5">
            {recommendation.reasons.map((reason) =>
          <li key={reason} className="flex gap-2 text-[12.5px] leading-relaxed text-navy-soft">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-500" aria-hidden="true" />
                {reason}
              </li>
          )}
          </ul>
        </section>
      }

      <section className="mt-5">
        <h2 className="text-[15px] font-bold text-navy">Career overview</h2>
        <p className="mt-1.5 text-[13.5px] leading-relaxed text-navy-muted">{career.overview}</p>
      </section>

      <section className="mt-5 rounded-2xl border border-hairline bg-white p-4">
        <h2 className="flex items-center gap-2 text-[14px] font-bold text-navy">
          <ListChecksIcon size={16} className="text-brand-600" />
          What this role does
        </h2>
        <ul className="mt-2.5 space-y-2">
          {career.whatYouDo.map((item) =>
          <li key={item} className="flex gap-2 text-[13px] leading-relaxed text-navy-soft">
              <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-400" aria-hidden="true" />
              {item}
            </li>
          )}
        </ul>
      </section>

      <section className="mt-5 space-y-4 rounded-2xl border border-hairline bg-white p-4">
        <div>
          <h2 className="mb-2 text-[14px] font-bold text-navy">Technical skills</h2>
          <SkillPills items={career.technicalSkills} />
        </div>
        <div>
          <h2 className="mb-2 text-[14px] font-bold text-navy">Soft skills</h2>
          <SkillPills items={career.softSkills} />
        </div>
      </section>

      <section className="mt-5 rounded-2xl border border-hairline bg-white p-4">
        <h2 className="text-[14px] font-bold text-navy">Learning path</h2>
        <ol className="mt-3 space-y-3">
          {career.learningPath.map((step, i) =>
          <li key={step} className="flex gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-brand-600 text-[11.5px] font-bold text-white">
                {i + 1}
              </span>
              <span className="pt-0.5 text-[13px] leading-snug text-navy-soft">{step}</span>
            </li>
          )}
        </ol>
      </section>

      <div className="mt-5 grid grid-cols-1 gap-3">
        <section className="rounded-2xl border border-hairline bg-white p-4">
          <h2 className="flex items-center gap-2 text-[14px] font-bold text-navy">
            <BriefcaseIcon size={16} className="text-brand-600" />
            Entry-level opportunities
          </h2>
          <SkillPills items={career.entryRoles} />
        </section>
        <section className="rounded-2xl border border-hairline bg-white p-4">
          <h2 className="flex items-center gap-2 text-[14px] font-bold text-navy">
            <TrendingUpIcon size={16} className="text-good" />
            Growth opportunities
          </h2>
          <SkillPills items={career.growth} />
        </section>
      </div>

      <section className="mt-5">
        <h2 className="mb-2.5 text-[15px] font-bold text-navy">Related careers</h2>
        <div className="space-y-2.5">
          {career.related.map((id) =>
          <button
            key={id}
            type="button"
            onClick={() => navigate(`/careers/${id}`)}
            className="flex min-h-[56px] w-full items-center justify-between gap-3 rounded-xl border border-hairline bg-white px-4 text-left transition-colors duration-150 ease-out hover:border-brand-300">
            
              <span>
                <span className="block text-[13.5px] font-semibold text-navy">{CAREERS[id].title}</span>
                <span className="block text-[12px] text-navy-muted">{CAREERS[id].family}</span>
              </span>
              <ArrowRightIcon size={16} className="text-brand-600" />
            </button>
          )}
        </div>
      </section>
    </Screen>);

}