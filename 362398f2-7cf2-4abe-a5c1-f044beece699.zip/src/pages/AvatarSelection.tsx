import React, { useState } from 'react';
import { ShieldCheckIcon, UsersRoundIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { AvatarFigure } from '../components/AvatarFigure';
import { Button } from '../components/ui/Button';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { AVATARS, getAvatar } from '../data/avatars';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';

export function AvatarSelection() {
  const navigate = useNavigate();
  const { profile, update } = useUser();
  const { t } = useT();
  const [gender, setGender] = useState<'male' | 'female' | null>(profile.gender);
  const [avatarId, setAvatarId] = useState<string | null>(profile.avatar);

  const options = AVATARS.filter((a) => a.gender === gender);
  const preview = getAvatar(avatarId) ?? options[0] ?? null;

  if (!gender) {
    return (
      <Screen
        header={
        <ScreenHeader subtitle="2 / 3" title={t('avatar.knowYou')} onBack={() => navigate('/onboarding/language')} />
        }
        footer={
        <p className="flex items-center justify-center gap-2 text-center text-[12px] text-navy-muted">
            <ShieldCheckIcon size={15} className="shrink-0 text-brand-600" />
            We respect your privacy. You can change this later in settings.
          </p>
        }>
        
        <div className="flex flex-col items-center pt-4 text-center">
          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-brand-50 text-brand-600">
            <UsersRoundIcon size={22} />
          </span>
          <h2 className="mt-4 text-[20px] font-bold text-navy">{t('avatar.gender')}</h2>
          <p className="mt-1.5 max-w-[250px] text-[13px] text-navy-muted">
            This only decides which avatar set we show you.
          </p>
        </div>

        <div className="mt-7 grid grid-cols-2 gap-3.5">
          {(['male', 'female'] as const).map((g) =>
          <button
            key={g}
            type="button"
            onClick={() => setGender(g)}
            className="flex flex-col items-center gap-3 rounded-2xl border border-hairline bg-white p-4 transition-colors duration-150 ease-out hover:border-brand-400">
            
              <AvatarFigure avatar={AVATARS.find((a) => a.gender === g) ?? null} size={104} />
              <span className="text-[14px] font-semibold text-navy">
                {g === 'male' ? t('avatar.male') : t('avatar.female')}
              </span>
            </button>
          )}
        </div>

        <button
          type="button"
          onClick={() => {
            update({ gender: null, avatar: null });
            navigate('/onboarding/path');
          }}
          className="mx-auto mt-6 block min-h-[44px] text-[13px] font-semibold text-navy-muted hover:text-brand-700">
          
          {t('avatar.skip')}
        </button>
      </Screen>);

  }

  return (
    <Screen
      header={<ScreenHeader title={t('avatar.choose')} subtitle="2 / 3" onBack={() => setGender(null)} />}
      footer={
      <Button
        fullWidth
        disabled={!avatarId}
        onClick={() => {
          update({ gender, avatar: avatarId });
          navigate(profile.assessmentComplete ? '/profile' : '/onboarding/path');
        }}>
        
          {t('common.continue')}
        </Button>
      }>
      
      <div className="flex flex-col items-center rounded-2xl bg-brand-50 py-6">
        <AvatarFigure avatar={preview} size={132} ring />
        <p className="mt-3 text-[13px] font-semibold text-brand-800">{preview?.name ?? '—'}</p>
      </div>

      <h2 className="mb-3 mt-6 text-[14px] font-bold text-navy">{t('avatar.select')}</h2>
      <div className="grid grid-cols-2 gap-3" role="radiogroup" aria-label={t('avatar.select')}>
        {options.map((option) => {
          const selected = avatarId === option.id;
          return (
            <button
              key={option.id}
              type="button"
              role="radio"
              aria-checked={selected}
              onClick={() => setAvatarId(option.id)}
              className={`flex flex-col items-center gap-2 rounded-xl border bg-white p-3 transition-colors duration-150 ease-out ${
              selected ? 'border-brand-600 ring-1 ring-brand-600' : 'border-hairline hover:border-brand-300'}`
              }>
              
              <AvatarFigure avatar={option} size={86} />
              <span className={`text-[12.5px] font-semibold ${selected ? 'text-brand-800' : 'text-navy'}`}>
                {option.name}
              </span>
            </button>);

        })}
      </div>

      <p className="mt-5 text-center text-[11.5px] leading-relaxed text-navy-muted">
        Your avatar is a visual personalisation only — voice and conversation are future features.
      </p>
    </Screen>);

}