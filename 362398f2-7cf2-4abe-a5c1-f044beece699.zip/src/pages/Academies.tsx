import React, { useMemo, useState } from 'react';
import { ClockIcon, GraduationCapIcon, MapPinIcon, StarIcon } from 'lucide-react';
import { BookmarkButton } from '../components/ui/BookmarkButton';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { ACADEMIES, ACADEMY_LEVELS, ACADEMY_MODES } from '../data/academies';
import { CAREER_LIST } from '../data/careers';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';
import type { CareerCategoryId } from '../types';

export function Academies() {
  const { profile, toggleSaved, isSaved, skillGap } = useUser();
  const { t } = useT();
  const recommended = profile.selectedCareer ?? profile.recommendations[0]?.careerId ?? null;
  const gapSkills = skillGap.filter((s) => s.level !== 'Strong').map((s) => s.name);

  const [career, setCareer] = useState<CareerCategoryId | 'all'>(recommended ?? 'all');
  const [mode, setMode] = useState<string>('all');
  const [level, setLevel] = useState<string>('all');
  const [query, setQuery] = useState('');

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return ACADEMIES.filter((academy) => {
      const careerOk = career === 'all' || academy.careers.includes(career);
      const modeOk = mode === 'all' || academy.mode === mode;
      const levelOk = level === 'all' || academy.level === level;
      const queryOk =
      !q ||
      academy.name.toLowerCase().includes(q) ||
      academy.course.toLowerCase().includes(q) ||
      academy.location.toLowerCase().includes(q) ||
      academy.skills.some((s) => s.toLowerCase().includes(q));
      return careerOk && modeOk && levelOk && queryOk;
    });
  }, [career, mode, level, query]);

  const reset = () => {
    setCareer('all');
    setMode('all');
    setLevel('all');
    setQuery('');
  };

  return (
    <Screen header={<ScreenHeader showBack={false} title={t('acad.title')} subtitle="Learning providers for your skills" />}>
      {gapSkills.length > 0 &&
      <p className="mb-3 rounded-xl bg-brand-50 p-3.5 text-[12.5px] leading-relaxed text-brand-800">
          Based on your skill gap, look for courses covering{' '}
          <strong>{gapSkills.slice(0, 3).join(', ')}</strong>.
        </p>
      }

      <input
        type="search"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search academies, courses or skills"
        aria-label="Search academies"
        className="min-h-[48px] w-full rounded-xl border border-hairline bg-white px-4 text-[14px] text-navy placeholder:text-navy-muted/75 focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-200" />
      

      <div className="mt-3 grid grid-cols-2 gap-2.5">
        <label className="text-[12px] font-semibold text-navy">
          {t('filter.career')}
          <select
            value={career}
            onChange={(e) => setCareer(e.target.value as CareerCategoryId | 'all')}
            className="mt-1 min-h-[44px] w-full rounded-xl border border-hairline bg-white px-3 text-[13px] font-medium text-navy focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-200">
            
            <option value="all">All careers</option>
            {CAREER_LIST.map((c) =>
            <option key={c.id} value={c.id}>
                {c.title}
              </option>
            )}
          </select>
        </label>
        <label className="text-[12px] font-semibold text-navy">
          {t('filter.level')}
          <select
            value={level}
            onChange={(e) => setLevel(e.target.value)}
            className="mt-1 min-h-[44px] w-full rounded-xl border border-hairline bg-white px-3 text-[13px] font-medium text-navy focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-200">
            
            <option value="all">All levels</option>
            {ACADEMY_LEVELS.map((l) =>
            <option key={l} value={l}>
                {l}
              </option>
            )}
          </select>
        </label>
      </div>

      <div className="mt-3 flex gap-2">
        {['all', ...ACADEMY_MODES].map((option) =>
        <button
          key={option}
          type="button"
          aria-pressed={mode === option}
          onClick={() => setMode(option)}
          className={`min-h-[40px] flex-1 rounded-full border text-[13px] font-semibold transition-colors duration-150 ease-out ${
          mode === option ?
          'border-brand-600 bg-brand-600 text-white' :
          'border-hairline bg-white text-navy-muted hover:border-brand-300'}`
          }>
          
            {option === 'all' ? 'All' : option}
          </button>
        )}
      </div>

      <p className="mt-4 text-[12px] font-medium text-navy-muted">
        {results.length} course{results.length === 1 ? '' : 's'} · sample data for this prototype
      </p>

      <div className="mt-3 space-y-3.5">
        {results.length === 0 ?
        <EmptyState
          title={t('err.noAcademies')}
          message="No courses match these filters. Try another mode or level."
          icon={<GraduationCapIcon size={22} />}
          action={
          <Button variant="outline" onClick={reset}>
                {t('common.clearFilters')}
              </Button>
          } /> :


        results.map((academy) => {
          const relevant = academy.skills.filter((s) => gapSkills.includes(s));
          return (
            <article key={academy.id} className="rounded-2xl border border-hairline bg-white p-4 shadow-card">
                <div className="flex items-start gap-3">
                  <div className="min-w-0 flex-1">
                    <p className="text-[12px] font-semibold uppercase tracking-wide text-brand-700">{academy.name}</p>
                    <h2 className="mt-1 text-[15.5px] font-bold leading-snug text-navy">{academy.course}</h2>
                  </div>
                  <BookmarkButton
                  compact
                  saved={isSaved('savedAcademies', academy.id)}
                  onToggle={() => toggleSaved('savedAcademies', academy.id)}
                  label={academy.course} />
                
                </div>

                <div className="mt-2.5 flex flex-wrap items-center gap-x-3.5 gap-y-1.5 text-[12px] text-navy-muted">
                  <span className="flex items-center gap-1">
                    <MapPinIcon size={13} />
                    {academy.mode} · {academy.location}
                  </span>
                  <span className="flex items-center gap-1">
                    <ClockIcon size={13} />
                    {academy.duration}
                  </span>
                  <span className="flex items-center gap-1">
                    <StarIcon size={13} className="text-warn" fill="currentColor" />
                    {academy.rating} ({academy.reviews})
                  </span>
                </div>

                <div className="mt-3 flex flex-wrap gap-1.5">
                  <span className="rounded-md bg-canvas px-2 py-1 text-[11.5px] font-semibold text-navy-soft">
                    {academy.level}
                  </span>
                  {academy.skills.map((skill) =>
                <span key={skill} className="rounded-md bg-brand-50 px-2 py-1 text-[11.5px] font-medium text-brand-800">
                      {skill}
                    </span>
                )}
                </div>

                {relevant.length > 0 &&
              <p className="mt-3 rounded-lg bg-goodSoft px-3 py-2 text-[12px] font-medium text-good">
                    Covers {relevant.length} of your gap skill{relevant.length === 1 ? '' : 's'}: {relevant.join(', ')}
                  </p>
              }
              </article>);

        })
        }
      </div>
    </Screen>);

}