import React, { useState } from 'react';
import { ChevronRightIcon, FileTextIcon, LogOutIcon, ShieldIcon, UserPenIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { AvatarFigure } from '../components/AvatarFigure';
import { Button } from '../components/ui/Button';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { TextField } from '../components/ui/TextField';
import { USER_CATEGORIES } from '../data/avatars';
import { useUser } from '../contexts/UserContext';
import { LANGUAGE_CODES, LANGUAGE_NATIVE, useT } from '../i18n';

export function Profile() {
  const navigate = useNavigate();
  const { profile, update, logout } = useUser();
  const { t, language } = useT();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(profile.name);
  const [info, setInfo] = useState<string | null>(null);

  const category = USER_CATEGORIES.find((c) => c.id === profile.userCategory);

  return (
    <Screen header={<ScreenHeader showBack={false} title={t('prof.title')} />}>
      <section className="flex items-center gap-4 rounded-2xl border border-hairline bg-white p-4">
        <AvatarFigure avatarId={profile.avatar} size={62} />
        <div className="min-w-0 flex-1">
          <p className="truncate text-[16px] font-bold text-navy">{profile.name || 'Guest user'}</p>
          <p className="truncate text-[12.5px] text-navy-muted">
            {profile.email || 'Browsing without an account'}
          </p>
          <p className="mt-1 truncate text-[12px] text-navy-muted">
            {category ? t(category.labelKey) : '—'} · {LANGUAGE_NATIVE[language]}
          </p>
        </div>
      </section>

      {profile.isGuest &&
      <div className="mt-4 rounded-2xl border border-brand-200 bg-brand-50 p-4">
          <h2 className="text-[13.5px] font-bold text-brand-800">You’re exploring as a guest</h2>
          <p className="mt-1 text-[12.5px] leading-relaxed text-brand-800/85">
            Create an account to keep your assessment results, roadmap and saved items.
          </p>
          <Button
          className="mt-3 min-h-[42px] bg-white text-brand-700 hover:bg-white/80"
          onClick={() => navigate('/create-account')}>
          
            {t('auth.createAccount')}
          </Button>
        </div>
      }

      {editing ?
      <section className="mt-4 space-y-3 rounded-2xl border border-hairline bg-white p-4">
          <TextField label={t('auth.fullName')} value={name} onChange={(e) => setName(e.target.value)} />
          <div className="flex gap-2.5">
            <Button
            fullWidth
            onClick={() => {
              update({ name });
              setEditing(false);
              setInfo('Profile updated');
            }}>
            
              {t('common.save')}
            </Button>
            <Button variant="outline" onClick={() => setEditing(false)}>
              {t('common.cancel')}
            </Button>
          </div>
        </section> :

      <button
        type="button"
        onClick={() => setEditing(true)}
        className="mt-4 flex min-h-[56px] w-full items-center gap-3 rounded-xl border border-hairline bg-white px-4 text-left transition-colors duration-150 ease-out hover:border-brand-300">
        
          <UserPenIcon size={18} className="text-brand-600" />
          <span className="flex-1 text-[14px] font-semibold text-navy">{t('prof.edit')}</span>
          <ChevronRightIcon size={17} className="text-navy-muted" />
        </button>
      }

      <button
        type="button"
        onClick={() => navigate('/onboarding/avatar')}
        className="mt-2.5 flex min-h-[56px] w-full items-center gap-3 rounded-xl border border-hairline bg-white px-4 text-left transition-colors duration-150 ease-out hover:border-brand-300">
        
        <AvatarFigure avatarId={profile.avatar} size={26} />
        <span className="flex-1 text-[14px] font-semibold text-navy">{t('prof.changeAvatar')}</span>
        <ChevronRightIcon size={17} className="text-navy-muted" />
      </button>

      <div className="mt-2.5 rounded-xl border border-hairline bg-white px-4 py-3">
        <label htmlFor="language" className="text-[12.5px] font-semibold text-navy">
          {t('prof.language')}
        </label>
        <select
          id="language"
          value={language}
          onChange={(e) => {
            update({ language: e.target.value });
            setInfo(`${t('prof.language')}: ${LANGUAGE_NATIVE[e.target.value as typeof language]}`);
          }}
          className="mt-1.5 min-h-[44px] w-full rounded-xl border border-hairline bg-white px-3 text-[14px] font-medium text-navy focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-200">
          
          {LANGUAGE_CODES.map((code) =>
          <option key={code} value={code}>
              {LANGUAGE_NATIVE[code]} — {code}
            </option>
          )}
        </select>
      </div>

      {[
      { key: 'prof.privacy', icon: <ShieldIcon size={18} className="text-brand-600" /> },
      { key: 'prof.terms', icon: <FileTextIcon size={18} className="text-brand-600" /> }].
      map((row) =>
      <button
        key={row.key}
        type="button"
        onClick={() => setInfo(`${t(row.key)} — not part of this prototype.`)}
        className="mt-2.5 flex min-h-[56px] w-full items-center gap-3 rounded-xl border border-hairline bg-white px-4 text-left transition-colors duration-150 ease-out hover:border-brand-300">
        
          {row.icon}
          <span className="flex-1 text-[14px] font-semibold text-navy">{t(row.key)}</span>
          <ChevronRightIcon size={17} className="text-navy-muted" />
        </button>
      )}

      {info &&
      <p role="status" className="mt-4 rounded-xl bg-goodSoft px-3.5 py-2.5 text-[12.5px] font-medium text-good">
          {info}
        </p>
      }

      <Button
        variant="danger"
        fullWidth
        className="mt-5"
        icon={<LogOutIcon size={17} />}
        onClick={() => {
          logout();
          navigate('/login', { replace: true });
        }}>
        
        {t('prof.logout')}
      </Button>

      <p className="mt-5 text-center text-[11px] leading-relaxed text-navy-muted">
        SkillBridgeAI MVP · recommendations use an on-device demo model trained on synthetic profiles.
        Institution and academy listings are mock data.
      </p>
    </Screen>);

}