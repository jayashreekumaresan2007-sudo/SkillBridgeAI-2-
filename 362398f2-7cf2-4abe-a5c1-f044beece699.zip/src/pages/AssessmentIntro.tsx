import React from 'react';
import { BrainCircuitIcon, ClockIcon, ListChecksIcon, ShieldCheckIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { JOURNEY_META } from '../data/assessment';
import { USER_CATEGORIES } from '../data/avatars';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';
import type { JourneyId } from '../types';

const HEADLINES: Record<JourneyId, {title: string;body: string;}> = {
  career: {
    title: 'Let’s understand you before we suggest a career',
    body: 'Most career advice starts with a job title. We start with your interests, your instincts and how you actually like to work.'
  },
  skill: {
    title: 'Let’s find out what you’re already good at',
    body: 'This one looks at how you work and learn, not what job you want. You’ll get a skill profile, the skills to prioritise and where to learn them.'
  },
  not_sure: {
    title: 'Not sure is a perfectly good starting point',
    body: 'This is the full version — it looks at both your career direction and your skills, then connects the two so you have a next step either way.'
  }
};

const CATEGORY_NOTE: Record<string, string> = {
  school: 'Questions are written for school students — subjects, projects and what you enjoy.',
  college: 'Questions draw on your coursework, projects and industry curiosity.',
  graduate: 'Questions focus on what you have already done and where you want to land next.',
  working: 'Questions focus on your current work, transferable strengths and the move you want.',
  switcher: 'Questions focus on what you would carry across and what you would need to build.',
  other: 'Questions stay general so nothing assumes a background you don’t have.'
};

export function AssessmentIntro() {
  const navigate = useNavigate();
  const { profile, questions, journey } = useUser();
  const { t } = useT();
  const answered = questions.filter((q) => profile.assessmentAnswers[q.id]).length;
  const hasProgress = answered > 0 && !profile.assessmentComplete;
  const category = USER_CATEGORIES.find((c) => c.id === profile.userCategory);
  const headline = HEADLINES[journey];

  const points = [
  {
    icon: <ClockIcon size={17} />,
    title: `${questions.length} questions, about ${Math.max(3, Math.round(questions.length * 0.4))} minutes`,
    body: 'Short questions, no right answers, nothing timed.'
  },
  {
    icon: <ListChecksIcon size={17} />,
    title: `Adapted to: ${category ? t(category.labelKey) : 'your profile'}`,
    body: CATEGORY_NOTE[profile.userCategory] ?? CATEGORY_NOTE.other
  },
  {
    icon: <BrainCircuitIcon size={17} />,
    title: 'A model reads your profile',
    body: `Your answers become a feature profile the recommendation model ranks against. You get: ${JOURNEY_META[journey].outcome.toLowerCase()}.`
  },
  {
    icon: <ShieldCheckIcon size={17} />,
    title: 'You can pause anytime',
    body: 'Answers are saved as you go, so you can go back or resume later.'
  }];


  return (
    <Screen
      header={
      <ScreenHeader
        title={JOURNEY_META[journey].label}
        subtitle="Before we begin"
        onBack={() => navigate('/onboarding/path')} />

      }
      footer={
      <div className="space-y-2.5">
          <Button fullWidth onClick={() => navigate('/assessment')}>
            {hasProgress ? t('asmt.resume') : t('asmt.start')}
          </Button>
          <button
          type="button"
          onClick={() => navigate('/onboarding/path')}
          className="min-h-[44px] w-full text-[13px] font-semibold text-navy-muted hover:text-brand-700">
          
            Choose a different journey
          </button>
        </div>
      }>
      
      <h1 className="text-[23px] font-bold leading-tight text-navy">{headline.title}</h1>
      <p className="mt-2.5 text-[13.5px] leading-relaxed text-navy-muted">{headline.body}</p>

      <ul className="mt-6 space-y-3">
        {points.map((point) =>
        <li key={point.title} className="flex gap-3 rounded-xl border border-hairline bg-white p-3.5">
            <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-brand-700">
              {point.icon}
            </span>
            <div className="min-w-0">
              <p className="text-[14px] font-semibold text-navy">{point.title}</p>
              <p className="mt-0.5 text-[12.5px] leading-relaxed text-navy-muted">{point.body}</p>
            </div>
          </li>
        )}
      </ul>

      <p className="mt-5 rounded-xl bg-brand-50 p-3.5 text-[12px] leading-relaxed text-brand-800">
        SkillBridgeAI recommends, it does not decide. Results are AI-assisted suggestions based on your
        answers — a starting point for exploration, not a validated prediction.
      </p>
    </Screen>);

}