import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { useT } from '../i18n';

const SLIDES = [
{
  key: 'walk.1.title',
  body: 'We help you discover the right path, skills and opportunities that truly align with who you are.',
  image: "/8be0bea7-ed7d-42ec-86e3-892fb81ee1da.jpg",
  alt: 'Student at a desk surrounded by questions and ideas'
},
{
  key: 'walk.2.title',
  body: 'A short assessment maps your strengths, interests and confidence — so guidance is based on you, not guesswork.',
  image: "/8b44a7d1-116a-456a-9bdf-533436f65408.jpg",
  alt: 'Person climbing ascending blocks towards a goal flag'
},
{
  key: 'walk.3.title',
  body: 'Get career matches, a skill gap view and a step-by-step roadmap tailored to your goals and strengths.',
  image: "/b4176bd3-a333-4b94-aeb9-344f1a5314c5.jpg",
  alt: 'Team collaborating around a growth chart'
}];


export function Walkthrough() {
  const navigate = useNavigate();
  const { t } = useT();
  const [index, setIndex] = useState(0);
  const slide = SLIDES[index];
  const isLast = index === SLIDES.length - 1;

  const finish = () => navigate('/login', { replace: true });

  return (
    <div className="flex h-full w-full flex-col bg-surface">
      <div className="flex shrink-0 justify-end px-5 pt-[max(20px,env(safe-area-inset-top))] sm:pt-10">
        <button
          type="button"
          onClick={finish}
          className="min-h-[44px] px-2 text-[13px] font-semibold uppercase tracking-wide text-navy-muted transition-colors duration-150 ease-out hover:text-navy">
          
          {t('common.skip')}
        </button>
      </div>

      <div className="flex flex-1 flex-col justify-center px-7">
        <AnimatePresence mode="wait">
          <motion.div
            key={index}
            initial={{ opacity: 0, x: 16 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -16 }}
            transition={{ duration: 0.22, ease: [0.23, 1, 0.32, 1] }}>
            
            <img src={slide.image} alt={slide.alt} className="mx-auto h-56 w-56 object-contain" />
            <h1 className="mt-10 whitespace-pre-line text-[26px] font-bold leading-[1.2] tracking-tight text-navy">
              {t(slide.key)}
            </h1>
            <span className="mt-4 block h-1 w-12 rounded-full bg-brand-600" />
            <p className="mt-4 max-w-[300px] text-[14px] leading-relaxed text-navy-muted">{slide.body}</p>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="shrink-0 px-7 pb-[max(24px,env(safe-area-inset-bottom))] pt-6">
        <div className="mb-5 flex items-center gap-2" role="tablist" aria-label="Walkthrough progress">
          {SLIDES.map((s, i) =>
          <button
            key={s.key}
            type="button"
            role="tab"
            aria-selected={i === index}
            aria-label={`${i + 1} / ${SLIDES.length}`}
            onClick={() => setIndex(i)}
            className="py-3">
            
              <span
              className={`block h-2 rounded-full transition-[width,background-color] duration-200 ease-out ${
              i === index ? 'w-7 bg-brand-600' : 'w-2 bg-brand-200'}`
              } />
            
            </button>
          )}
          <span className="ml-auto text-[12px] font-medium text-navy-muted">
            {index + 1} {t('common.of')} {SLIDES.length}
          </span>
        </div>

        <Button fullWidth onClick={() => isLast ? finish() : setIndex((i) => i + 1)}>
          {isLast ? t('common.getStarted') : t('common.next')}
        </Button>
      </div>
    </div>);

}