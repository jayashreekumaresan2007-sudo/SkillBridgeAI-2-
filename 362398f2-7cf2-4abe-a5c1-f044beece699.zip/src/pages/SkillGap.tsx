import React from 'react';
import { ArrowRightIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { GuestGate } from '../components/GuestGate';
import { LevelTag } from '../components/ui/LevelTag';
import { ProgressBar } from '../components/ui/ProgressBar';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { CAREERS } from '../data/careers';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';

const LEVEL_KEYS = {
  Strong: 'gap.strong',
  Developing: 'gap.developing',
  'Needs Improvement': 'gap.needs'
} as const;

export function SkillGap() {
  const navigate = useNavigate();
  const { profile, skillGap } = useUser();
  const { t } = useT();
  const careerId = profile.selectedCareer ?? profile.recommendations[0]?.careerId ?? null;

  if (profile.isGuest) {
    return (
      <Screen header={<ScreenHeader title="Skill gap" />}>
        <GuestGate
          feature="Skill gap analysis"
          description="Your skill gap is built from your own assessment answers, so it needs an account to save your profile." />
        
      </Screen>);

  }

  if (!careerId || skillGap.length === 0) {
    return (
      <Screen header={<ScreenHeader title="Skill gap" />}>
        <EmptyState
          title="No skill gap yet"
          message="Pick a recommended career and we’ll compare it against your current profile."
          action={<Button onClick={() => navigate('/assessment/intro')}>Start assessment</Button>} />
        
      </Screen>);

  }

  const career = CAREERS[careerId];
  const grouped = {
    Strong: skillGap.filter((s) => s.level === 'Strong'),
    Developing: skillGap.filter((s) => s.level === 'Developing'),
    'Needs Improvement': skillGap.filter((s) => s.level === 'Needs Improvement')
  };

  return (
    <Screen
      header={<ScreenHeader title={t('gap.title')} subtitle={career.title} />}
      footer={
      <Button fullWidth onClick={() => navigate('/roadmap')} iconRight={<ArrowRightIcon size={17} />}>
          {t('gap.build')}
        </Button>
      }>
      
      <p className="text-[13.5px] leading-relaxed text-navy-muted">
        Your self-rated profile compared with what a <strong className="text-navy">{career.title}</strong>{' '}
        typically needs.
      </p>

      <div className="mt-4 grid grid-cols-3 gap-2.5">
        {(['Strong', 'Developing', 'Needs Improvement'] as const).map((level) =>
        <div key={level} className="rounded-xl border border-hairline bg-white p-3 text-center">
            <p className="text-[20px] font-bold text-navy">{grouped[level].length}</p>
            <p className="mt-0.5 text-[11px] font-medium leading-tight text-navy-muted">{t(LEVEL_KEYS[level], level)}</p>
          </div>
        )}
      </div>

      <ul className="mt-5 space-y-3">
        {skillGap.map((skill) =>
        <li key={skill.name} className="rounded-2xl border border-hairline bg-white p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="text-[14px] font-semibold text-navy">{skill.name}</p>
                <p className="mt-0.5 text-[12px] text-navy-muted">
                  Role importance: {skill.weight >= 0.9 ? 'Core' : skill.weight >= 0.7 ? 'Important' : 'Supporting'}
                </p>
              </div>
              <LevelTag level={skill.level} />
            </div>
            <div className="mt-3 flex items-center gap-3">
              <ProgressBar value={skill.value} size="sm" label={`${skill.name} confidence`} />
              <span className="w-9 shrink-0 text-right text-[12px] font-semibold text-navy-muted">{skill.value}%</span>
            </div>
          </li>
        )}
      </ul>

      <p className="mt-5 rounded-xl bg-brand-50 p-3.5 text-[11.5px] leading-relaxed text-brand-800">
        Levels are derived from your self-ratings and preferences in the assessment, mapped to the skills
        this career requires. Re-take the assessment anytime to update them.
      </p>
    </Screen>);

}