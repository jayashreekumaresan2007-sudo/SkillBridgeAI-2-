import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { LevelTag } from '../components/ui/LevelTag';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { CAREERS } from '../data/careers';
import { buildSkillGap } from '../ml/skillGap';
import { useUser } from '../contexts/UserContext';
import type { CareerCategoryId } from '../types';

export function CareerCompare() {
  const navigate = useNavigate();
  const { profile, update } = useUser();
  const options = profile.recommendations.map((r) => r.careerId);
  const [left, setLeft] = useState<CareerCategoryId | null>(options[0] ?? null);
  const [right, setRight] = useState<CareerCategoryId | null>(options[1] ?? null);

  if (options.length < 2) {
    return (
      <Screen header={<ScreenHeader title="Compare careers" />}>
        <EmptyState
          title="Nothing to compare yet"
          message="Complete the assessment to get recommended careers you can compare side by side."
          action={<Button onClick={() => navigate('/assessment/intro')}>Start assessment</Button>} />
        
      </Screen>);

  }

  const pick = (id: CareerCategoryId, side: 'left' | 'right') => {
    if (side === 'left') setLeft(id === right ? left : id);else
    setRight(id === left ? right : id);
  };

  const columns = ([left, right].filter(Boolean) as CareerCategoryId[]).map((id) => {
    const career = CAREERS[id];
    const gap = buildSkillGap(id, profile.features);
    return {
      id,
      career,
      match: profile.recommendations.find((r) => r.careerId === id)?.match ?? 0,
      gap,
      weakest: gap[0]
    };
  });

  return (
    <Screen
      header={<ScreenHeader title="Compare careers" subtitle="Two at a time, side by side" />}
      footer={
      <Button
        fullWidth
        disabled={!left}
        onClick={() => {
          if (left) update({ selectedCareer: left });
          navigate('/roadmap');
        }}>
        
          Continue with {left ? CAREERS[left].title : ''}
        </Button>
      }>
      
      {(['left', 'right'] as const).map((side) =>
      <div key={side} className="mb-3">
          <label className="mb-1.5 block text-[12.5px] font-semibold text-navy">
            {side === 'left' ? 'First career' : 'Second career'}
          </label>
          <select
          value={(side === 'left' ? left : right) ?? ''}
          onChange={(e) => pick(e.target.value as CareerCategoryId, side)}
          className="min-h-[48px] w-full rounded-xl border border-hairline bg-white px-3.5 text-[14px] font-medium text-navy focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-200">
          
            {options.map((id) =>
          <option key={id} value={id}>
                {CAREERS[id].title}
              </option>
          )}
          </select>
        </div>
      )}

      <div className="mt-5 space-y-4">
        {[
        { label: 'Match', render: (c: (typeof columns)[number]) => <span className="text-[15px] font-bold text-brand-700">{c.match}%</span> },
        {
          label: 'Required skills',
          render: (c: (typeof columns)[number]) =>
          <span className="text-[12.5px] leading-relaxed text-navy-soft">
                {c.career.requiredSkills.slice(0, 4).map((s) => s.name).join(', ')}
              </span>

        },
        {
          label: 'Learning path',
          render: (c: (typeof columns)[number]) =>
          <span className="text-[12.5px] leading-relaxed text-navy-soft">{c.career.learningPath.slice(0, 3).join(' → ')}</span>

        },
        {
          label: 'Typical responsibilities',
          render: (c: (typeof columns)[number]) =>
          <span className="text-[12.5px] leading-relaxed text-navy-soft">{c.career.responsibilities}</span>

        },
        {
          label: 'Biggest skill gap',
          render: (c: (typeof columns)[number]) =>
          c.weakest ?
          <span className="flex flex-col items-start gap-1.5">
                  <span className="text-[12.5px] font-semibold text-navy">{c.weakest.name}</span>
                  <LevelTag level={c.weakest.level} />
                </span> :

          <span className="text-[12.5px] text-navy-muted">—</span>

        }].
        map((row) =>
        <section key={row.label} className="rounded-2xl border border-hairline bg-white p-4">
            <h2 className="mb-3 text-[12px] font-semibold uppercase tracking-wide text-navy-muted">{row.label}</h2>
            <div className="grid grid-cols-2 gap-3">
              {columns.map((column) =>
            <div key={column.id}>
                  <p className="mb-1.5 text-[12.5px] font-bold text-navy">{column.career.title}</p>
                  {row.render(column)}
                </div>
            )}
            </div>
          </section>
        )}
      </div>
    </Screen>);

}