import React, { useState } from 'react';
import { AlertCircleIcon, ArrowRightIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Logo } from '../components/Logo';
import { Button } from '../components/ui/Button';
import { TextField } from '../components/ui/TextField';
import { SocialAuthButtons } from '../components/SocialAuthButtons';
import { AuthAccountSheet } from '../components/AuthAccountSheet';
import type { AuthProvider } from '../components/AuthAccountSheet';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function Login() {
  const navigate = useNavigate();
  const { login, loginAsGuest, profile } = useUser();
  const { t } = useT();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(true);
  const [errors, setErrors] = useState<{email?: string;password?: string;}>({});
  const [formError, setFormError] = useState('');
  const [loading, setLoading] = useState(false);
  const [provider, setProvider] = useState<AuthProvider | null>(null);

  const afterAuth = () => profile.userCategory ? '/dashboard' : '/onboarding/language';

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    const next: typeof errors = {};
    if (!EMAIL_RE.test(email)) next.email = t('err.email');
    if (password.length < 6) next.password = t('err.passwordShort');
    setErrors(next);
    setFormError('');
    if (Object.keys(next).length) return;

    setLoading(true);
    window.setTimeout(() => {
      setLoading(false);
      if (password.toLowerCase() === 'wrongpass') {
        setFormError(t('err.credentials'));
        return;
      }
      login(email.split('@')[0].replace(/\b\w/g, (c) => c.toUpperCase()), email);
      navigate(afterAuth(), { replace: true });
    }, 700);
  };

  return (
    <div className="relative h-full w-full">
      <div className="no-scrollbar h-full overflow-y-auto bg-surface px-6 pb-10 pt-[max(28px,env(safe-area-inset-top))] sm:pt-14">
        <Logo size={40} />
        <h1 className="mt-5 text-[25px] font-bold leading-tight text-navy">{t('auth.welcome')}</h1>
        <p className="mt-1.5 text-[13.5px] text-navy-muted">
          Sign in to continue your career journey where you left off.
        </p>

        {formError &&
        <div
          role="alert"
          className="mt-5 flex items-start gap-2 rounded-xl border border-bad/25 bg-badSoft px-3.5 py-3 text-[13px] font-medium text-bad">
          
            <AlertCircleIcon size={16} className="mt-0.5 shrink-0" />
            <span>{formError}</span>
          </div>
        }

        <form onSubmit={submit} noValidate className="mt-6 space-y-4">
          <TextField
            label={t('auth.email')}
            type="email"
            inputMode="email"
            autoComplete="email"
            placeholder="you@example.com"
            value={email}
            error={errors.email}
            onChange={(e) => setEmail(e.target.value)} />
          
          <TextField
            label={t('auth.password')}
            showToggle
            autoComplete="current-password"
            placeholder="••••••••"
            value={password}
            error={errors.password}
            onChange={(e) => setPassword(e.target.value)} />
          

          <div className="flex items-center justify-between">
            <label className="flex min-h-[44px] cursor-pointer items-center gap-2.5 text-[13px] font-medium text-navy">
              <input
                type="checkbox"
                checked={remember}
                onChange={(e) => setRemember(e.target.checked)}
                className="h-[18px] w-[18px] rounded border-hairline text-brand-600 focus:ring-brand-300" />
              
              {t('auth.remember')}
            </label>
            <button
              type="button"
              onClick={() => navigate('/forgot-password')}
              className="min-h-[44px] text-[13px] font-semibold text-brand-700 hover:underline">
              
              {t('auth.forgot')}
            </button>
          </div>

          <Button type="submit" fullWidth loading={loading}>
            {t('auth.login')}
          </Button>
        </form>

        <SocialAuthButtons onSelect={setProvider} />

        <div className="mt-7 space-y-3 border-t border-hairline pt-5">
          <Button variant="outline" fullWidth onClick={() => navigate('/create-account')}>
            {t('auth.createAccount')}
          </Button>
          <button
            type="button"
            onClick={() => {
              loginAsGuest();
              navigate('/careers', { replace: true });
            }}
            className="flex min-h-[44px] w-full items-center justify-center gap-1.5 text-[13.5px] font-semibold text-navy-muted transition-colors duration-150 ease-out hover:text-brand-700">
            
            {t('auth.guest')}
            <ArrowRightIcon size={15} />
          </button>
        </div>
      </div>

      {provider &&
      <AuthAccountSheet
        provider={provider}
        onClose={() => setProvider(null)}
        onSelect={(account) => {
          setProvider(null);
          login(account.name, account.email);
          navigate(afterAuth(), { replace: true });
        }} />

      }
    </div>);

}