import React, { useState } from 'react';
import { CheckIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { DynamicIcon } from '../components/ui/DynamicIcon';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { USER_CATEGORIES } from '../data/avatars';
import { useUser } from '../contexts/UserContext';
import { LANGUAGE_CODES, LANGUAGE_NATIVE, useT } from '../i18n';
import type { LanguageCode } from '../i18n';

export function LanguageCategory() {
  const navigate = useNavigate();
  const { profile, update } = useUser();
  const { t, language } = useT();
  const [category, setCategory] = useState(profile.userCategory);

  return (
    <Screen
      header={<ScreenHeader title={t('onb.personalise')} subtitle="1 / 3" onBack={() => navigate('/login')} />}
      footer={
      <Button
        fullWidth
        disabled={!category}
        onClick={() => {
          update({ userCategory: category });
          navigate('/onboarding/avatar');
        }}>
        
          {t('common.continue')}
        </Button>
      }>
      
      <section aria-labelledby="lang-heading">
        <div className="flex items-center gap-2.5">
          <span className="flex h-6 w-6 items-center justify-center rounded-full bg-brand-600 text-[12px] font-bold text-white">
            1
          </span>
          <h2 id="lang-heading" className="text-[16px] font-bold text-navy">
            {t('onb.language')}
          </h2>
        </div>
        <p className="mb-3.5 mt-1 text-[12.5px] text-navy-muted">{t('onb.languageHint')}</p>

        <div className="grid grid-cols-2 gap-2.5" role="radiogroup" aria-labelledby="lang-heading">
          {LANGUAGE_CODES.map((code: LanguageCode) => {
            const selected = language === code;
            return (
              <button
                key={code}
                type="button"
                role="radio"
                aria-checked={selected}
                onClick={() => update({ language: code })}
                className={`flex min-h-[62px] items-center justify-between gap-2 rounded-xl border px-3.5 text-left transition-colors duration-150 ease-out ${
                selected ? 'border-brand-600 bg-brand-50 ring-1 ring-brand-600' : 'border-hairline bg-white hover:border-brand-300'}`
                }>
                
                <span className="min-w-0">
                  <span className={`block truncate text-[14px] font-semibold ${selected ? 'text-brand-800' : 'text-navy'}`}>
                    {LANGUAGE_NATIVE[code]}
                  </span>
                  <span className="block truncate text-[11.5px] text-navy-muted">{code}</span>
                </span>
                {selected &&
                <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-brand-600 text-white">
                    <CheckIcon size={13} strokeWidth={3} />
                  </span>
                }
              </button>);

          })}
        </div>
      </section>

      <section aria-labelledby="cat-heading" className="mt-8">
        <div className="flex items-center gap-2.5">
          <span className="flex h-6 w-6 items-center justify-center rounded-full bg-brand-600 text-[12px] font-bold text-white">
            2
          </span>
          <h2 id="cat-heading" className="text-[16px] font-bold text-navy">
            {t('onb.describe')}
          </h2>
        </div>
        <div className="mt-3.5 grid grid-cols-2 gap-2.5" role="radiogroup" aria-labelledby="cat-heading">
          {USER_CATEGORIES.map((option) => {
            const selected = category === option.id;
            return (
              <button
                key={option.id}
                type="button"
                role="radio"
                aria-checked={selected}
                onClick={() => setCategory(option.id)}
                className={`relative flex min-h-[92px] flex-col items-start justify-between gap-2 rounded-xl border p-3.5 text-left transition-colors duration-150 ease-out ${
                selected ? 'border-brand-600 bg-brand-50 ring-1 ring-brand-600' : 'border-hairline bg-white hover:border-brand-300'}`
                }>
                
                <span
                  className={`flex h-9 w-9 items-center justify-center rounded-lg ${
                  selected ? 'bg-brand-600 text-white' : 'bg-brand-50 text-brand-700'}`
                  }>
                  
                  <DynamicIcon name={option.icon} size={18} />
                </span>
                <span className={`text-[13.5px] font-semibold leading-snug ${selected ? 'text-brand-800' : 'text-navy'}`}>
                  {t(option.labelKey)}
                </span>
                {selected &&
                <span className="absolute right-3 top-3 flex h-5 w-5 items-center justify-center rounded-full bg-brand-600 text-white">
                    <CheckIcon size={12} strokeWidth={3} />
                  </span>
                }
              </button>);

          })}
        </div>
      </section>
    </Screen>);

}