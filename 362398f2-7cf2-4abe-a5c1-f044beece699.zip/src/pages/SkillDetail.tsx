import React, { useMemo, useState } from 'react';
import {
  BookOpenIcon,
  DumbbellIcon,
  GraduationCapIcon,
  FileTextIcon,
  MapPinIcon,
  TagIcon,
  WrenchIcon } from
'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { BookmarkButton } from '../components/ui/BookmarkButton';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { LevelTag } from '../components/ui/LevelTag';
import { ProgressBar } from '../components/ui/ProgressBar';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { VerifySheet } from '../components/VerifySheet';
import { ACADEMIES } from '../data/academies';
import { toolkitFor } from '../data/skillToolkits';
import { featureForSkill, levelFor } from '../ml/skillProfile';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';

function teaches(academySkills: string[], skill: string) {
  const target = skill.toLowerCase();
  return academySkills.some((s) => {
    const value = s.toLowerCase();
    return value === target || value.includes(target) || target.includes(value);
  });
}

export function SkillDetail() {
  const navigate = useNavigate();
  const { skillId } = useParams();
  const { profile, update, toggleSaved, isSaved, skillRecommendations } = useUser();
  const { t } = useT();
  const skill = decodeURIComponent(skillId ?? '');
  const [verifying, setVerifying] = useState<string | null>(null);
  const [note, setNote] = useState(profile.skillNotes[skill] ?? '');
  const [noteSaved, setNoteSaved] = useState(false);

  const toolkit = toolkitFor(skill);
  const recommendation = skillRecommendations.find((s) => s.name === skill);
  const value = profile.features ? profile.features[featureForSkill(skill)] : 0;
  const level = levelFor(value);

  const courses = useMemo(() => ACADEMIES.filter((a) => teaches(a.skills, skill)), [skill]);

  if (!skill) {
    return (
      <Screen header={<ScreenHeader title="Skill" onBack={() => navigate('/skill-results')} />}>
        <EmptyState title="Skill not found" message="Pick a skill from your profile to see its toolkit." />
      </Screen>);

  }

  const saveNote = () => {
    update({ skillNotes: { ...profile.skillNotes, [skill]: note } });
    setNoteSaved(true);
    window.setTimeout(() => setNoteSaved(false), 2000);
  };

  const sections = [
  { title: 'Tools', icon: <WrenchIcon size={16} />, items: toolkit.tools },
  { title: 'Keywords to learn', icon: <TagIcon size={16} />, items: toolkit.keywords },
  { title: 'Practice ideas', icon: <DumbbellIcon size={16} />, items: toolkit.practice },
  { title: 'Resources', icon: <BookOpenIcon size={16} />, items: toolkit.resources }];


  return (
    <div className="relative h-full w-full">
      <Screen
        header={<ScreenHeader title={skill} subtitle={t('skill.toolkit')} onBack={() => navigate('/skill-results')} />}
        footer={
        <Button fullWidth onClick={() => navigate('/academies')}>
            See all courses for this skill
          </Button>
        }>
        
        <section className="rounded-2xl border border-hairline bg-white p-4 shadow-card">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <h2 className="text-[15px] font-bold text-navy">Where you are now</h2>
              <p className="mt-1 text-[12.5px] text-navy-muted">Estimated from your assessment answers.</p>
            </div>
            <LevelTag level={level} />
          </div>
          <div className="mt-3 flex items-center gap-3">
            <ProgressBar value={value * 100} size="sm" tone={level === 'Strong' ? 'good' : 'brand'} label={skill} />
            <span className="w-10 shrink-0 text-right text-[12px] font-semibold text-navy-muted">
              {Math.round(value * 100)}%
            </span>
          </div>
          {recommendation &&
          <p className="mt-3 text-[12.5px] leading-relaxed text-navy-soft">
              <span className="font-semibold text-navy">{t('skill.why')} </span>
              {recommendation.reason}
            </p>
          }
        </section>

        {sections.map((section) =>
        <section key={section.title} className="mt-4 rounded-2xl border border-hairline bg-white p-4">
            <h2 className="flex items-center gap-2 text-[14px] font-bold text-navy">
              <span className="text-brand-600">{section.icon}</span>
              {section.title}
            </h2>
            <ul className="mt-2.5 space-y-1.5">
              {section.items.map((item) =>
            <li key={item} className="flex gap-2 text-[12.5px] leading-relaxed text-navy-soft">
                  <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-brand-600" />
                  {item}
                </li>
            )}
            </ul>
          </section>
        )}

        <section className="mt-4 rounded-2xl border border-hairline bg-white p-4">
          <h2 className="flex items-center gap-2 text-[14px] font-bold text-navy">
            <FileTextIcon size={16} className="text-brand-600" />
            My notes
          </h2>
          <label htmlFor="skill-note" className="sr-only">
            Notes for {skill}
          </label>
          <textarea
            id="skill-note"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            rows={3}
            placeholder={`What you want to remember about ${skill}…`}
            className="mt-2.5 w-full resize-none rounded-xl border border-hairline bg-canvas p-3 text-[13px] text-navy placeholder:text-navy-muted/75 focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-200" />
          
          <div className="mt-2.5 flex items-center gap-3">
            <Button className="min-h-[42px]" onClick={saveNote}>
              Save note
            </Button>
            {noteSaved &&
            <span role="status" className="text-[12.5px] font-semibold text-good">
                Saved
              </span>
            }
          </div>
        </section>

        <section className="mt-6">
          <h2 className="text-[16px] font-bold text-navy">{t('skill.whereToLearn')}</h2>
          <p className="mt-1 text-[12.5px] leading-relaxed text-navy-muted">
            Providers whose listed course covers {skill}. Sample data for this prototype — verify everything
            with the provider.
          </p>

          <div className="mt-3.5 space-y-3">
            {courses.length === 0 ?
            <EmptyState
              title="No course found for this skill"
              message="Try browsing all academies — a broader course may still cover it."
              icon={<GraduationCapIcon size={22} />}
              action={
              <Button variant="outline" onClick={() => navigate('/academies')}>
                    Browse academies
                  </Button>
              } /> :


            courses.map((course) =>
            <article key={course.id} className="rounded-2xl border border-hairline bg-white p-4 shadow-card">
                  <div className="flex items-start gap-3">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
                      <GraduationCapIcon size={19} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <h3 className="text-[14.5px] font-bold leading-snug text-navy">{course.course}</h3>
                      <p className="mt-0.5 truncate text-[12.5px] text-navy-muted">{course.name}</p>
                    </div>
                    <BookmarkButton
                  compact
                  saved={isSaved('savedAcademies', course.id)}
                  onToggle={() => toggleSaved('savedAcademies', course.id)}
                  label={course.course} />
                
                  </div>

                  <div className="mt-2.5 flex flex-wrap items-center gap-2 text-[11.5px] font-semibold text-navy-soft">
                    <span className="rounded-md bg-canvas px-2 py-1">{course.mode}</span>
                    <span className="rounded-md bg-canvas px-2 py-1">{course.level}</span>
                    <span className="rounded-md bg-canvas px-2 py-1">{course.duration}</span>
                    <span className="flex items-center gap-1 rounded-md bg-canvas px-2 py-1">
                      <MapPinIcon size={12} />
                      {course.location}
                    </span>
                  </div>

                  <p className="mt-2.5 text-[12.5px] leading-relaxed text-navy-muted">
                    <span className="font-semibold text-navy">Covers: </span>
                    {course.skills.join(', ')}
                  </p>

                  <button
                type="button"
                onClick={() => setVerifying(course.name)}
                className="mt-3 flex min-h-[44px] w-full items-center justify-center rounded-xl bg-brand-50 text-[13.5px] font-semibold text-brand-700 transition-colors duration-150 ease-out hover:bg-brand-100">
                
                    Contact this provider
                  </button>
                </article>
            )
            }
          </div>
        </section>
      </Screen>

      {verifying &&
      <VerifySheet
        providerName={verifying}
        onConfirm={() => setVerifying(null)}
        onBack={() => {
          setVerifying(null);
          navigate('/academies');
        }} />

      }
    </div>);

}