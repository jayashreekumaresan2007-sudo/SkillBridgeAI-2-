import React, { useState } from 'react';
import { CheckCircle2Icon, MailCheckIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { TextField } from '../components/ui/TextField';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
type Stage = 'email' | 'verify' | 'reset' | 'done';

const TITLES: Record<Stage, {title: string;step: string;}> = {
  email: { title: 'Forgot password', step: 'Step 1 of 3' },
  verify: { title: 'Verify it’s you', step: 'Step 2 of 3' },
  reset: { title: 'Set a new password', step: 'Step 3 of 3' },
  done: { title: 'Password updated', step: 'Complete' }
};

export function ForgotPassword() {
  const navigate = useNavigate();
  const [stage, setStage] = useState<Stage>('email');
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const goBack = () => {
    if (stage === 'email') navigate('/login');else
    if (stage === 'verify') setStage('email');else
    if (stage === 'reset') setStage('verify');else
    navigate('/login');
  };

  const submitEmail = () => {
    if (!EMAIL_RE.test(email)) return setError('Enter a valid email address');
    setError('');
    setLoading(true);
    window.setTimeout(() => {
      setLoading(false);
      setStage('verify');
    }, 600);
  };

  const submitCode = () => {
    if (code.trim().length !== 6) return setError('Enter the 6-digit code we sent you');
    setError('');
    setStage('reset');
  };

  const submitPassword = () => {
    if (password.length < 8) return setError('Use at least 8 characters');
    if (password !== confirm) return setError('Passwords do not match');
    setError('');
    setStage('done');
  };

  return (
    <Screen
      tone="white"
      header={<ScreenHeader title={TITLES[stage].title} subtitle={TITLES[stage].step} onBack={goBack} />}
      footer={
      stage === 'email' ?
      <Button fullWidth loading={loading} onClick={submitEmail}>
            Send reset code
          </Button> :
      stage === 'verify' ?
      <Button fullWidth onClick={submitCode}>
            Verify code
          </Button> :
      stage === 'reset' ?
      <Button fullWidth onClick={submitPassword}>
            Update password
          </Button> :

      <Button fullWidth onClick={() => navigate('/login', { replace: true })}>
            Back to login
          </Button>

      }>
      
      {stage === 'email' &&
      <div className="space-y-5">
          <p className="text-[13.5px] leading-relaxed text-navy-muted">
            Enter the email linked to your SkillBridgeAI account and we’ll send a 6-digit reset code.
          </p>
          <TextField
          label="Email"
          type="email"
          inputMode="email"
          placeholder="you@example.com"
          value={email}
          error={error}
          onChange={(e) => setEmail(e.target.value)} />
        
        </div>
      }

      {stage === 'verify' &&
      <div className="space-y-5">
          <div className="flex items-start gap-3 rounded-xl bg-brand-50 p-4">
            <MailCheckIcon size={18} className="mt-0.5 shrink-0 text-brand-700" />
            <p className="text-[13px] leading-relaxed text-brand-800">
              We sent a code to <strong>{email}</strong>. In this prototype, any 6 digits will work.
            </p>
          </div>
          <TextField
          label="Verification code"
          inputMode="numeric"
          maxLength={6}
          placeholder="123456"
          value={code}
          error={error}
          onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} />
        
          <button type="button" className="min-h-[44px] text-[13px] font-semibold text-brand-700 hover:underline">
            Resend code
          </button>
        </div>
      }

      {stage === 'reset' &&
      <div className="space-y-4">
          <p className="text-[13.5px] leading-relaxed text-navy-muted">
            Choose a new password you haven’t used before.
          </p>
          <TextField
          label="New password"
          showToggle
          hint="At least 8 characters"
          value={password}
          onChange={(e) => setPassword(e.target.value)} />
        
          <TextField
          label="Confirm new password"
          showToggle
          value={confirm}
          error={error}
          onChange={(e) => setConfirm(e.target.value)} />
        
        </div>
      }

      {stage === 'done' &&
      <div className="flex flex-col items-center pt-14 text-center">
          <span className="flex h-16 w-16 items-center justify-center rounded-full bg-goodSoft text-good">
            <CheckCircle2Icon size={32} />
          </span>
          <h2 className="mt-5 text-[20px] font-bold text-navy">Password updated</h2>
          <p className="mt-2 max-w-[270px] text-[13.5px] leading-relaxed text-navy-muted">
            You can now log in with your new password.
          </p>
        </div>
      }
    </Screen>);

}