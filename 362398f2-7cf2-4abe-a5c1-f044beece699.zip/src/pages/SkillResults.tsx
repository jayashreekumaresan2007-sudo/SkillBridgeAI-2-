import React from 'react';
import { ChevronRightIcon, InfoIcon, TargetIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { LevelTag } from '../components/ui/LevelTag';
import { ProgressBar } from '../components/ui/ProgressBar';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { SKILL_ADVICE_LABEL } from '../ml/skillProfile';
import { modelSummary } from '../ml/service';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';
import type { SkillAdviceKind, SkillLevel } from '../types';

const GROUPS: {level: SkillLevel;blurb: string;}[] = [
{ level: 'Strong', blurb: 'Lead with these — they are already evidence you can point to.' },
{ level: 'Developing', blurb: 'Real but inconsistent. A focused month moves each one up.' },
{ level: 'Needs Improvement', blurb: 'Low signal in your answers. Pick one, not all of them.' }];


const KIND_STYLES: Record<SkillAdviceKind, string> = {
  learn: 'bg-badSoft text-bad',
  improve: 'bg-warnSoft text-warn',
  strengthen: 'bg-goodSoft text-good',
  complementary: 'bg-brand-50 text-brand-800',
  emerging: 'bg-navy text-white'
};

export function SkillResults() {
  const navigate = useNavigate();
  const { profile, skillProfile, skillRecommendations, update } = useUser();
  const { t } = useT();
  const model = modelSummary();

  if (!profile.features || skillProfile.length === 0 || skillRecommendations.length === 0) {
    return (
      <Screen header={<ScreenHeader title="Skill profile" onBack={() => navigate('/dashboard')} />}>
        <EmptyState
          title="No skill profile yet"
          message="Complete the skill assessment and we’ll map your strengths and gaps."
          icon={<TargetIcon size={22} />}
          action={<Button onClick={() => navigate('/assessment/intro')}>{t('asmt.start')}</Button>} />
        
      </Screen>);

  }

  const strong = skillProfile.filter((s) => s.level === 'Strong');
  const priority = skillRecommendations.filter((s) => s.kind === 'learn' || s.kind === 'improve');

  const openSkill = (name: string) => {
    update({ focusSkill: name });
    navigate(`/skills/${encodeURIComponent(name)}`);
  };

  return (
    <Screen
      header={
      <ScreenHeader
        title={t('skill.profile')}
        subtitle="Based on your assessment"
        onBack={() => navigate('/dashboard')} />

      }
      footer={
      <Button
        fullWidth
        onClick={() => openSkill(priority[0]?.name ?? skillRecommendations[0].name)}
        iconRight={<ChevronRightIcon size={17} />}>
        
          Start with {priority[0]?.name ?? skillRecommendations[0].name}
        </Button>
      }>
      
      <section className="rounded-2xl bg-navy p-5 text-white">
        <h2 className="text-[12px] font-semibold uppercase tracking-wide text-brand-300">Where you are today</h2>
        <p className="mt-2 text-[15px] font-semibold leading-snug">
          {strong.length > 0 ?
          `${strong.slice(0, 2).map((s) => s.name).join(' and ')} came through as your clearest strengths.` :
          'Your profile is still broad — no single skill dominates yet.'}
        </p>
        <p className="mt-2 text-[12.5px] leading-relaxed text-brand-100">
          {priority.length > 0 ?
          `${priority.length} skills are worth prioritising next, starting with ${priority[0].name}.` :
          'Keep building evidence in your strongest skills.'}
        </p>
      </section>

      {GROUPS.map((group) => {
        const items = skillProfile.filter((s) => s.level === group.level);
        if (items.length === 0) return null;
        return (
          <section key={group.level} className="mt-5">
            <div className="flex items-center justify-between gap-3">
              <h2 className="text-[15px] font-bold text-navy">{group.level}</h2>
              <LevelTag level={group.level} />
            </div>
            <p className="mt-1 text-[12.5px] leading-relaxed text-navy-muted">{group.blurb}</p>
            <ul className="mt-3 space-y-2.5">
              {items.map((item) =>
              <li key={item.id} className="rounded-xl border border-hairline bg-white p-3.5">
                  <div className="flex items-baseline justify-between gap-3">
                    <span className="text-[13.5px] font-semibold text-navy">{item.name}</span>
                    <span className="shrink-0 text-[12px] font-semibold text-navy-muted">
                      {Math.round(item.value * 100)}%
                    </span>
                  </div>
                  <div className="mt-2">
                    <ProgressBar
                    value={item.value * 100}
                    size="sm"
                    tone={item.level === 'Strong' ? 'good' : 'brand'}
                    label={item.name} />
                  
                  </div>
                  <p className="mt-2 text-[12px] leading-relaxed text-navy-muted">{item.note}</p>
                </li>
              )}
            </ul>
          </section>);

      })}

      <section className="mt-7">
        <h2 className="text-[16px] font-bold text-navy">{t('skill.toWorkOn')}</h2>
        <p className="mt-1 text-[12.5px] leading-relaxed text-navy-muted">
          Chosen from the roles your profile matches. Tap one for its toolkit and real courses.
        </p>
        <ul className="mt-3.5 space-y-3">
          {skillRecommendations.map((skill) =>
          <li key={skill.id}>
              <button
              type="button"
              onClick={() => openSkill(skill.name)}
              className="w-full rounded-2xl border border-hairline bg-white p-4 text-left shadow-card transition-colors duration-150 ease-out hover:border-brand-300">
              
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <span className={`inline-block rounded-full px-2.5 py-1 text-[11px] font-semibold ${KIND_STYLES[skill.kind]}`}>
                      {SKILL_ADVICE_LABEL[skill.kind]}
                    </span>
                    <h3 className="mt-2 text-[15px] font-bold text-navy">{skill.name}</h3>
                  </div>
                  <ChevronRightIcon size={17} className="mt-1 shrink-0 text-navy-muted" />
                </div>
                <p className="mt-2 text-[12.5px] leading-relaxed text-navy-soft">
                  <span className="font-semibold text-navy">{t('skill.why')} </span>
                  {skill.reason}
                </p>
              </button>
            </li>
          )}
        </ul>
      </section>

      <button
        type="button"
        onClick={() => navigate('/academies')}
        className="mt-5 flex min-h-[48px] w-full items-center justify-center gap-1.5 rounded-xl border border-hairline bg-white text-[13.5px] font-semibold text-navy transition-colors duration-150 ease-out hover:border-brand-300">
        
        Browse all academies and courses
        <ChevronRightIcon size={16} />
      </button>

      <p className="mt-5 flex gap-2 rounded-xl bg-brand-50 p-3.5 text-[11.5px] leading-relaxed text-brand-800">
        <InfoIcon size={15} className="mt-0.5 shrink-0" />
        <span>
          Your skill profile is derived from your own answers by an on-device demo model ({model.features}{' '}
          profile features). It is a self-reported picture, not a test result.
        </span>
      </p>
    </Screen>);

}