import React from 'react';
import { CheckIcon, PartyPopperIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { GuestGate } from '../components/GuestGate';
import { ProgressBar } from '../components/ui/ProgressBar';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { CAREERS } from '../data/careers';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';

export function Roadmap() {
  const navigate = useNavigate();
  const { profile, roadmap, roadmapPercent, toggleRoadmapStep } = useUser();
  const { t } = useT();
  const careerId = profile.selectedCareer ?? profile.recommendations[0]?.careerId ?? null;

  if (profile.isGuest) {
    return (
      <Screen header={<ScreenHeader title="My roadmap" />}>
        <GuestGate
          feature="Your personalised roadmap"
          description="Roadmaps are generated from your assessment and progress is saved to your account." />
        
      </Screen>);

  }

  if (!careerId || roadmap.length === 0) {
    return (
      <Screen header={<ScreenHeader title="My roadmap" />}>
        <EmptyState
          title="No roadmap yet"
          message="Choose a career from your results and we’ll generate a step-by-step plan."
          action={<Button onClick={() => navigate('/results')}>See my results</Button>} />
        
      </Screen>);

  }

  const career = CAREERS[careerId];
  const completed = profile.roadmapProgress[careerId] ?? [];
  const done = roadmapPercent === 100;

  return (
    <Screen
      header={<ScreenHeader title={t('road.title')} subtitle={career.title} />}
      footer={
      <Button fullWidth onClick={() => navigate('/academies')}>
          Find learning providers
        </Button>
      }>
      
      <section className="rounded-2xl bg-navy p-5 text-white">
        <p className="text-[12px] font-semibold uppercase tracking-wide text-brand-300">{t('road.progress')}</p>
        <div className="mt-2 flex items-baseline gap-2">
          <span className="text-[34px] font-bold leading-none">{roadmapPercent}%</span>
          <span className="text-[13px] text-brand-200">
            {completed.length} of {roadmap.length} steps complete
          </span>
        </div>
        <div className="mt-4">
          <ProgressBar value={roadmapPercent} tone="good" label="Roadmap progress" size="sm" />
        </div>
      </section>

      {done &&
      <div className="mt-4 flex items-start gap-3 rounded-2xl border border-good/25 bg-goodSoft p-4">
          <PartyPopperIcon size={18} className="mt-0.5 shrink-0 text-good" />
          <div>
            <p className="text-[13.5px] font-bold text-good">Roadmap completed</p>
            <p className="mt-1 text-[12.5px] leading-relaxed text-good/90">
              You’ve worked through every step for {career.title}. Check your career clarity next.
            </p>
            <Button variant="secondary" className="mt-3 min-h-[42px] bg-white" onClick={() => navigate('/clarity')}>
              Career clarity check
            </Button>
          </div>
        </div>
      }

      <ol className="mt-5 space-y-3">
        {roadmap.map((step, index) => {
          const isComplete = completed.includes(step.id);
          return (
            <li key={step.id} className="relative pl-8">
              {index !== roadmap.length - 1 &&
              <span className="absolute left-[13px] top-8 h-[calc(100%-16px)] w-px bg-hairline" aria-hidden="true" />
              }
              <button
                type="button"
                aria-pressed={isComplete}
                aria-label={`${isComplete ? 'Mark incomplete' : 'Mark complete'}: ${step.title}`}
                onClick={() => toggleRoadmapStep(step.id)}
                className={`absolute left-0 top-3 flex h-7 w-7 items-center justify-center rounded-full border-2 transition-colors duration-150 ease-out ${
                isComplete ? 'border-good bg-good text-white' : 'border-hairline bg-white text-transparent hover:border-brand-400'}`
                }>
                
                <CheckIcon size={15} strokeWidth={3} />
              </button>

              <div
                className={`rounded-2xl border p-4 transition-colors duration-150 ease-out ${
                isComplete ? 'border-good/25 bg-goodSoft/60' : 'border-hairline bg-white'}`
                }>
                
                <div className="flex items-start justify-between gap-3">
                  <h2 className="text-[14.5px] font-bold text-navy">{step.title}</h2>
                  {isComplete &&
                  <span className="shrink-0 rounded-full bg-good px-2 py-0.5 text-[10.5px] font-bold uppercase text-white">
                      Done
                    </span>
                  }
                </div>
                <p className="mt-1.5 text-[13px] leading-relaxed text-navy-muted">{step.goal}</p>

                <div className="mt-3 flex flex-wrap gap-1.5">
                  {step.skills.map((skill) =>
                  <span key={skill} className="rounded-md bg-brand-50 px-2 py-1 text-[11.5px] font-medium text-brand-800">
                      {skill}
                    </span>
                  )}
                </div>

                <p className="mt-3 border-t border-hairline pt-3 text-[12.5px] leading-relaxed text-navy-soft">
                  <span className="font-semibold text-navy">Suggested activity: </span>
                  {step.activity}
                </p>

                <button
                  type="button"
                  onClick={() => toggleRoadmapStep(step.id)}
                  className={`mt-3 min-h-[44px] w-full rounded-xl text-[13.5px] font-semibold transition-colors duration-150 ease-out ${
                  isComplete ?
                  'bg-white text-navy-muted hover:text-navy' :
                  'bg-brand-50 text-brand-700 hover:bg-brand-100'}`
                  }>
                  
                  {isComplete ? t('road.markIncomplete') : t('road.markComplete')}
                </button>
              </div>
            </li>);

        })}
      </ol>
    </Screen>);

}