import React, { useState } from 'react';
import { CompassIcon, HelpCircleIcon, SparklesIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { SelectCard } from '../components/ui/SelectCard';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';
import type { JourneyId } from '../types';

const PATHS: {id: JourneyId;titleKey: string;descKey: string;icon: React.ReactNode;flow: string;}[] = [
{
  id: 'career',
  titleKey: 'path.career',
  descKey: 'path.careerDesc',
  icon: <CompassIcon size={18} />,
  flow: 'Career assessment → matches → clarity check → skill gap → institutions'
},
{
  id: 'skill',
  titleKey: 'path.skill',
  descKey: 'path.skillDesc',
  icon: <SparklesIcon size={18} />,
  flow: 'Skill assessment → strengths & gaps → priority skills → academies'
},
{
  id: 'not_sure',
  titleKey: 'path.unsure',
  descKey: 'path.unsureDesc',
  icon: <HelpCircleIcon size={18} />,
  flow: 'Full assessment → career direction + skill direction → both next steps'
}];


export function PathSelection() {
  const navigate = useNavigate();
  const { profile, update, resetAssessment } = useUser();
  const { t } = useT();
  const [path, setPath] = useState<JourneyId | null>(profile.careerPath as JourneyId ?? null);

  const selectedPath = PATHS.find((p) => p.id === path);

  return (
    <Screen
      header={<ScreenHeader title={t('path.title')} subtitle="3 / 3" onBack={() => navigate('/onboarding/avatar')} />}
      footer={
      <Button
        fullWidth
        disabled={!path}
        onClick={() => {
          if (path && path !== profile.careerPath) resetAssessment();
          update({ careerPath: path });
          navigate('/assessment/intro');
        }}>
        
          {t('common.continue')}
        </Button>
      }>
      
      <p className="mb-5 text-[13.5px] leading-relaxed text-navy-muted">
        Each option runs a different assessment, so pick the one that matches where you are right now. You
        can come back and take another later.
      </p>

      <div className="space-y-3" role="radiogroup" aria-label={t('path.title')}>
        {PATHS.map((option) =>
        <SelectCard
          key={option.id}
          title={t(option.titleKey)}
          description={t(option.descKey)}
          icon={option.icon}
          selected={path === option.id}
          onSelect={() => setPath(option.id)} />

        )}
      </div>

      {selectedPath &&
      <div className="mt-5 rounded-xl border border-brand-200 bg-brand-50 p-4">
          <h2 className="text-[12px] font-semibold uppercase tracking-wide text-brand-700">What happens next</h2>
          <p className="mt-1.5 text-[13px] leading-relaxed text-brand-800">{selectedPath.flow}</p>
          {selectedPath.id === 'not_sure' &&
        <p className="mt-2 text-[12.5px] leading-relaxed text-brand-800/85">
              This is the most chosen option — it covers both sides so you leave with a direction either way.
            </p>
        }
        </div>
      }
    </Screen>);

}