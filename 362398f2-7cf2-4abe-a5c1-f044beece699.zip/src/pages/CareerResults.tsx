import React from 'react';
import { ChevronRightIcon, GitCompareIcon, InfoIcon, SparklesIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { CareerCard } from '../components/CareerCard';
import { RoleDiscoveryCard } from '../components/RoleDiscoveryCard';
import { Button } from '../components/ui/Button';
import { ProgressBar } from '../components/ui/ProgressBar';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { EmptyState } from '../components/ui/EmptyState';
import { modelSummary } from '../ml/service';
import { skillConfidence, strengths, topInterests } from '../utils/profileSummary';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';

export function CareerResults() {
  const navigate = useNavigate();
  const { profile, discovery, journey, skillRecommendations } = useUser();
  const { t } = useT();
  const { features, recommendations } = profile;
  const discovered = [
  { label: 'Best-fit role', role: discovery.bestFit },
  { label: 'Alternative role', role: discovery.alternative },
  { label: 'Adjacent role', role: discovery.adjacent },
  { label: 'Hidden role', role: discovery.hidden },
  { label: 'Emerging role', role: discovery.emerging }].
  filter((entry): entry is {label: string;role: NonNullable<typeof entry.role>;} => Boolean(entry.role));

  if (!features || recommendations.length === 0) {
    return (
      <Screen header={<ScreenHeader title="Career results" onBack={() => navigate('/dashboard')} />}>
        <EmptyState
          title="No results yet"
          message="Complete the assessment and we’ll generate your career interest profile."
          action={<Button onClick={() => navigate('/assessment/intro')}>Start assessment</Button>} />
        
      </Screen>);

  }

  const model = modelSummary();
  const interests = topInterests(features);
  const topStrengths = strengths(features);
  const confidence = skillConfidence(features);

  return (
    <Screen
      header={<ScreenHeader title={t('res.title')} subtitle="Based on your assessment" onBack={() => navigate('/dashboard')} />}
      footer={
      <Button fullWidth onClick={() => navigate(`/careers/${recommendations[0].careerId}`)}>
          Explore top match
        </Button>
      }>
      
      <section className="rounded-2xl bg-navy p-5 text-white">
        <h2 className="text-[12px] font-semibold uppercase tracking-wide text-brand-300">{t('res.profile')}</h2>
        <p className="mt-2 text-[15px] font-semibold leading-snug">
          Your profile leans towards {interests[0]?.label ?? 'exploring broadly'}
          {interests[1] ? ` and ${interests[1].label}` : ''}.
        </p>
        <div className="mt-4 flex flex-wrap gap-1.5">
          {interests.map((interest) =>
          <span key={interest.label} className="rounded-full bg-white/10 px-2.5 py-1 text-[12px] font-medium">
              {interest.label}
            </span>
          )}
        </div>
      </section>

      <section className="mt-5 rounded-2xl border border-hairline bg-white p-4">
        <h2 className="text-[14px] font-bold text-navy">{t('res.strengths')}</h2>
        <ul className="mt-3 space-y-3">
          {topStrengths.map((strength) =>
          <li key={strength.label}>
              <div className="mb-1 flex items-baseline justify-between">
                <span className="text-[13px] font-medium text-navy">{strength.label}</span>
                <span className="text-[12px] font-semibold text-navy-muted">{strength.value}%</span>
              </div>
              <ProgressBar value={strength.value} size="sm" label={strength.label} />
            </li>
          )}
        </ul>
      </section>

      <section className="mt-5 rounded-2xl border border-hairline bg-white p-4">
        <h2 className="text-[14px] font-bold text-navy">{t('res.confidence')}</h2>
        <p className="mt-1 text-[12.5px] text-navy-muted">How you rated yourself across the assessment.</p>
        <ul className="mt-3 grid grid-cols-2 gap-x-4 gap-y-2.5">
          {confidence.map((item) =>
          <li key={item.label} className="text-[12.5px]">
              <span className="block truncate font-medium text-navy">{item.label}</span>
              <span className="text-navy-muted">{item.value}%</span>
            </li>
          )}
        </ul>
      </section>

      {discovered.length > 0 &&
      <section className="mt-7">
          <h2 className="text-[16px] font-bold text-navy">{t('role.explore')}</h2>
          <p className="mt-1 text-[12.5px] leading-relaxed text-navy-muted">
            Ranked from your profile — including roles most people never think to search for.
          </p>
          <div className="mt-3.5 space-y-3.5">
            {discovered.map((entry, index) =>
          <RoleDiscoveryCard
            key={entry.role.roleId}
            role={entry.role}
            label={entry.label}
            emphasis={index === 0} />

          )}
          </div>
        </section>
      }

      {journey === 'not_sure' && skillRecommendations.length > 0 &&
      <section className="mt-7 rounded-2xl border border-hairline bg-white p-4 shadow-card">
          <div className="flex items-start gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
              <SparklesIcon size={19} />
            </span>
            <div className="min-w-0">
              <h2 className="text-[15px] font-bold text-navy">Your skill direction</h2>
              <p className="mt-1 text-[12.5px] leading-relaxed text-navy-muted">
                You took the full assessment, so you also have a skill profile — strengths, gaps and where to
                learn each one.
              </p>
            </div>
          </div>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {skillRecommendations.slice(0, 4).map((skill) =>
          <span key={skill.id} className="rounded-md bg-canvas px-2 py-1 text-[11.5px] font-medium text-navy-soft">
                {skill.name}
              </span>
          )}
          </div>
          <button
          type="button"
          onClick={() => navigate('/skill-results')}
          className="mt-3 flex min-h-[44px] w-full items-center justify-center gap-1.5 rounded-xl bg-brand-50 text-[13.5px] font-semibold text-brand-700 transition-colors duration-150 ease-out hover:bg-brand-100">
          
            Open my skill profile
            <ChevronRightIcon size={16} />
          </button>
        </section>
      }

      <div className="mt-7 flex items-center justify-between gap-3">
        <h2 className="text-[16px] font-bold text-navy">{t('res.recommended')}</h2>
        <button
          type="button"
          onClick={() => navigate('/compare')}
          className="flex min-h-[44px] items-center gap-1.5 text-[13px] font-semibold text-brand-700 hover:underline">
          
          <GitCompareIcon size={15} />
          {t('res.compare')}
        </button>
      </div>

      <div className="mt-3 space-y-3.5">
        {recommendations.map((rec, i) =>
        <CareerCard
          key={rec.careerId}
          careerId={rec.careerId}
          match={rec.match}
          reasons={rec.reasons}
          rank={i + 1} />

        )}
      </div>

      <p className="mt-5 flex gap-2 rounded-xl bg-brand-50 p-3.5 text-[11.5px] leading-relaxed text-brand-800">
        <InfoIcon size={15} className="mt-0.5 shrink-0" />
        <span>
          Ranked by an on-device demo model ({model.features} profile features, {model.classes} career
          categories, trained on {model.samples} synthetic profiles). Match percentages are AI-assisted
          suggestions, not validated predictions.
        </span>
      </p>
    </Screen>);

}