import React, { useMemo, useState } from 'react';
import { Building2Icon, ChevronDownIcon, MapPinIcon, NavigationIcon, StarIcon } from 'lucide-react';
import { BookmarkButton } from '../components/ui/BookmarkButton';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { INSTITUTIONS, INSTITUTION_CITIES, INSTITUTION_TYPES } from '../data/institutions';
import { CAREERS, CAREER_LIST } from '../data/careers';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';
import type { CareerCategoryId } from '../types';

export function Institutions() {
  const { profile, toggleSaved, isSaved } = useUser();
  const { t } = useT();
  const recommended = profile.selectedCareer ?? profile.recommendations[0]?.careerId ?? null;

  const [career, setCareer] = useState<CareerCategoryId | 'all'>(recommended ?? 'all');
  const [city, setCity] = useState('all');
  const [type, setType] = useState('all');
  const [nearbyOnly, setNearbyOnly] = useState(false);
  const [query, setQuery] = useState('');
  const [expanded, setExpanded] = useState<string | null>(null);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return INSTITUTIONS.filter((institution) => {
      const careerOk = career === 'all' || institution.careers.includes(career);
      const cityOk = city === 'all' || institution.city === city;
      const typeOk = type === 'all' || institution.type === type;
      const nearOk = !nearbyOnly || institution.distanceKm <= 10;
      const queryOk =
      !q ||
      institution.name.toLowerCase().includes(q) ||
      institution.programs.some((p) => p.toLowerCase().includes(q)) ||
      institution.skills.some((s) => s.toLowerCase().includes(q));
      return careerOk && cityOk && typeOk && nearOk && queryOk;
    }).sort((a, b) => a.distanceKm - b.distanceKm);
  }, [career, city, type, nearbyOnly, query]);

  const reset = () => {
    setCareer('all');
    setCity('all');
    setType('all');
    setNearbyOnly(false);
    setQuery('');
  };

  return (
    <Screen header={<ScreenHeader showBack={false} title={t('inst.title')} subtitle="Find where you can study this" />}>
      <input
        type="search"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search institutions, programs or skills"
        aria-label="Search institutions"
        className="min-h-[48px] w-full rounded-xl border border-hairline bg-white px-4 text-[14px] text-navy placeholder:text-navy-muted/75 focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-200" />
      

      <div className="mt-3 grid grid-cols-2 gap-2.5">
        <label className="text-[12px] font-semibold text-navy">
          {t('filter.career')}
          <select
            value={career}
            onChange={(e) => setCareer(e.target.value as CareerCategoryId | 'all')}
            className="mt-1 min-h-[44px] w-full rounded-xl border border-hairline bg-white px-3 text-[13px] font-medium text-navy focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-200">
            
            <option value="all">{t('filter.all')}</option>
            {CAREER_LIST.map((c) =>
            <option key={c.id} value={c.id}>
                {c.title}
              </option>
            )}
          </select>
        </label>
        <label className="text-[12px] font-semibold text-navy">
          {t('filter.location')}
          <select
            value={city}
            onChange={(e) => setCity(e.target.value)}
            className="mt-1 min-h-[44px] w-full rounded-xl border border-hairline bg-white px-3 text-[13px] font-medium text-navy focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-200">
            
            <option value="all">{t('filter.all')}</option>
            {INSTITUTION_CITIES.map((c) =>
            <option key={c} value={c}>
                {c}
              </option>
            )}
          </select>
        </label>
      </div>

      <div className="no-scrollbar -mx-5 mt-3 flex gap-2 overflow-x-auto px-5 pb-1">
        <button
          type="button"
          aria-pressed={nearbyOnly}
          onClick={() => setNearbyOnly((v) => !v)}
          className={`flex min-h-[38px] shrink-0 items-center gap-1.5 rounded-full border px-3.5 text-[13px] font-semibold transition-colors duration-150 ease-out ${
          nearbyOnly ?
          'border-brand-600 bg-brand-600 text-white' :
          'border-hairline bg-white text-navy-muted hover:border-brand-300'}`
          }>
          
          <NavigationIcon size={14} />
          {t('inst.nearby')}
        </button>
        {['all', ...INSTITUTION_TYPES].map((option) =>
        <button
          key={option}
          type="button"
          aria-pressed={type === option}
          onClick={() => setType(option)}
          className={`min-h-[38px] shrink-0 rounded-full border px-3.5 text-[13px] font-semibold transition-colors duration-150 ease-out ${
          type === option ?
          'border-brand-600 bg-brand-600 text-white' :
          'border-hairline bg-white text-navy-muted hover:border-brand-300'}`
          }>
          
            {option === 'all' ? t('filter.all') : option}
          </button>
        )}
      </div>

      <p className="mt-4 text-[12px] font-medium text-navy-muted">
        {results.length} · sample data for this prototype
      </p>

      <div className="mt-3 space-y-3.5">
        {results.length === 0 ?
        <EmptyState
          title={t('err.noInstitutions')}
          message="Try exploring all institutions or widening your filters."
          icon={<Building2Icon size={22} />}
          action={
          <Button variant="outline" onClick={reset}>
                {t('common.clearFilters')}
              </Button>
          } /> :


        results.map((institution) => {
          const open = expanded === institution.id;
          return (
            <article key={institution.id} className="rounded-2xl border border-hairline bg-white p-4 shadow-card">
                <div className="flex items-start gap-3">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
                    <Building2Icon size={19} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <h2 className="text-[15px] font-bold leading-snug text-navy">{institution.name}</h2>
                    <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[12.5px] text-navy-muted">
                      <span className="flex items-center gap-1">
                        <MapPinIcon size={13} />
                        {institution.location}
                      </span>
                      <span className="flex items-center gap-1">
                        <NavigationIcon size={12} />
                        {institution.distanceKm} km
                      </span>
                    </p>
                  </div>
                  <BookmarkButton
                  compact
                  saved={isSaved('savedInstitutions', institution.id)}
                  onToggle={() => toggleSaved('savedInstitutions', institution.id)}
                  label={institution.name} />
                
                </div>

                <div className="mt-2.5 flex flex-wrap items-center gap-2">
                  <span className="rounded-md bg-canvas px-2 py-1 text-[11.5px] font-semibold text-navy-soft">
                    {institution.type}
                  </span>
                  <span className="flex items-center gap-1 rounded-md bg-warnSoft px-2 py-1 text-[11.5px] font-semibold text-warn">
                    <StarIcon size={12} fill="currentColor" />
                    {institution.rating} ({institution.reviews})
                  </span>
                </div>

                <div className="mt-3 flex flex-wrap gap-1.5">
                  {institution.programs.slice(0, open ? undefined : 2).map((program) =>
                <span key={program} className="rounded-md bg-canvas px-2 py-1 text-[11.5px] font-medium text-navy-soft">
                      {program}
                    </span>
                )}
                </div>

                <p className="mt-3 text-[12.5px] leading-relaxed text-navy-muted">
                  <span className="font-semibold text-navy">Why it may be relevant: </span>
                  {institution.relevance}
                </p>

                {open &&
              <div className="mt-3 space-y-3 border-t border-hairline pt-3">
                    <div>
                      <h3 className="mb-1.5 text-[12px] font-semibold uppercase tracking-wide text-navy-muted">
                        Skills covered
                      </h3>
                      <div className="flex flex-wrap gap-1.5">
                        {institution.skills.map((skill) =>
                    <span key={skill} className="rounded-md bg-brand-50 px-2 py-1 text-[11.5px] font-medium text-brand-800">
                            {skill}
                          </span>
                    )}
                      </div>
                    </div>
                    <div>
                      <h3 className="mb-1.5 text-[12px] font-semibold uppercase tracking-wide text-navy-muted">
                        Relevant careers
                      </h3>
                      <p className="text-[12.5px] text-navy-soft">
                        {institution.careers.map((id) => CAREERS[id].title).join(' · ')}
                      </p>
                    </div>
                    <p className="text-[11.5px] leading-relaxed text-navy-muted">
                      Mock listing — verify programs, ratings and admissions directly with the institution.
                    </p>
                  </div>
              }

                <button
                type="button"
                aria-expanded={open}
                onClick={() => setExpanded(open ? null : institution.id)}
                className="mt-3 flex min-h-[44px] w-full items-center justify-center gap-1.5 rounded-xl bg-brand-50 text-[13.5px] font-semibold text-brand-700 transition-colors duration-150 ease-out hover:bg-brand-100">
                
                  {open ? t('common.hideDetails') : t('common.viewDetails')}
                  <ChevronDownIcon
                  size={16}
                  className={`transition-transform duration-200 ease-out ${open ? 'rotate-180' : ''}`} />
                
                </button>
              </article>);

        })
        }
      </div>
    </Screen>);

}