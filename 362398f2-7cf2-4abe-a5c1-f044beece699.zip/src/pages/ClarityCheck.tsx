import React, { useState } from 'react';
import { ArrowRightIcon, CompassIcon, HelpCircleIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { GuestGate } from '../components/GuestGate';
import { ProgressBar } from '../components/ui/ProgressBar';
import { RatingScale } from '../components/RatingScale';
import { Screen } from '../components/ui/Screen';
import { ScreenHeader } from '../components/ui/ScreenHeader';
import { CAREERS } from '../data/careers';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';
import type { ClarityAnswers, UserProfile } from '../types';

const ITEMS: {key: keyof ClarityAnswers;labelKey: string;}[] = [
{ key: 'direction', labelKey: 'clarity.q1' },
{ key: 'skills', labelKey: 'clarity.q2' },
{ key: 'path', labelKey: 'clarity.q3' },
{ key: 'confidence', labelKey: 'clarity.q4' }];


const RELEVANCE: {id: NonNullable<UserProfile['careerRelevance']>;labelKey: string;}[] = [
{ id: 'yes', labelKey: 'clarity.yes' },
{ id: 'maybe', labelKey: 'clarity.maybe' },
{ id: 'no', labelKey: 'clarity.no' }];


function message(score: number) {
  if (score >= 80) return 'You now have a clearer direction and a practical next step.';
  if (score >= 60) return 'Your direction is taking shape. Working through your roadmap will sharpen it.';
  if (score >= 40) return 'You have a starting point. Explore two career details and revisit this check.';
  return 'Still foggy — that’s okay. Re-take the assessment or compare a few careers first.';
}

export function ClarityCheck() {
  const navigate = useNavigate();
  const { profile, setClarity, clarityScore, skillGap, roadmapPercent } = useUser();
  const { t } = useT();
  const [answers, setAnswers] = useState<Partial<ClarityAnswers>>(profile.clarityAnswers ?? {});
  const [relevance, setRelevance] = useState<UserProfile['careerRelevance']>(profile.careerRelevance);
  const [submitted, setSubmitted] = useState(Boolean(profile.clarityAnswers));

  if (profile.isGuest) {
    return (
      <Screen header={<ScreenHeader title={t('clarity.title')} />}>
        <GuestGate
          feature="Career clarity check"
          description="This self-check is saved to your profile so you can see how your clarity changes over time." />
        
      </Screen>);

  }

  const complete = ITEMS.every((item) => answers[item.key]) && Boolean(relevance);
  const careerId = profile.selectedCareer ?? profile.recommendations[0]?.careerId ?? null;
  const focusSkills = skillGap.filter((s) => s.level !== 'Strong').slice(0, 2).map((s) => s.name);

  if (submitted && clarityScore !== null) {
    return (
      <Screen
        header={<ScreenHeader title={t('clarity.score')} onBack={() => navigate('/dashboard')} />}
        footer={
        <div className="space-y-2.5">
            <Button fullWidth onClick={() => navigate('/dashboard')}>
              {t('nav.home')}
            </Button>
            <button
            type="button"
            onClick={() => setSubmitted(false)}
            className="min-h-[44px] w-full text-[13px] font-semibold text-navy-muted hover:text-brand-700">
            
              Retake the check
            </button>
          </div>
        }>
        
        <section className="rounded-2xl bg-navy p-6 text-center text-white">
          <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-white/10">
            <CompassIcon size={24} />
          </span>
          <p className="mt-4 text-[12px] font-semibold uppercase tracking-wide text-brand-300">
            {t('clarity.score')}
          </p>
          <p className="mt-1 text-[46px] font-bold leading-none">{clarityScore}%</p>
          <p className="mx-auto mt-3 max-w-[250px] text-[13.5px] leading-relaxed text-brand-100">
            {message(clarityScore)}
          </p>
        </section>

        <section className="mt-5 grid grid-cols-2 gap-3">
          <div className="rounded-2xl border border-hairline bg-white p-4">
            <h2 className="text-[11.5px] font-semibold uppercase tracking-wide text-navy-muted">
              {t('clarity.before')}
            </h2>
            <ul className="mt-2.5 space-y-1.5 text-[12.5px] text-navy-muted">
              <li>Confused</li>
              <li>Exploring</li>
              <li>Unsure of next step</li>
            </ul>
          </div>
          <div className="rounded-2xl border border-brand-200 bg-brand-50 p-4">
            <h2 className="text-[11.5px] font-semibold uppercase tracking-wide text-brand-700">
              {t('clarity.after')}
            </h2>
            <ul className="mt-2.5 space-y-1.5 text-[12.5px] font-medium text-brand-800">
              <li>{careerId ? CAREERS[careerId].title : 'Career direction'}</li>
              <li>{focusSkills.length ? focusSkills.join(', ') : 'Skill priorities'}</li>
              <li>Roadmap {roadmapPercent}% complete</li>
            </ul>
          </div>
        </section>

        <ul className="mt-5 space-y-3">
          {ITEMS.map((item) =>
          <li key={item.key} className="rounded-xl border border-hairline bg-white p-3.5">
              <p className="text-[13px] font-medium text-navy">{t(item.labelKey)}</p>
              <div className="mt-2 flex items-center gap-3">
                <ProgressBar
                value={(profile.clarityAnswers?.[item.key] ?? 0) / 5 * 100}
                size="sm"
                label={t(item.labelKey)} />
              
                <span className="w-8 shrink-0 text-right text-[12px] font-semibold text-navy-muted">
                  {profile.clarityAnswers?.[item.key]}/5
                </span>
              </div>
            </li>
          )}
          <li className="flex items-center justify-between gap-3 rounded-xl border border-hairline bg-white p-3.5">
            <p className="text-[13px] font-medium text-navy">{t('clarity.relevance')}</p>
            <span className="shrink-0 rounded-full bg-brand-50 px-2.5 py-1 text-[12px] font-semibold text-brand-700">
              {t(`clarity.${profile.careerRelevance ?? 'maybe'}`)}
            </span>
          </li>
        </ul>

        <Button
          variant="outline"
          fullWidth
          className="mt-5"
          onClick={() => navigate('/roadmap')}
          iconRight={<ArrowRightIcon size={16} />}>
          
          {t('dash.continueRoadmap')}
        </Button>

        <p className="mt-5 text-[11.5px] leading-relaxed text-navy-muted">
          This is a self-reported clarity indicator based on your own answers — not a validated assessment
          score.
        </p>
      </Screen>);

  }

  return (
    <Screen
      header={<ScreenHeader title={t('clarity.title')} subtitle="Five quick questions" />}
      footer={
      <Button
        fullWidth
        disabled={!complete}
        onClick={() => {
          setClarity(answers as ClarityAnswers, relevance);
          setSubmitted(true);
        }}>
        
          {t('clarity.score')}
        </Button>
      }>
      
      <p className="text-[13.5px] leading-relaxed text-navy-muted">
        Rate how you feel right now, from 1 (still confused) to 5 (very clear).
      </p>
      <div className="mt-4 space-y-3">
        {ITEMS.map((item) =>
        <RatingScale
          key={item.key}
          label={t(item.labelKey)}
          value={answers[item.key]}
          onChange={(value) => setAnswers((prev) => ({ ...prev, [item.key]: value }))} />

        )}

        <fieldset className="rounded-xl border border-hairline bg-white p-3.5">
          <legend className="sr-only">{t('clarity.relevance')}</legend>
          <p className="mb-2.5 flex items-start gap-2 text-[14px] font-semibold text-navy">
            <HelpCircleIcon size={16} className="mt-0.5 shrink-0 text-brand-600" />
            {t('clarity.relevance')}
          </p>
          <div className="flex gap-2" role="radiogroup" aria-label={t('clarity.relevance')}>
            {RELEVANCE.map((option) => {
              const selected = relevance === option.id;
              return (
                <button
                  key={option.id}
                  type="button"
                  role="radio"
                  aria-checked={selected}
                  onClick={() => setRelevance(option.id)}
                  className={`min-h-[44px] flex-1 rounded-lg border text-[13.5px] font-semibold transition-colors duration-150 ease-out ${
                  selected ?
                  'border-brand-600 bg-brand-600 text-white' :
                  'border-hairline bg-white text-navy-muted hover:border-brand-300 hover:text-navy'}`
                  }>
                  
                  {t(option.labelKey)}
                </button>);

            })}
          </div>
        </fieldset>
      </div>
    </Screen>);

}