import React from 'react';
import {
  ArrowRightIcon,
  BookmarkIcon,
  Building2Icon,
  CompassIcon,
  GraduationCapIcon,
  LayersIcon,
  TargetIcon } from
'lucide-react';
import { useNavigate } from 'react-router-dom';
import { AvatarFigure } from '../components/AvatarFigure';
import { Button } from '../components/ui/Button';
import { LevelTag } from '../components/ui/LevelTag';
import { ProgressBar } from '../components/ui/ProgressBar';
import { Screen } from '../components/ui/Screen';
import { CAREERS } from '../data/careers';
import { ACADEMIES } from '../data/academies';
import { INSTITUTIONS } from '../data/institutions';
import { useUser } from '../contexts/UserContext';
import { useT } from '../i18n';

export function Dashboard() {
  const navigate = useNavigate();
  const { profile, skillGap, roadmapPercent, clarityScore, journey, skillRecommendations } = useUser();
  const { t } = useT();
  const isSkillJourney = journey === 'skill';

  const SHORTCUTS = [
  { to: '/careers', key: 'nav.careers', Icon: CompassIcon },
  { to: isSkillJourney ? '/skill-results' : '/skill-gap', key: 'gap.title', Icon: TargetIcon },
  { to: '/institutions', key: 'inst.title', Icon: Building2Icon },
  { to: '/academies', key: 'acad.title', Icon: GraduationCapIcon },
  { to: '/saved', key: 'nav.saved', Icon: BookmarkIcon },
  { to: '/compare', key: 'res.compare', Icon: LayersIcon }];


  const topCareerId = profile.selectedCareer ?? profile.recommendations[0]?.careerId ?? null;
  const topMatch = profile.recommendations.find((r) => r.careerId === topCareerId);
  const firstName = (profile.name || 'there').split(' ')[0];

  const relevantInstitutions = topCareerId ?
  INSTITUTIONS.filter((i) => i.careers.includes(topCareerId)).slice(0, 2) :
  [];
  const relevantAcademies = topCareerId ?
  ACADEMIES.filter((a) => a.careers.includes(topCareerId)).slice(0, 2) :
  [];

  return (
    <Screen>
      <header className="flex items-center gap-3 pt-[max(0px,env(safe-area-inset-top))] sm:pt-5">
        <AvatarFigure avatarId={profile.avatar} size={48} />
        <div className="min-w-0 flex-1">
          <p className="text-[12.5px] text-navy-muted">{t('dash.welcome')}</p>
          <h1 className="truncate text-[19px] font-bold text-navy">{firstName}</h1>
        </div>
        {profile.isGuest &&
        <span className="rounded-full bg-warnSoft px-2.5 py-1 text-[11.5px] font-semibold text-warn">Guest</span>
        }
      </header>

      {!profile.assessmentComplete ?
      <section className="mt-5 rounded-2xl bg-navy p-5 text-white">
          <h2 className="text-[19px] font-bold leading-snug">{t('dash.journey')}</h2>
          <p className="mt-2 text-[13px] leading-relaxed text-brand-200">
            Take the assessment and we’ll map your interests and strengths to careers, skills and a
            step-by-step roadmap.
          </p>
          <Button
          className="mt-4 bg-white text-brand-700 hover:bg-brand-50"
          fullWidth
          onClick={() => navigate(profile.isGuest ? '/create-account' : '/assessment/intro')}
          iconRight={<ArrowRightIcon size={17} />}>
          
            {profile.isGuest ? t('auth.createAccount') : t('dash.completeAssessment')}
          </Button>
        </section> :
      isSkillJourney && skillRecommendations.length > 0 ?
      <section className="mt-5 rounded-2xl bg-navy p-5 text-white">
          <p className="text-[12px] font-semibold uppercase tracking-wide text-brand-300">Your priority skill</p>
          <h2 className="mt-1.5 text-[21px] font-bold leading-tight">{skillRecommendations[0].name}</h2>
          <p className="mt-1.5 text-[13px] leading-relaxed text-brand-200">{skillRecommendations[0].reason}</p>
          <Button
          className="mt-4 bg-white text-brand-700 hover:bg-brand-50"
          fullWidth
          onClick={() => navigate(`/skills/${encodeURIComponent(skillRecommendations[0].name)}`)}
          iconRight={<ArrowRightIcon size={17} />}>
          
            Open the skill toolkit
          </Button>
        </section> :

      topCareerId &&
      <section className="mt-5 rounded-2xl bg-navy p-5 text-white">
            <p className="text-[12px] font-semibold uppercase tracking-wide text-brand-300">{t('dash.topMatch')}</p>
            <h2 className="mt-1.5 text-[21px] font-bold leading-tight">{CAREERS[topCareerId].title}</h2>
            <p className="mt-1.5 text-[13px] leading-relaxed text-brand-200">{CAREERS[topCareerId].tagline}</p>
            <div className="mt-4 flex items-center gap-3">
              <span className="text-[26px] font-bold leading-none">{topMatch?.match ?? 0}%</span>
              <span className="flex-1">
                <ProgressBar value={topMatch?.match ?? 0} size="sm" label="Career match" />
              </span>
            </div>
            <Button
          className="mt-4 bg-white text-brand-700 hover:bg-brand-50"
          fullWidth
          onClick={() => navigate('/roadmap')}
          iconRight={<ArrowRightIcon size={17} />}>
          
              {t('dash.continueRoadmap')}
            </Button>
          </section>

      }

      <nav aria-label="Quick links" className="mt-5 grid grid-cols-3 gap-2.5">
        {SHORTCUTS.map(({ to, key, Icon }) =>
        <button
          key={to}
          type="button"
          onClick={() => navigate(to)}
          className="flex min-h-[76px] flex-col items-center justify-center gap-1.5 rounded-xl border border-hairline bg-white px-1 text-center text-[12px] font-semibold leading-tight text-navy transition-colors duration-150 ease-out hover:border-brand-300">
          
            <Icon size={19} className="text-brand-600" aria-hidden="true" />
            {t(key)}
          </button>
        )}
      </nav>

      {profile.assessmentComplete &&
      <>
          <div className="mt-5 grid grid-cols-2 gap-3">
            <article className="rounded-2xl border border-hairline bg-white p-4">
              <h2 className="text-[12.5px] font-semibold text-navy-muted">{t('road.progress')}</h2>
              <p className="mt-1.5 text-[24px] font-bold text-navy">{roadmapPercent}%</p>
              <div className="mt-2">
                <ProgressBar value={roadmapPercent} tone="good" size="sm" label="Roadmap" />
              </div>
            </article>
            <article className="rounded-2xl border border-hairline bg-white p-4">
              <h2 className="text-[12.5px] font-semibold text-navy-muted">{t('clarity.score')}</h2>
              <p className="mt-1.5 text-[24px] font-bold text-navy">
                {clarityScore !== null ? `${clarityScore}%` : '—'}
              </p>
              <button
              type="button"
              onClick={() => navigate('/clarity')}
              className="mt-1.5 text-[12px] font-semibold text-brand-700 hover:underline">
              
                {clarityScore !== null ? 'Retake check' : 'Take the check'}
              </button>
            </article>
          </div>

          <section className="mt-5 rounded-2xl border border-hairline bg-white p-4">
            <div className="flex items-center justify-between gap-3">
              <h2 className="text-[14px] font-bold text-navy">{t('gap.title')}</h2>
              <button
              type="button"
              onClick={() => navigate('/skill-gap')}
              className="text-[12.5px] font-semibold text-brand-700 hover:underline">
              
                {t('common.viewAll')}
              </button>
            </div>
            <ul className="mt-3 space-y-2.5">
              {skillGap.slice(0, 3).map((skill) =>
            <li key={skill.name} className="flex items-center justify-between gap-3">
                  <span className="truncate text-[13px] font-medium text-navy">{skill.name}</span>
                  <LevelTag level={skill.level} />
                </li>
            )}
            </ul>
          </section>

          <section className="mt-5">
            <div className="flex items-center justify-between gap-3">
              <h2 className="text-[15px] font-bold text-navy">{t('dash.institutions')}</h2>
              <button
              type="button"
              onClick={() => navigate('/institutions')}
              className="text-[12.5px] font-semibold text-brand-700 hover:underline">
              
                {t('common.seeAll')}
              </button>
            </div>
            <ul className="mt-3 space-y-2.5">
              {relevantInstitutions.map((institution) =>
            <li key={institution.id}>
                  <button
                type="button"
                onClick={() => navigate('/institutions')}
                className="flex min-h-[60px] w-full items-center gap-3 rounded-xl border border-hairline bg-white px-4 text-left transition-colors duration-150 ease-out hover:border-brand-300">
                
                    <Building2Icon size={18} className="shrink-0 text-brand-600" />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[13.5px] font-semibold text-navy">{institution.name}</span>
                      <span className="block truncate text-[12px] text-navy-muted">{institution.location}</span>
                    </span>
                    <ArrowRightIcon size={16} className="shrink-0 text-navy-muted" />
                  </button>
                </li>
            )}
            </ul>
          </section>

          <section className="mt-5">
            <div className="flex items-center justify-between gap-3">
              <h2 className="text-[15px] font-bold text-navy">{t('dash.academies')}</h2>
              <button
              type="button"
              onClick={() => navigate('/academies')}
              className="text-[12.5px] font-semibold text-brand-700 hover:underline">
              
                {t('common.seeAll')}
              </button>
            </div>
            <ul className="mt-3 space-y-2.5">
              {relevantAcademies.map((academy) =>
            <li key={academy.id}>
                  <button
                type="button"
                onClick={() => navigate('/academies')}
                className="flex min-h-[60px] w-full items-center gap-3 rounded-xl border border-hairline bg-white px-4 text-left transition-colors duration-150 ease-out hover:border-brand-300">
                
                    <GraduationCapIcon size={18} className="shrink-0 text-brand-600" />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[13.5px] font-semibold text-navy">{academy.course}</span>
                      <span className="block truncate text-[12px] text-navy-muted">
                        {academy.name} · {academy.mode} · {academy.duration}
                      </span>
                    </span>
                    <ArrowRightIcon size={16} className="shrink-0 text-navy-muted" />
                  </button>
                </li>
            )}
            </ul>
          </section>

          <button
          type="button"
          onClick={() => navigate(isSkillJourney ? '/skill-results' : '/results')}
          className="mt-5 min-h-[48px] w-full rounded-xl border border-hairline bg-white text-[13.5px] font-semibold text-navy transition-colors duration-150 ease-out hover:border-brand-300">
          
            Assessment complete · view full results
          </button>
        </>
      }
    </Screen>);

}