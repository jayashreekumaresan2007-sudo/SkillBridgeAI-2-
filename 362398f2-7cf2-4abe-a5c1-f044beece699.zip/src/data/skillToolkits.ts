export interface SkillToolkit {
  tools: string[];
  keywords: string[];
  practice: string[];
  resources: string[];
}

/**
 * Per-skill toolkit content. Deliberately specific — the point of the toolkit
 * is that it changes completely between skills rather than showing the same
 * generic "watch a tutorial" advice everywhere.
 */
export const SKILL_TOOLKITS: Record<string, SkillToolkit> = {
  Python: {
    tools: ['VS Code', 'Jupyter Notebook', 'Google Colab'],
    keywords: ['Variables & types', 'Functions', 'List comprehension', 'Virtual environments'],
    practice: ['Write a script that cleans a messy CSV', 'Rebuild a spreadsheet calculation in pandas'],
    resources: ['Official Python tutorial', 'Automate the Boring Stuff (free online)']
  },
  Programming: {
    tools: ['VS Code', 'Git & GitHub', 'A browser dev console'],
    keywords: ['Data structures', 'Version control', 'Debugging', 'Code review'],
    practice: ['Ship one small app end to end', 'Read and fix an open-source beginner issue'],
    resources: ['MDN Web Docs', 'The Odin Project']
  },
  'Machine Learning': {
    tools: ['scikit-learn', 'Google Colab', 'Kaggle'],
    keywords: ['Train/test split', 'Overfitting', 'Feature engineering', 'Evaluation metrics'],
    practice: ['Train a classifier on a public dataset and explain its errors', 'Write up why a model failed'],
    resources: ['Google Machine Learning Crash Course', 'Kaggle Learn micro-courses']
  },
  Statistics: {
    tools: ['Excel / Google Sheets', 'Python (pandas)', 'R'],
    keywords: ['Distribution', 'Correlation vs causation', 'Confidence interval', 'Sampling bias'],
    practice: ['Summarise a dataset in five honest sentences', 'Find a misleading chart and correct it'],
    resources: ['Khan Academy Statistics', 'Seeing Theory (Brown University)']
  },
  SQL: {
    tools: ['PostgreSQL', 'DB Fiddle', 'Metabase'],
    keywords: ['JOIN', 'GROUP BY', 'Window functions', 'Indexes'],
    practice: ['Answer five business questions from one schema', 'Rewrite a slow query and measure it'],
    resources: ['SQLBolt', 'Mode SQL Tutorial']
  },
  Analytics: {
    tools: ['Google Sheets', 'Looker Studio', 'GA4'],
    keywords: ['Metric definition', 'Segmentation', 'Cohort', 'Attribution'],
    practice: ['Define three metrics for a product you use daily', 'Build a one-screen dashboard'],
    resources: ['Google Analytics Academy', 'Storytelling with Data blog']
  },
  'Data Visualisation': {
    tools: ['Looker Studio', 'Tableau Public', 'matplotlib'],
    keywords: ['Chart choice', 'Axis honesty', 'Annotation', 'Colour accessibility'],
    practice: ['Redesign a chart from a news article', 'Explain one dataset in a single visual'],
    resources: ['Financial Times Visual Vocabulary', 'Storytelling with Data']
  },
  'Analytical Thinking': {
    tools: ['Spreadsheets', 'Miro / FigJam', 'Notebook and pen'],
    keywords: ['Hypothesis', 'Root cause', 'Assumption', 'Trade-off'],
    practice: ['Write a one-page decision memo with three options', 'Do a five-whys on a real failure'],
    resources: ['Thinking in Systems (Meadows)', 'Farnam Street mental models']
  },
  'Systems Thinking': {
    tools: ['Miro / FigJam', 'Draw.io', 'Notion'],
    keywords: ['Feedback loop', 'Bottleneck', 'Dependency', 'Failure mode'],
    practice: ['Diagram how one product feature actually flows', 'Map where a process breaks under load'],
    resources: ['Thinking in Systems (Meadows)', 'The Phoenix Project']
  },
  'Spreadsheets & Tools': {
    tools: ['Google Sheets', 'Excel', 'Airtable'],
    keywords: ['Pivot table', 'Lookup functions', 'Data validation', 'Named ranges'],
    practice: ['Rebuild a manual report as a pivot table', 'Automate one repeated calculation'],
    resources: ['Google Sheets training', 'ExcelJet reference']
  },
  Figma: {
    tools: ['Figma', 'FigJam', 'Figma Community files'],
    keywords: ['Auto layout', 'Components', 'Variants', 'Design tokens'],
    practice: ['Rebuild an app screen you use daily', 'Design an onboarding flow with three states'],
    resources: ['Figma Learn', 'Refactoring UI']
  },
  'Visual & Interaction Design': {
    tools: ['Figma', 'Google Fonts', 'Contrast checkers'],
    keywords: ['Hierarchy', 'Spacing scale', 'Contrast', 'States'],
    practice: ['Take one screen and improve only its hierarchy', 'Design empty, loading and error states'],
    resources: ['Refactoring UI', 'Laws of UX']
  },
  'User Research': {
    tools: ['Notion', 'Google Forms', 'Maze'],
    keywords: ['Open question', 'Usability test', 'Affinity mapping', 'Research plan'],
    practice: ['Interview three real users for 15 minutes each', 'Run a five-task usability test'],
    resources: ['Nielsen Norman Group articles', 'Just Enough Research (Hall)']
  },
  'Research Methods': {
    tools: ['Google Scholar', 'Zotero', 'Notion'],
    keywords: ['Literature review', 'Sampling', 'Validity', 'Citation'],
    practice: ['Write a two-page literature summary', 'Critique one paper’s method section'],
    resources: ['Google Scholar', 'Purdue OWL research guides']
  },
  'Empathy for Users': {
    tools: ['Interview notes', 'FigJam', 'Journey map template'],
    keywords: ['Pain point', 'Journey map', 'Jobs to be done', 'Accessibility'],
    practice: ['Map one user’s journey end to end', 'Watch someone use your work in silence'],
    resources: ['Nielsen Norman Group', 'Inclusive Design Principles']
  },
  Communication: {
    tools: ['Slides', 'Loom', 'Notion'],
    keywords: ['Audience', 'Structure', 'Signposting', 'Call to action'],
    practice: ['Explain your last project in 90 seconds', 'Rewrite a long update into five lines'],
    resources: ['Talk Like TED', 'Hemingway Editor']
  },
  'Written Communication': {
    tools: ['Google Docs', 'Hemingway Editor', 'Grammarly'],
    keywords: ['Summary first', 'Active voice', 'Plain language', 'Editing pass'],
    practice: ['Write a 300-word summary of something technical', 'Cut one of your documents by 30%'],
    resources: ['On Writing Well (Zinsser)', 'Purdue OWL']
  },
  Leadership: {
    tools: ['1:1 notes', 'Shared roadmap', 'Retrospective template'],
    keywords: ['Delegation', 'Feedback', 'Prioritisation', 'Accountability'],
    practice: ['Run a retrospective for a group project', 'Give one piece of specific feedback this week'],
    resources: ['Radical Candor', 'The Making of a Manager']
  },
  'Business Thinking': {
    tools: ['Spreadsheets', 'Business model canvas', 'Notion'],
    keywords: ['Unit economics', 'Value proposition', 'Prioritisation', 'Trade-off'],
    practice: ['Model the cost and revenue of one product idea', 'Write a one-page business case'],
    resources: ['Strategyzer Business Model Canvas', 'Lenny’s Newsletter (free posts)']
  },
  'Problem Solving': {
    tools: ['Whiteboard', 'Issue tracker', 'Pen and paper'],
    keywords: ['Decomposition', 'Constraint', 'Edge case', 'Iteration'],
    practice: ['Solve three structured problems a week and write up your approach', 'Debug someone else’s code'],
    resources: ['LeetCode / Exercism', 'How to Solve It (Pólya)']
  },
  Databases: {
    tools: ['PostgreSQL', 'DBeaver', 'Prisma'],
    keywords: ['Normalisation', 'Primary key', 'Migration', 'Transaction'],
    practice: ['Design a schema for an app you use', 'Write the queries a real screen would need'],
    resources: ['PostgreSQL tutorial', 'Use The Index, Luke']
  },
  Scripting: {
    tools: ['Bash', 'Python', 'cron'],
    keywords: ['Automation', 'Arguments', 'Logging', 'Error handling'],
    practice: ['Automate one task you repeat weekly', 'Add logging and failure handling to it'],
    resources: ['Bash scripting guide', 'Automate the Boring Stuff']
  },
  'Linux & Scripting': {
    tools: ['A Linux VM', 'Docker', 'tmux'],
    keywords: ['File permissions', 'Processes', 'SSH', 'Containers'],
    practice: ['Deploy a small app on a Linux server yourself', 'Containerise one project'],
    resources: ['Linux Journey', 'Docker getting started guide']
  },
  'Networking & Systems': {
    tools: ['Wireshark', 'nmap', 'A home lab VM'],
    keywords: ['TCP/IP', 'DNS', 'Firewall rules', 'Least privilege'],
    practice: ['Map the traffic of one app you use', 'Harden a test machine and document why'],
    resources: ['Cisco Networking Basics', 'TryHackMe free rooms']
  },
  'Technical Confidence': {
    tools: ['Documentation', 'GitHub', 'A scratch project folder'],
    keywords: ['Reading docs', 'Reproducing errors', 'Asking precisely', 'Small commits'],
    practice: ['Learn one unfamiliar tool and ship something tiny with it', 'Write down every error you solve'],
    resources: ['The Pragmatic Programmer', 'Official docs of your main tool']
  },
  Creativity: {
    tools: ['Sketchbook', 'FigJam', 'Reference boards'],
    keywords: ['Divergence', 'Constraint', 'Remix', 'Critique'],
    practice: ['Produce ten options before choosing one', 'Redesign something you use with one constraint'],
    resources: ['Steal Like an Artist', 'IDEO Design Kit']
  }
};

export const DEFAULT_TOOLKIT: SkillToolkit = {
  tools: ['Notion or a notebook', 'A public example to study', 'A small practice project'],
  keywords: ['Fundamentals', 'Deliberate practice', 'Feedback loop', 'Portfolio evidence'],
  practice: ['Set one small weekly output and show it to someone', 'Keep a log of what you learned'],
  resources: ['Look for a structured beginner course from a verified provider']
};

export function toolkitFor(skill: string): SkillToolkit {
  return SKILL_TOOLKITS[skill] ?? DEFAULT_TOOLKIT;
}