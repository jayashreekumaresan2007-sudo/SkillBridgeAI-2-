import type { Role } from '../types';

/**
 * ROLE TAXONOMY
 *
 * The ML model ranks broad career categories. This taxonomy turns those
 * categories into concrete roles and marks each one as core (well known),
 * adjacent (a sideways step), hidden (rarely considered) or emerging (newer
 * role shaped by AI and data work). Discovery re-ranks roles inside the
 * predicted categories using their own feature affinity, so recommendations
 * are driven by the assessment rather than a fixed list.
 */
export const ROLES: Role[] = [
// AI / Machine Learning
{
  id: 'ml_engineer',
  title: 'AI / ML Engineer',
  careerId: 'ai_ml',
  kind: 'core',
  summary: 'Builds and ships models that make predictions inside real products.',
  affinity: { interest_technology: 1, analytical_score: 0.9, coding_preference: 0.9, technical_confidence: 0.7 },
  skills: ['Python', 'Machine Learning', 'Statistics', 'Problem Solving']
},
{
  id: 'ml_ops',
  title: 'ML Operations Engineer',
  careerId: 'ai_ml',
  kind: 'adjacent',
  summary: 'Keeps models running reliably in production once they leave the notebook.',
  affinity: { technical_confidence: 1, coding_preference: 0.8, problem_solving_score: 0.7 },
  skills: ['Python', 'Linux & Scripting', 'Systems Thinking']
},
{
  id: 'responsible_ai',
  title: 'Responsible AI Specialist',
  careerId: 'ai_ml',
  kind: 'emerging',
  summary: 'Checks AI systems for bias, safety and fairness before they reach users.',
  affinity: { analytical_score: 0.8, research_preference: 0.9, communication_score: 0.7, people_orientation: 0.6 },
  skills: ['Research Methods', 'Analytical Thinking', 'Written Communication', 'Machine Learning']
},

// Software
{
  id: 'software_engineer',
  title: 'Software Developer',
  careerId: 'software',
  kind: 'core',
  summary: 'Designs and builds the applications people use every day.',
  affinity: { coding_preference: 1, technical_confidence: 0.8, problem_solving_score: 0.8, interest_technology: 0.7 },
  skills: ['Programming', 'Databases', 'Problem Solving']
},
{
  id: 'qa_automation',
  title: 'Quality & Automation Engineer',
  careerId: 'software',
  kind: 'hidden',
  summary: 'Finds failures before users do, and automates the checks that catch them.',
  affinity: { analytical_score: 0.9, problem_solving_score: 0.8, coding_preference: 0.6 },
  skills: ['Scripting', 'Analytical Thinking', 'Problem Solving']
},
{
  id: 'ai_workflow',
  title: 'AI Workflow Specialist',
  careerId: 'software',
  kind: 'emerging',
  summary: 'Redesigns how teams work by wiring AI tools into everyday processes.',
  affinity: { problem_solving_score: 0.9, business_orientation: 0.7, technical_confidence: 0.6, communication_score: 0.6 },
  skills: ['Systems Thinking', 'Business Thinking', 'Programming']
},

// Data
{
  id: 'data_analyst',
  title: 'Data Analyst',
  careerId: 'data',
  kind: 'core',
  summary: 'Turns messy data into decisions people can actually act on.',
  affinity: { analytical_score: 1, interest_data: 0.9, communication_score: 0.5 },
  skills: ['SQL', 'Data Visualisation', 'Statistics']
},
{
  id: 'data_storyteller',
  title: 'Data Storytelling Specialist',
  careerId: 'data',
  kind: 'hidden',
  summary: 'Makes analysis land with non-technical audiences through narrative and visuals.',
  affinity: { communication_score: 1, analytical_score: 0.7, creativity_score: 0.7, interest_data: 0.6 },
  skills: ['Data Visualisation', 'Written Communication', 'Communication']
},
{
  id: 'climate_data',
  title: 'Climate Data Analyst',
  careerId: 'data',
  kind: 'emerging',
  summary: 'Applies analysis to emissions, energy and sustainability reporting.',
  affinity: { analytical_score: 0.9, interest_science: 0.8, research_preference: 0.7, people_orientation: 0.5 },
  skills: ['SQL', 'Statistics', 'Research Methods']
},

// Cybersecurity
{
  id: 'security_analyst',
  title: 'Cybersecurity Analyst',
  careerId: 'cybersecurity',
  kind: 'core',
  summary: 'Monitors systems, investigates incidents and closes the gaps attackers use.',
  affinity: { technical_confidence: 0.9, analytical_score: 0.9, problem_solving_score: 0.8 },
  skills: ['Networking & Systems', 'Scripting', 'Analytical Thinking']
},
{
  id: 'security_awareness',
  title: 'Security Awareness Lead',
  careerId: 'cybersecurity',
  kind: 'hidden',
  summary: 'Trains people — the part of security that technology cannot patch.',
  affinity: { communication_score: 1, people_orientation: 0.8, technical_confidence: 0.5 },
  skills: ['Communication', 'Networking & Systems', 'Written Communication']
},
{
  id: 'ai_governance',
  title: 'AI Governance Specialist',
  careerId: 'cybersecurity',
  kind: 'emerging',
  summary: 'Sets the rules for how AI and data may be used inside an organisation.',
  affinity: { analytical_score: 0.8, business_orientation: 0.7, research_preference: 0.7, communication_score: 0.6 },
  skills: ['Research Methods', 'Business Thinking', 'Written Communication']
},

// UI/UX
{
  id: 'ux_designer',
  title: 'UI/UX Designer',
  careerId: 'uiux',
  kind: 'core',
  summary: 'Shapes how a product looks, flows and feels to the person using it.',
  affinity: { design_preference: 1, creativity_score: 0.9, interest_design: 0.8 },
  skills: ['Figma', 'Visual & Interaction Design', 'User Research']
},
{
  id: 'ux_researcher',
  title: 'UX Researcher',
  careerId: 'uiux',
  kind: 'adjacent',
  summary: 'Studies real users so design decisions rest on evidence, not opinion.',
  affinity: { research_preference: 1, people_orientation: 0.8, communication_score: 0.7, interest_design: 0.5 },
  skills: ['User Research', 'Research Methods', 'Empathy for Users']
},
{
  id: 'human_ai_designer',
  title: 'Human-AI Interaction Designer',
  careerId: 'uiux',
  kind: 'emerging',
  summary: 'Designs how people understand, trust and correct AI-driven features.',
  affinity: { design_preference: 0.9, interest_technology: 0.8, creativity_score: 0.7, research_preference: 0.6 },
  skills: ['Figma', 'User Research', 'Visual & Interaction Design', 'Machine Learning']
},

// Business
{
  id: 'business_analyst',
  title: 'Business Analyst',
  careerId: 'business',
  kind: 'core',
  summary: 'Sits between the business and the build team, turning needs into requirements.',
  affinity: { business_orientation: 1, analytical_score: 0.8, communication_score: 0.8 },
  skills: ['Business Thinking', 'Analytics', 'Communication']
},
{
  id: 'operations_lead',
  title: 'Operations Lead',
  careerId: 'business',
  kind: 'adjacent',
  summary: 'Makes the day-to-day machinery of a team run predictably.',
  affinity: { leadership_score: 0.9, business_orientation: 0.8, teamwork_score: 0.7 },
  skills: ['Leadership', 'Business Thinking', 'Systems Thinking']
},
{
  id: 'learning_analytics',
  title: 'Learning Analytics Specialist',
  careerId: 'business',
  kind: 'emerging',
  summary: 'Uses data to work out what actually helps people learn inside an organisation.',
  affinity: { analytical_score: 0.8, people_orientation: 0.8, interest_data: 0.6, communication_score: 0.6 },
  skills: ['Analytics', 'SQL', 'Communication']
},

// Marketing
{
  id: 'digital_marketer',
  title: 'Digital Marketing Specialist',
  careerId: 'marketing',
  kind: 'core',
  summary: 'Finds an audience and earns their attention across digital channels.',
  affinity: { interest_communication: 1, communication_score: 0.9, creativity_score: 0.7 },
  skills: ['Communication', 'Analytics', 'Creativity']
},
{
  id: 'content_strategist',
  title: 'Content Strategist',
  careerId: 'marketing',
  kind: 'adjacent',
  summary: 'Decides what a brand says, to whom, and in what order.',
  affinity: { communication_score: 1, creativity_score: 0.8, research_preference: 0.6 },
  skills: ['Written Communication', 'Communication', 'Analytics']
},
{
  id: 'marketing_ops',
  title: 'Marketing Data Specialist',
  careerId: 'marketing',
  kind: 'hidden',
  summary: 'Runs the measurement and automation behind marketing decisions.',
  affinity: { analytical_score: 0.9, interest_data: 0.8, business_orientation: 0.6 },
  skills: ['Analytics', 'SQL', 'Spreadsheets & Tools']
},

// Research
{
  id: 'research_analyst',
  title: 'Research Analyst',
  careerId: 'research',
  kind: 'core',
  summary: 'Designs studies and produces evidence others make decisions on.',
  affinity: { research_preference: 1, interest_science: 0.9, analytical_score: 0.8 },
  skills: ['Research Methods', 'Statistics', 'Written Communication']
},
{
  id: 'science_communicator',
  title: 'Science Communicator',
  careerId: 'research',
  kind: 'hidden',
  summary: 'Translates technical research into something the public can use.',
  affinity: { communication_score: 1, interest_science: 0.8, creativity_score: 0.6 },
  skills: ['Written Communication', 'Communication', 'Research Methods']
},
{
  id: 'ai_ux_researcher',
  title: 'AI UX Researcher',
  careerId: 'research',
  kind: 'emerging',
  summary: 'Studies how people behave with AI systems and feeds that back into design.',
  affinity: { research_preference: 0.9, people_orientation: 0.8, interest_technology: 0.7, communication_score: 0.6 },
  skills: ['User Research', 'Research Methods', 'Analytical Thinking']
},

// Cloud
{
  id: 'cloud_engineer',
  title: 'Cloud / DevOps Engineer',
  careerId: 'cloud',
  kind: 'core',
  summary: 'Builds the infrastructure and pipelines everything else runs on.',
  affinity: { technical_confidence: 1, coding_preference: 0.8, problem_solving_score: 0.8 },
  skills: ['Linux & Scripting', 'Systems Thinking', 'Technical Confidence']
},
{
  id: 'platform_reliability',
  title: 'Reliability Engineer',
  careerId: 'cloud',
  kind: 'adjacent',
  summary: 'Owns uptime — measuring, predicting and preventing failure.',
  affinity: { analytical_score: 0.9, technical_confidence: 0.9, problem_solving_score: 0.7 },
  skills: ['Systems Thinking', 'Linux & Scripting', 'Analytical Thinking']
},
{
  id: 'digital_twin',
  title: 'Digital Twin Specialist',
  careerId: 'cloud',
  kind: 'emerging',
  summary: 'Builds live virtual models of physical systems for simulation and monitoring.',
  affinity: { interest_technology: 0.8, interest_science: 0.7, analytical_score: 0.8, coding_preference: 0.6 },
  skills: ['Programming', 'Systems Thinking', 'Statistics']
},

// Product
{
  id: 'product_manager',
  title: 'Product Manager',
  careerId: 'product',
  kind: 'core',
  summary: 'Decides what gets built next and why it matters to users and the business.',
  affinity: { business_orientation: 0.9, communication_score: 0.9, leadership_score: 0.8, problem_solving_score: 0.6 },
  skills: ['Business Thinking', 'Communication', 'User Research']
},
{
  id: 'ai_product_designer',
  title: 'AI Product Designer',
  careerId: 'product',
  kind: 'emerging',
  summary: 'Shapes products where the core experience is powered by a model.',
  affinity: { design_preference: 0.9, interest_technology: 0.8, creativity_score: 0.8, business_orientation: 0.6 },
  skills: ['Figma', 'User Research', 'Business Thinking', 'Machine Learning']
},
{
  id: 'learning_experience',
  title: 'Learning Experience Designer',
  careerId: 'product',
  kind: 'hidden',
  summary: 'Designs how people are taught inside a product or a programme.',
  affinity: { people_orientation: 0.9, creativity_score: 0.8, communication_score: 0.8, design_preference: 0.6 },
  skills: ['User Research', 'Communication', 'Visual & Interaction Design']
}];


export const ROLE_INDEX: Record<string, Role> = ROLES.reduce(
  (acc, role) => {
    acc[role.id] = role;
    return acc;
  },
  {} as Record<string, Role>
);

export const ROLE_KIND_LABEL = {
  core: 'Best-fit role',
  adjacent: 'Adjacent role',
  hidden: 'Hidden role',
  emerging: 'Emerging role'
} as const;