import type { Academy } from '../types';

/** MOCK DATA — sample learning providers for the MVP, not verified listings. */
export const ACADEMIES: Academy[] = [
{
  id: 'acad-1',
  name: 'BrandMonk Academy',
  course: 'Product Design Foundations',
  skills: ['Figma', 'Visual & Interaction Design', 'User Research', 'Creativity'],
  careers: ['uiux', 'product'],
  mode: 'Offline',
  level: 'Beginner',
  duration: '10 weeks',
  location: 'Coimbatore',
  rating: 4.8,
  reviews: 485
},
{
  id: 'acad-2',
  name: 'Srichand Academy',
  course: 'UX Research & Usability Testing',
  skills: ['User Research', 'Communication', 'Empathy for Users'],
  careers: ['uiux', 'product'],
  mode: 'Hybrid',
  level: 'Intermediate',
  duration: '6 weeks',
  location: 'Coimbatore',
  rating: 4.7,
  reviews: 320
},
{
  id: 'acad-3',
  name: 'Nova Data Lab',
  course: 'Applied Machine Learning',
  skills: ['Python', 'Machine Learning', 'Statistics'],
  careers: ['ai_ml', 'data'],
  mode: 'Online',
  level: 'Advanced',
  duration: '16 weeks',
  location: 'Online',
  rating: 4.6,
  reviews: 1240
},
{
  id: 'acad-4',
  name: 'Nova Data Lab',
  course: 'SQL & Analytics Essentials',
  skills: ['SQL', 'Data Visualisation', 'Spreadsheets & Tools'],
  careers: ['data', 'business'],
  mode: 'Online',
  level: 'Beginner',
  duration: '5 weeks',
  location: 'Online',
  rating: 4.5,
  reviews: 890
},
{
  id: 'acad-5',
  name: 'Cipher Security School',
  course: 'Defensive Security Bootcamp',
  skills: ['Networking & Systems', 'Scripting', 'Analytical Thinking'],
  careers: ['cybersecurity', 'cloud'],
  mode: 'Hybrid',
  level: 'Intermediate',
  duration: '12 weeks',
  location: 'Chennai',
  rating: 4.4,
  reviews: 210
},
{
  id: 'acad-6',
  name: 'StackForge Institute',
  course: 'Full Stack Development',
  skills: ['Programming', 'Databases', 'Problem Solving'],
  careers: ['software', 'cloud'],
  mode: 'Offline',
  level: 'Beginner',
  duration: '20 weeks',
  location: 'Bengaluru',
  rating: 4.6,
  reviews: 1530
},
{
  id: 'acad-7',
  name: 'StackForge Institute',
  course: 'Cloud & DevOps Practitioner',
  skills: ['Linux & Scripting', 'Technical Confidence', 'Systems Thinking'],
  careers: ['cloud', 'software'],
  mode: 'Online',
  level: 'Intermediate',
  duration: '9 weeks',
  location: 'Online',
  rating: 4.3,
  reviews: 640
},
{
  id: 'acad-8',
  name: 'Meridian Business Studio',
  course: 'Management & Leadership Basics',
  skills: ['Leadership', 'Communication', 'Business Thinking'],
  careers: ['business', 'product'],
  mode: 'Offline',
  level: 'Beginner',
  duration: '8 weeks',
  location: 'Chennai',
  rating: 4.5,
  reviews: 275
},
{
  id: 'acad-9',
  name: 'Signal Marketing School',
  course: 'Digital Marketing & Analytics',
  skills: ['Communication', 'Analytics', 'Creativity'],
  careers: ['marketing', 'business'],
  mode: 'Online',
  level: 'Beginner',
  duration: '7 weeks',
  location: 'Online',
  rating: 4.4,
  reviews: 980
},
{
  id: 'acad-10',
  name: 'Ardent Research Collective',
  course: 'Research Methods & Academic Writing',
  skills: ['Research Methods', 'Written Communication', 'Analytical Thinking'],
  careers: ['research', 'data'],
  mode: 'Hybrid',
  level: 'Advanced',
  duration: '11 weeks',
  location: 'Hyderabad',
  rating: 4.2,
  reviews: 150
}];


export const ACADEMY_MODES = ['Online', 'Offline', 'Hybrid'] as const;
export const ACADEMY_LEVELS = ['Beginner', 'Intermediate', 'Advanced'] as const;