export interface AvatarOption {
  id: string;
  gender: 'male' | 'female';
  name: string;
  image: string;
}

/**
 * AI mentor avatars — VISUAL PERSONALISATION ONLY in this MVP.
 * No voice, conversation, animation or lip-sync behaviour is attached to them.
 */
export const AVATARS: AvatarOption[] = [
{
  id: 'm1',
  gender: 'male',
  name: 'Arun',
  image: "/d209d16a-f43b-4c2c-b60a-9f7414b6558f.jpg"
},
{
  id: 'm2',
  gender: 'male',
  name: 'Nikhil',
  image: "/12489e55-8e2e-4069-8f3e-54715897cf14.jpg"
},
{
  id: 'm3',
  gender: 'male',
  name: 'Vikram',
  image: "/afeecf5d-c090-4f32-95de-c4a38533892f.jpg"
},
{
  id: 'm4',
  gender: 'male',
  name: 'Daniel',
  image: "/8b556565-9f43-45a3-a364-89fd12beaab1.jpg"
},
{
  id: 'f1',
  gender: 'female',
  name: 'Meera',
  image: "/19375fd7-3459-4c99-968c-fc4d00a97fd7.jpg"
},
{
  id: 'f2',
  gender: 'female',
  name: 'Divya',
  image: "/c64028ce-fbe9-4eb9-ac9a-f34a6aff9076.jpg"
},
{
  id: 'f3',
  gender: 'female',
  name: 'Anika',
  image: "/a69ba6e7-370e-41e4-b6cc-1db4e1e15f22.jpg"
},
{
  id: 'f4',
  gender: 'female',
  name: 'Sara',
  image: "/673e8d78-8d20-4a8b-a572-a79e07633ec9.jpg"
}];


export const getAvatar = (id: string | null) => AVATARS.find((a) => a.id === id) ?? null;

export const LANGUAGES = ['English', 'Tamil', 'Hindi', 'Malayalam'];

export const USER_CATEGORIES = [
{ id: 'school', labelKey: 'cat.school', icon: 'School' },
{ id: 'college', labelKey: 'cat.college', icon: 'GraduationCap' },
{ id: 'graduate', labelKey: 'cat.graduate', icon: 'Award' },
{ id: 'working', labelKey: 'cat.working', icon: 'Briefcase' },
{ id: 'switcher', labelKey: 'cat.switcher', icon: 'Route' },
{ id: 'other', labelKey: 'cat.other', icon: 'CircleEllipsis' }];