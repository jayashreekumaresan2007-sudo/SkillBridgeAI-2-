import type { Question } from '../types';

/**
 * JOURNEY + CATEGORY QUESTION BANK
 *
 * These questions sit alongside the shared core questions in data/assessment.ts.
 * Composition happens in `getQuestions(journey, category)` — every question here
 * carries the same feature weights contract, so the ML feature extractor is
 * indifferent to which set a user actually saw.
 */

/* ------------------------------------------------------------------ */
/* CAREER JOURNEY — category-specific questions                        */
/* ------------------------------------------------------------------ */

export const CAREER_CATEGORY_QUESTIONS: Record<string, Question[]> = {
  school: [
  {
    id: 'school_subject',
    type: 'multi',
    kind: 'Interest',
    maxSelect: 3,
    title: 'Which school subjects do you enjoy most?',
    helper: 'Pick up to 3 — the ones you would happily study on a free afternoon.',
    options: [
    { id: 'maths', label: 'Maths', icon: 'Calculator', weights: { analytical_score: 0.9, interest_data: 0.5 } },
    { id: 'science', label: 'Science', icon: 'FlaskConical', weights: { interest_science: 0.9, research_preference: 0.5 } },
    { id: 'computers', label: 'Computers', icon: 'Cpu', weights: { interest_technology: 0.9, coding_preference: 0.5 } },
    { id: 'art', label: 'Art & Craft', icon: 'Palette', weights: { creativity_score: 0.9, design_preference: 0.5 } },
    { id: 'languages', label: 'Languages', icon: 'Megaphone', weights: { communication_score: 0.8, interest_communication: 0.5 } },
    { id: 'social', label: 'Social Studies', icon: 'Users', weights: { people_orientation: 0.7, business_orientation: 0.4 } }]

  },
  {
    id: 'school_style',
    type: 'single',
    kind: 'Activity',
    title: 'In a class project, which part do you usually take?',
    helper: 'Think about the last group project you actually enjoyed.',
    options: [
    { id: 'ideas', label: 'Coming up with the idea', icon: 'Sparkles', weights: { creativity_score: 0.9, design_preference: 0.4 } },
    { id: 'making', label: 'Making or building it', icon: 'Hammer', weights: { coding_preference: 0.7, technical_confidence: 0.5 } },
    { id: 'facts', label: 'Finding the facts and checking them', icon: 'Search', weights: { research_preference: 0.9, analytical_score: 0.5 } },
    { id: 'explaining', label: 'Explaining it to the class', icon: 'Megaphone', weights: { communication_score: 0.9, leadership_score: 0.4 } }]

  }],

  college: [
  {
    id: 'college_strength',
    type: 'single',
    kind: 'Category',
    title: 'Which part of your coursework comes easiest to you?',
    helper: 'The part where you rarely need extra help.',
    options: [
    { id: 'programming', label: 'Programming assignments', icon: 'Code2', weights: { coding_preference: 0.9, technical_confidence: 0.6 } },
    { id: 'analysis', label: 'Analysis and calculations', icon: 'LineChart', weights: { analytical_score: 0.9, interest_data: 0.5 } },
    { id: 'design', label: 'Design and presentation work', icon: 'PenTool', weights: { design_preference: 0.9, creativity_score: 0.5 } },
    { id: 'writing', label: 'Reports, writing and viva', icon: 'FileText', weights: { communication_score: 0.8, research_preference: 0.4 } }]

  },
  {
    id: 'college_industry',
    type: 'multi',
    kind: 'Interest',
    maxSelect: 2,
    title: 'Which industries would you like to work in?',
    helper: 'Pick up to 2 — go with curiosity, not job security.',
    options: [
    { id: 'software', label: 'Software & IT', icon: 'AppWindow', weights: { interest_technology: 0.9, coding_preference: 0.4 } },
    { id: 'aiml', label: 'AI & Research labs', icon: 'BrainCircuit', weights: { interest_technology: 0.6, research_preference: 0.7, analytical_score: 0.5 } },
    { id: 'creative', label: 'Creative & Product studios', icon: 'Brush', weights: { design_preference: 0.8, creativity_score: 0.6 } },
    { id: 'consulting', label: 'Business & Consulting', icon: 'Briefcase', weights: { business_orientation: 0.9, communication_score: 0.4 } },
    { id: 'security', label: 'Security & Infrastructure', icon: 'Shield', weights: { technical_confidence: 0.7, problem_solving_score: 0.5 } },
    { id: 'social_impact', label: 'Education & Social impact', icon: 'HeartHandshake', weights: { people_orientation: 0.9, communication_score: 0.4 } }]

  }],

  graduate: [
  {
    id: 'grad_transferable',
    type: 'multi',
    kind: 'Category',
    maxSelect: 3,
    title: 'Which of these have you already done in a project or internship?',
    helper: 'Pick up to 3 — real experience counts more than coursework here.',
    options: [
    { id: 'built', label: 'Built and shipped something technical', icon: 'Rocket', weights: { coding_preference: 0.8, technical_confidence: 0.7 } },
    { id: 'analysed', label: 'Analysed a real dataset', icon: 'Database', weights: { analytical_score: 0.9, interest_data: 0.7 } },
    { id: 'designed', label: 'Designed screens or brand material', icon: 'Layers', weights: { design_preference: 0.9, creativity_score: 0.5 } },
    { id: 'presented', label: 'Presented to a client or panel', icon: 'Megaphone', weights: { communication_score: 0.9, business_orientation: 0.4 } },
    { id: 'coordinated', label: 'Coordinated a team', icon: 'Flag', weights: { leadership_score: 0.9, teamwork_score: 0.5 } },
    { id: 'researched', label: 'Published or wrote up research', icon: 'Microscope', weights: { research_preference: 0.9, interest_science: 0.5 } }]

  },
  {
    id: 'grad_goal',
    type: 'single',
    kind: 'Category',
    title: 'What is your priority for the next 12 months?',
    helper: 'Your honest priority, not the impressive answer.',
    options: [
    { id: 'first_role', label: 'Land a first role in a technical field', icon: 'Target', weights: { technical_confidence: 0.6, coding_preference: 0.5 } },
    { id: 'specialise', label: 'Specialise deeply in one domain', icon: 'GraduationCap', weights: { research_preference: 0.8, analytical_score: 0.4 } },
    { id: 'portfolio', label: 'Build a portfolio of real work', icon: 'Sparkles', weights: { creativity_score: 0.7, design_preference: 0.5 } },
    { id: 'business_side', label: 'Move into the business or product side', icon: 'TrendingUp', weights: { business_orientation: 0.9, communication_score: 0.5 } }]

  }],

  working: [
  {
    id: 'work_expertise',
    type: 'single',
    kind: 'Category',
    title: 'Where does most of your current work sit?',
    helper: 'Choose the closest match to your day-to-day.',
    options: [
    { id: 'technical_delivery', label: 'Technical delivery and systems', icon: 'Code2', weights: { technical_confidence: 0.9, coding_preference: 0.6 } },
    { id: 'reporting', label: 'Reporting, numbers and analysis', icon: 'BarChart3', weights: { analytical_score: 0.9, interest_data: 0.6 } },
    { id: 'creative_work', label: 'Creative, content or design work', icon: 'Brush', weights: { creativity_score: 0.8, design_preference: 0.6 } },
    { id: 'people_ops', label: 'Clients, teams and operations', icon: 'Handshake', weights: { people_orientation: 0.8, business_orientation: 0.6 } }]

  },
  {
    id: 'work_growth',
    type: 'single',
    kind: 'Category',
    title: 'What kind of move are you looking for?',
    helper: 'This decides whether we suggest progression or transition paths.',
    options: [
    { id: 'deeper', label: 'Go deeper in my current field', icon: 'Microscope', weights: { technical_confidence: 0.7, research_preference: 0.6 } },
    { id: 'adjacent_move', label: 'Move to an adjacent role', icon: 'Route', weights: { problem_solving_score: 0.6, business_orientation: 0.5 } },
    { id: 'lead_people', label: 'Lead people and strategy', icon: 'Flag', weights: { leadership_score: 0.9, business_orientation: 0.6, communication_score: 0.5 } },
    { id: 'new_field', label: 'Change field entirely', icon: 'Sparkles', weights: { creativity_score: 0.6, problem_solving_score: 0.5 } }]

  }],

  switcher: [
  {
    id: 'switch_driver',
    type: 'single',
    kind: 'Category',
    title: 'What is pushing you to change direction?',
    helper: 'Understanding the reason changes what we recommend.',
    options: [
    { id: 'growth_stalled', label: 'Growth has stalled where I am', icon: 'TrendingUp', weights: { business_orientation: 0.6, leadership_score: 0.5 } },
    { id: 'want_technical', label: 'I want more technical work', icon: 'Cpu', weights: { interest_technology: 0.9, coding_preference: 0.6 } },
    { id: 'want_creative', label: 'I want more creative work', icon: 'Palette', weights: { creativity_score: 0.9, design_preference: 0.6 } },
    { id: 'want_meaning', label: 'I want work that means more to me', icon: 'HeartHandshake', weights: { people_orientation: 0.9, communication_score: 0.4 } }]

  },
  {
    id: 'switch_transfer',
    type: 'multi',
    kind: 'Category',
    maxSelect: 3,
    title: 'Which strengths would you bring with you?',
    helper: 'Pick up to 3 — these become the bridge into your next field.',
    options: [
    { id: 'stakeholders', label: 'Managing stakeholders', icon: 'Handshake', weights: { communication_score: 0.8, business_orientation: 0.6 } },
    { id: 'process', label: 'Improving processes', icon: 'ListChecks', weights: { analytical_score: 0.7, problem_solving_score: 0.6 } },
    { id: 'tools', label: 'Picking up new tools quickly', icon: 'Zap', weights: { technical_confidence: 0.8, coding_preference: 0.4 } },
    { id: 'mentoring', label: 'Mentoring and training others', icon: 'Users', weights: { people_orientation: 0.8, leadership_score: 0.6 } },
    { id: 'storytelling', label: 'Explaining complex things simply', icon: 'Megaphone', weights: { communication_score: 0.9, creativity_score: 0.4 } },
    { id: 'domain', label: 'Deep knowledge of my current domain', icon: 'Award', weights: { research_preference: 0.7, analytical_score: 0.5 } }]

  }]

};

/* ------------------------------------------------------------------ */
/* SKILL JOURNEY — practical, behaviour-led questions                  */
/* ------------------------------------------------------------------ */

export const SKILL_SHARED_QUESTIONS: Question[] = [
{
  id: 'skill_learning',
  type: 'single',
  kind: 'Scenario',
  scenarioContext: 'Skill scenario 1 of 2',
  title: 'You have one week to learn something new for a project. What do you actually do?',
  helper: 'Pick your real habit, not the ideal one.',
  options: [
  { id: 'course', label: 'Follow a structured course end to end', icon: 'GraduationCap', weights: { research_preference: 0.7, analytical_score: 0.4 } },
  { id: 'build_first', label: 'Start building and learn as I break things', icon: 'Hammer', weights: { coding_preference: 0.8, problem_solving_score: 0.6 } },
  { id: 'examples', label: 'Study examples others have made', icon: 'Layers', weights: { design_preference: 0.7, creativity_score: 0.5 } },
  { id: 'ask', label: 'Ask someone who already knows it', icon: 'Users', weights: { people_orientation: 0.7, communication_score: 0.6 } }]

},
{
  id: 'skill_feedback',
  type: 'single',
  kind: 'Scenario',
  scenarioContext: 'Skill scenario 2 of 2',
  title: 'Your work gets detailed criticism in front of the group. What happens next?',
  helper: 'This tells us about adaptability, not confidence.',
  options: [
  { id: 'rework', label: 'I rework it straight away', icon: 'ListChecks', weights: { problem_solving_score: 0.7, technical_confidence: 0.5 } },
  { id: 'question', label: 'I ask questions until I understand the reasoning', icon: 'Search', weights: { analytical_score: 0.7, research_preference: 0.5 } },
  { id: 'discuss_team', label: 'I talk it through with the team first', icon: 'MessagesSquare', weights: { teamwork_score: 0.8, communication_score: 0.6 } },
  { id: 'defend', label: 'I explain my reasoning, then decide', icon: 'Flag', weights: { leadership_score: 0.8, communication_score: 0.5 } }]

}];


export const SKILL_CATEGORY_QUESTIONS: Record<string, Question[]> = {
  school: [
  {
    id: 'skill_school_core',
    type: 'rating',
    kind: 'Skill confidence',
    title: 'How confident do you feel about these?',
    helper: '1 = still learning, 5 = very confident. Nobody sees this but you.',
    items: [
    { id: 'sch_present', label: 'Speaking in front of the class', feature: 'communication_score' },
    { id: 'sch_puzzle', label: 'Working out tricky puzzles', feature: 'problem_solving_score' },
    { id: 'sch_make', label: 'Making or drawing something original', feature: 'creativity_score' },
    { id: 'sch_computer', label: 'Using a computer for schoolwork', feature: 'technical_confidence' }]

  },
  {
    id: 'skill_school_learn',
    type: 'rating',
    kind: 'Rate yourself',
    title: 'And these habits?',
    helper: 'Think about the last few months of school.',
    items: [
    { id: 'sch_curious', label: 'Looking things up on my own', feature: 'research_preference' },
    { id: 'sch_team', label: 'Working in a group', feature: 'teamwork_score' },
    { id: 'sch_lead', label: 'Organising others', feature: 'leadership_score' },
    { id: 'sch_numbers', label: 'Working with numbers', feature: 'analytical_score' }]

  }],

  college: [
  {
    id: 'skill_college_core',
    type: 'rating',
    kind: 'Skill confidence',
    title: 'Rate your current working skills',
    helper: '1 = still learning, 5 = very confident.',
    items: [
    { id: 'col_code', label: 'Writing code or scripts', feature: 'coding_preference' },
    { id: 'col_data', label: 'Handling and interpreting data', feature: 'analytical_score' },
    { id: 'col_design', label: 'Designing interfaces or visuals', feature: 'design_preference' },
    { id: 'col_tools', label: 'Picking up new digital tools', feature: 'technical_confidence' }]

  },
  {
    id: 'skill_college_soft',
    type: 'rating',
    kind: 'Rate yourself',
    title: 'And how you work with others',
    helper: 'Based on your project and internship experience.',
    items: [
    { id: 'col_comm', label: 'Explaining your work clearly', feature: 'communication_score' },
    { id: 'col_team', label: 'Collaborating on a team project', feature: 'teamwork_score' },
    { id: 'col_lead', label: 'Taking the lead when needed', feature: 'leadership_score' },
    { id: 'col_research', label: 'Researching an unfamiliar topic', feature: 'research_preference' }]

  }],

  graduate: [
  {
    id: 'skill_grad_core',
    type: 'rating',
    kind: 'Skill confidence',
    title: 'Rate your job-readiness today',
    helper: '1 = still learning, 5 = very confident.',
    items: [
    { id: 'grad_domain', label: 'Depth in your main subject', feature: 'analytical_score' },
    { id: 'grad_tools', label: 'Professional tools of your field', feature: 'technical_confidence' },
    { id: 'grad_build', label: 'Producing finished, usable work', feature: 'coding_preference' },
    { id: 'grad_interview', label: 'Explaining your work in an interview', feature: 'communication_score' }]

  },
  {
    id: 'skill_grad_soft',
    type: 'rating',
    kind: 'Rate yourself',
    title: 'And your working habits',
    helper: 'Be honest — this shapes what we tell you to focus on.',
    items: [
    { id: 'grad_adapt', label: 'Adapting when requirements change', feature: 'problem_solving_score' },
    { id: 'grad_learn', label: 'Learning something new unaided', feature: 'research_preference' },
    { id: 'grad_team', label: 'Working with people you did not choose', feature: 'teamwork_score' },
    { id: 'grad_initiative', label: 'Taking initiative without being asked', feature: 'leadership_score' }]

  }],

  working: [
  {
    id: 'skill_work_core',
    type: 'rating',
    kind: 'Skill confidence',
    title: 'Rate your professional skills today',
    helper: '1 = developing, 5 = this is a real strength.',
    items: [
    { id: 'wrk_domain', label: 'Technical or domain expertise', feature: 'technical_confidence' },
    { id: 'wrk_analysis', label: 'Analysis and decision-making with data', feature: 'analytical_score' },
    { id: 'wrk_strategy', label: 'Strategic and commercial thinking', feature: 'business_orientation' },
    { id: 'wrk_comm', label: 'Communicating with senior stakeholders', feature: 'communication_score' }]

  },
  {
    id: 'skill_work_lead',
    type: 'rating',
    kind: 'Rate yourself',
    title: 'And your leadership and adaptability',
    helper: 'Think about the last six months at work.',
    items: [
    { id: 'wrk_lead', label: 'Leading or mentoring others', feature: 'leadership_score' },
    { id: 'wrk_adapt', label: 'Handling ambiguous problems', feature: 'problem_solving_score' },
    { id: 'wrk_new', label: 'Learning new tools or platforms', feature: 'coding_preference' },
    { id: 'wrk_people', label: 'Building working relationships', feature: 'people_orientation' }]

  }],

  switcher: [
  {
    id: 'skill_switch_core',
    type: 'rating',
    kind: 'Skill confidence',
    title: 'Rate the skills you would carry into a new field',
    helper: '1 = developing, 5 = this is a real strength.',
    items: [
    { id: 'swi_comm', label: 'Communicating and influencing', feature: 'communication_score' },
    { id: 'swi_analysis', label: 'Structured analysis and problem solving', feature: 'analytical_score' },
    { id: 'swi_tools', label: 'Learning unfamiliar tools', feature: 'technical_confidence' },
    { id: 'swi_people', label: 'Working with and through people', feature: 'people_orientation' }]

  },
  {
    id: 'skill_switch_new',
    type: 'rating',
    kind: 'Rate yourself',
    title: 'And the skills you would need to build',
    helper: 'Rate where you are today, not where you want to be.',
    items: [
    { id: 'swi_code', label: 'Technical building or coding', feature: 'coding_preference' },
    { id: 'swi_design', label: 'Design and visual thinking', feature: 'design_preference' },
    { id: 'swi_research', label: 'Research and self-directed study', feature: 'research_preference' },
    { id: 'swi_lead', label: 'Leading in an unfamiliar domain', feature: 'leadership_score' }]

  }]

};

/* ------------------------------------------------------------------ */
/* NOT SURE JOURNEY                                                    */
/* ------------------------------------------------------------------ */

export const NOT_SURE_QUESTIONS: Question[] = [
{
  id: 'unsure_block',
  type: 'single',
  kind: 'Category',
  title: 'What makes the decision hard right now?',
  helper: 'This tells us where to start, not what you should choose.',
  options: [
  { id: 'too_many', label: 'Too many options look interesting', icon: 'Layers', weights: { creativity_score: 0.5, research_preference: 0.4 } },
  { id: 'dont_know', label: 'I don’t know what jobs actually exist', icon: 'Search', weights: { research_preference: 0.6, analytical_score: 0.3 } },
  { id: 'not_good', label: 'I’m not sure what I’m good at', icon: 'HelpCircle', weights: { problem_solving_score: 0.4, teamwork_score: 0.3 } },
  { id: 'pressure', label: 'People around me expect a specific path', icon: 'Users', weights: { people_orientation: 0.6, communication_score: 0.3 } }]

},
{
  id: 'unsure_energy',
  type: 'single',
  kind: 'Activity',
  title: 'Think of a time you lost track of the hours. What were you doing?',
  helper: 'The activity matters more than the subject.',
  options: [
  { id: 'figuring', label: 'Figuring out why something wasn’t working', icon: 'Bug', weights: { problem_solving_score: 0.9, analytical_score: 0.5 } },
  { id: 'making_thing', label: 'Making something look or feel right', icon: 'PenTool', weights: { design_preference: 0.9, creativity_score: 0.6 } },
  { id: 'reading', label: 'Going deep down a topic rabbit hole', icon: 'Microscope', weights: { research_preference: 0.9, interest_science: 0.4 } },
  { id: 'with_people', label: 'Talking something through with people', icon: 'MessagesSquare', weights: { people_orientation: 0.8, communication_score: 0.7 } },
  { id: 'organising', label: 'Organising a plan so it actually worked', icon: 'ListChecks', weights: { leadership_score: 0.8, business_orientation: 0.5 } }]

}];