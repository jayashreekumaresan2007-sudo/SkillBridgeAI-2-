import type { Institution } from '../types';

/**
 * MOCK DATA — representative examples for the MVP, not verified listings.
 * `distanceKm` is mock location data; no maps API is used in this prototype.
 */
export const INSTITUTIONS: Institution[] = [
{
  id: 'inst-1',
  name: 'Coimbatore Institute of Technology Studies',
  type: 'University',
  location: 'Peelamedu, Coimbatore',
  city: 'Coimbatore',
  programs: ['B.Tech Computer Science', 'M.Tech Artificial Intelligence', 'B.Tech Data Science'],
  skills: ['Python', 'Machine Learning', 'Statistics', 'Databases'],
  careers: ['ai_ml', 'software', 'data'],
  relevance: 'Offers an AI specialisation with a project-based final year.',
  modes: ['On campus'],
  rating: 4.6,
  reviews: 812,
  distanceKm: 2.3
},
{
  id: 'inst-2',
  name: 'Kongu Institute of Design & Media',
  type: 'College',
  location: 'Erode',
  city: 'Erode',
  programs: ['B.Des Interaction Design', 'Diploma in Visual Communication'],
  skills: ['Figma', 'User Research', 'Visual Design', 'Prototyping'],
  careers: ['uiux', 'marketing', 'product'],
  relevance: 'Design studio model with a portfolio review each semester.',
  modes: ['On campus', 'Hybrid'],
  rating: 4.4,
  reviews: 356,
  distanceKm: 5.1
},
{
  id: 'inst-3',
  name: 'Anna Regional School of Management',
  type: 'College',
  location: 'Chennai',
  city: 'Chennai',
  programs: ['BBA', 'MBA Operations', 'PG Diploma in Product Management'],
  skills: ['Business Thinking', 'Leadership', 'Communication', 'Analytics'],
  careers: ['business', 'product', 'marketing'],
  relevance: 'Case-study led management programmes with industry mentors.',
  modes: ['On campus'],
  rating: 4.5,
  reviews: 640,
  distanceKm: 12.7
},
{
  id: 'inst-4',
  name: 'Southern Polytechnic of Applied Computing',
  type: 'Polytechnic',
  location: 'Madurai',
  city: 'Madurai',
  programs: ['Diploma in Computer Engineering', 'Diploma in Network Security'],
  skills: ['Networking & Systems', 'Scripting', 'Linux & Scripting'],
  careers: ['cybersecurity', 'cloud', 'software'],
  relevance: 'Practical diploma route with lab-heavy security modules.',
  modes: ['On campus'],
  rating: 4.2,
  reviews: 274,
  distanceKm: 8.4
},
{
  id: 'inst-5',
  name: 'Nilgiri Centre for Data & Society',
  type: 'Research Institute',
  location: 'Coonoor',
  city: 'Coonoor',
  programs: ['MSc Data Science', 'Research Fellowship in Applied Statistics'],
  skills: ['Statistics', 'Research Methods', 'SQL', 'Data Visualisation'],
  careers: ['data', 'research', 'ai_ml'],
  relevance: 'Research-first environment with published student work.',
  modes: ['On campus', 'Hybrid'],
  rating: 4.7,
  reviews: 158,
  distanceKm: 16.2
},
{
  id: 'inst-6',
  name: 'Bengaluru School of Cloud Engineering',
  type: 'College',
  location: 'Whitefield, Bengaluru',
  city: 'Bengaluru',
  programs: ['B.Tech IT with Cloud Track', 'PG Diploma in DevOps'],
  skills: ['Linux & Scripting', 'Technical Confidence', 'Systems Thinking'],
  careers: ['cloud', 'software', 'cybersecurity'],
  relevance: 'Cloud lab partnership and a mandatory internship semester.',
  modes: ['On campus', 'Hybrid'],
  rating: 4.3,
  reviews: 921,
  distanceKm: 21.5
},
{
  id: 'inst-7',
  name: 'Kerala Institute of Communication Studies',
  type: 'College',
  location: 'Kochi',
  city: 'Kochi',
  programs: ['BA Media & Communication', 'PG Diploma in Digital Marketing'],
  skills: ['Communication', 'Creativity', 'Analytics', 'Audience Understanding'],
  careers: ['marketing', 'product', 'uiux'],
  relevance: 'Campaign studio with live client briefs each term.',
  modes: ['On campus'],
  rating: 4.4,
  reviews: 402,
  distanceKm: 18.9
},
{
  id: 'inst-8',
  name: 'Hyderabad Institute of Advanced Research',
  type: 'Research Institute',
  location: 'Gachibowli, Hyderabad',
  city: 'Hyderabad',
  programs: ['MSc Applied Sciences', 'Integrated PhD Programme'],
  skills: ['Research Methods', 'Analytical Thinking', 'Written Communication'],
  careers: ['research', 'ai_ml', 'data'],
  relevance: 'Fellowship support for early-career research associates.',
  modes: ['On campus'],
  rating: 4.6,
  reviews: 233,
  distanceKm: 24.6
}];


export const INSTITUTION_TYPES = ['University', 'College', 'Polytechnic', 'Research Institute'] as const;
export const INSTITUTION_CITIES = Array.from(new Set(INSTITUTIONS.map((i) => i.city))).sort();