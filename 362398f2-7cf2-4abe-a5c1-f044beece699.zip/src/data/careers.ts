import type { Career, CareerCategoryId } from '../types';

export const CAREERS: Record<CareerCategoryId, Career> = {
  ai_ml: {
    id: 'ai_ml',
    title: 'AI / ML Engineer',
    family: 'Technology',
    tagline: 'Teach systems to learn from data and make useful decisions.',
    overview:
    'AI/ML engineers turn data and mathematics into working intelligent systems — recommendation engines, prediction models and language tools that sit inside real products.',
    whatYouDo: [
    'Frame a real problem as a prediction or ranking task',
    'Prepare, clean and explore the data behind it',
    'Train, evaluate and tune models',
    'Ship models into products and monitor how they behave'],

    technicalSkills: ['Python', 'Mathematics & Statistics', 'Machine Learning', 'Deep Learning', 'SQL', 'Model Deployment'],
    softSkills: ['Structured problem solving', 'Curiosity', 'Explaining technical work simply'],
    requiredSkills: [
    { name: 'Python', source: 'coding_preference', weight: 1 },
    { name: 'Statistics', source: 'analytical_score', weight: 0.9 },
    { name: 'Machine Learning', source: 'technical_confidence', weight: 1 },
    { name: 'SQL & Data Handling', source: 'interest_data', weight: 0.8 },
    { name: 'Problem Solving', source: 'problem_solving_score', weight: 0.8 },
    { name: 'Communication', source: 'communication_score', weight: 0.5 }],

    learningPath: ['Python & maths foundations', 'Data handling with pandas & SQL', 'Classical ML', 'Deep learning', 'Deployment & MLOps'],
    entryRoles: ['ML Intern', 'Junior Data Scientist', 'AI Associate Engineer'],
    growth: ['ML Engineer', 'Senior ML Engineer', 'Applied Scientist / ML Lead'],
    responsibilities: 'Model building, data pipelines, evaluation and deployment.',
    related: ['data', 'software', 'research']
  },
  software: {
    id: 'software',
    title: 'Software Developer',
    family: 'Technology',
    tagline: 'Build the products and systems people use every day.',
    overview:
    'Software developers design, build and maintain applications — translating requirements into reliable, readable code that works at scale.',
    whatYouDo: [
    'Break features into buildable pieces',
    'Write and review application code',
    'Debug and improve existing systems',
    'Work with designers and product teams'],

    technicalSkills: ['Programming fundamentals', 'Data structures', 'APIs & databases', 'Version control', 'Testing'],
    softSkills: ['Collaboration', 'Attention to detail', 'Communication in code review'],
    requiredSkills: [
    { name: 'Programming', source: 'coding_preference', weight: 1 },
    { name: 'Problem Solving', source: 'problem_solving_score', weight: 0.9 },
    { name: 'Technical Confidence', source: 'technical_confidence', weight: 0.8 },
    { name: 'Databases', source: 'interest_data', weight: 0.6 },
    { name: 'Teamwork', source: 'teamwork_score', weight: 0.6 }],

    learningPath: ['One language deeply', 'Data structures & algorithms', 'Web or mobile framework', 'Databases & APIs', 'Testing & deployment'],
    entryRoles: ['Software Intern', 'Junior Developer', 'Associate Engineer'],
    growth: ['Software Engineer', 'Senior Engineer', 'Tech Lead / Architect'],
    responsibilities: 'Feature development, code quality, debugging and releases.',
    related: ['cloud', 'ai_ml', 'product']
  },
  data: {
    id: 'data',
    title: 'Data Analyst',
    family: 'Data',
    tagline: 'Turn messy numbers into decisions people can act on.',
    overview:
    'Data analysts collect, clean and interpret data, then explain what it means to the people who make decisions.',
    whatYouDo: [
    'Ask the right question before touching the data',
    'Clean and join data from different sources',
    'Build dashboards and reports',
    'Present findings to non-technical teams'],

    technicalSkills: ['SQL', 'Excel / Sheets', 'Python or R', 'Data visualisation', 'Statistics'],
    softSkills: ['Storytelling with data', 'Business curiosity', 'Precision'],
    requiredSkills: [
    { name: 'SQL', source: 'interest_data', weight: 1 },
    { name: 'Statistics', source: 'analytical_score', weight: 1 },
    { name: 'Data Visualisation', source: 'creativity_score', weight: 0.6 },
    { name: 'Spreadsheets & Tools', source: 'technical_confidence', weight: 0.7 },
    { name: 'Communication', source: 'communication_score', weight: 0.8 }],

    learningPath: ['Spreadsheets & statistics', 'SQL', 'Visualisation tools', 'Python for analysis', 'Business case studies'],
    entryRoles: ['Data Analyst Intern', 'Reporting Analyst', 'Business Analyst'],
    growth: ['Senior Analyst', 'Analytics Lead', 'Data Scientist'],
    responsibilities: 'Reporting, dashboards, analysis and decision support.',
    related: ['ai_ml', 'business', 'product']
  },
  cybersecurity: {
    id: 'cybersecurity',
    title: 'Cybersecurity Analyst',
    family: 'Technology',
    tagline: 'Protect systems, data and people from digital threats.',
    overview:
    'Cybersecurity analysts monitor systems, find weaknesses before attackers do, and respond when something goes wrong.',
    whatYouDo: [
    'Monitor systems for unusual activity',
    'Test applications and networks for weaknesses',
    'Respond to and document incidents',
    'Teach teams safer working habits'],

    technicalSkills: ['Networking', 'Operating systems', 'Security tools', 'Scripting', 'Threat analysis'],
    softSkills: ['Calm under pressure', 'Ethical judgement', 'Clear reporting'],
    requiredSkills: [
    { name: 'Networking & Systems', source: 'technical_confidence', weight: 1 },
    { name: 'Scripting', source: 'coding_preference', weight: 0.8 },
    { name: 'Analytical Thinking', source: 'analytical_score', weight: 0.9 },
    { name: 'Problem Solving', source: 'problem_solving_score', weight: 0.8 },
    { name: 'Reporting', source: 'communication_score', weight: 0.6 }],

    learningPath: ['Networking basics', 'Linux & systems', 'Security fundamentals', 'Hands-on labs & CTFs', 'Certification prep'],
    entryRoles: ['SOC Analyst (L1)', 'Security Intern', 'IT Support with security focus'],
    growth: ['Security Analyst', 'Penetration Tester', 'Security Architect'],
    responsibilities: 'Monitoring, vulnerability assessment and incident response.',
    related: ['cloud', 'software', 'data']
  },
  uiux: {
    id: 'uiux',
    title: 'UI/UX Designer',
    family: 'Design',
    tagline: 'Understand people, then design experiences that work for them.',
    overview:
    'UI/UX designers research user needs, structure information and design interfaces that are usable, accessible and pleasant.',
    whatYouDo: [
    'Talk to users and study how they behave',
    'Map flows and information architecture',
    'Design interfaces and design systems',
    'Test prototypes and iterate'],

    technicalSkills: ['Figma', 'Interaction design', 'Design systems', 'Prototyping', 'Usability testing'],
    softSkills: ['Empathy', 'Presenting design decisions', 'Receiving critique'],
    requiredSkills: [
    { name: 'Visual & Interaction Design', source: 'design_preference', weight: 1 },
    { name: 'Creativity', source: 'creativity_score', weight: 0.9 },
    { name: 'User Research', source: 'research_preference', weight: 0.8 },
    { name: 'Communication', source: 'communication_score', weight: 0.8 },
    { name: 'Empathy for Users', source: 'people_orientation', weight: 0.7 }],

    learningPath: ['Design fundamentals', 'Figma & prototyping', 'UX research methods', 'Design systems', 'Portfolio case studies'],
    entryRoles: ['Design Intern', 'Junior UI Designer', 'UX Researcher (Associate)'],
    growth: ['Product Designer', 'Senior Designer', 'Design Lead'],
    responsibilities: 'Research, wireframes, UI design, prototypes and testing.',
    related: ['product', 'marketing', 'software']
  },
  business: {
    id: 'business',
    title: 'Business / Management Associate',
    family: 'Business',
    tagline: 'Organise people, plans and priorities so work actually happens.',
    overview:
    'Business and management roles connect strategy to execution — planning, coordinating teams and measuring whether goals are being met.',
    whatYouDo: [
    'Plan and track projects and budgets',
    'Coordinate across teams and stakeholders',
    'Analyse performance against goals',
    'Present recommendations to leadership'],

    technicalSkills: ['Business analysis', 'Spreadsheets', 'Project management tools', 'Basic finance', 'Reporting'],
    softSkills: ['Leadership', 'Negotiation', 'Structured communication'],
    requiredSkills: [
    { name: 'Leadership', source: 'leadership_score', weight: 1 },
    { name: 'Communication', source: 'communication_score', weight: 1 },
    { name: 'Business Thinking', source: 'business_orientation', weight: 0.9 },
    { name: 'Analytical Thinking', source: 'analytical_score', weight: 0.7 },
    { name: 'Teamwork', source: 'teamwork_score', weight: 0.8 }],

    learningPath: ['Business fundamentals', 'Spreadsheets & reporting', 'Project management', 'Communication & presentation', 'Case study practice'],
    entryRoles: ['Management Trainee', 'Business Analyst', 'Operations Associate'],
    growth: ['Manager', 'Senior Manager', 'Business Head'],
    responsibilities: 'Planning, coordination, reporting and stakeholder management.',
    related: ['product', 'marketing', 'data']
  },
  marketing: {
    id: 'marketing',
    title: 'Digital Marketing Specialist',
    family: 'Communication',
    tagline: 'Reach the right people with the right message, and measure it.',
    overview:
    'Digital marketers build audiences and campaigns across channels, then use data to understand what worked.',
    whatYouDo: [
    'Plan campaigns and content calendars',
    'Write and brief creative work',
    'Run and optimise paid and organic channels',
    'Report on reach, engagement and conversion'],

    technicalSkills: ['SEO', 'Content strategy', 'Analytics tools', 'Ad platforms', 'Copywriting'],
    softSkills: ['Storytelling', 'Adaptability', 'Audience empathy'],
    requiredSkills: [
    { name: 'Communication', source: 'communication_score', weight: 1 },
    { name: 'Creativity', source: 'creativity_score', weight: 0.9 },
    { name: 'Analytics', source: 'analytical_score', weight: 0.7 },
    { name: 'Audience Understanding', source: 'people_orientation', weight: 0.8 },
    { name: 'Business Thinking', source: 'business_orientation', weight: 0.6 }],

    learningPath: ['Marketing fundamentals', 'Content & copywriting', 'SEO & analytics', 'Paid channels', 'Campaign portfolio'],
    entryRoles: ['Marketing Intern', 'Content Associate', 'Performance Marketing Executive'],
    growth: ['Marketing Specialist', 'Growth Lead', 'Marketing Manager'],
    responsibilities: 'Campaign planning, content, channels and performance reporting.',
    related: ['business', 'uiux', 'product']
  },
  research: {
    id: 'research',
    title: 'Research Associate',
    family: 'Science',
    tagline: 'Ask precise questions and find evidence-based answers.',
    overview:
    'Research roles design studies, gather evidence and publish findings that push a field or a product forward.',
    whatYouDo: [
    'Review existing literature and prior work',
    'Design and run experiments or studies',
    'Analyse results rigorously',
    'Write up and present findings'],

    technicalSkills: ['Research methods', 'Statistics', 'Academic writing', 'Lab or field tools', 'Data analysis'],
    softSkills: ['Patience', 'Intellectual honesty', 'Written communication'],
    requiredSkills: [
    { name: 'Research Methods', source: 'research_preference', weight: 1 },
    { name: 'Analytical Thinking', source: 'analytical_score', weight: 0.9 },
    { name: 'Scientific Interest', source: 'interest_science', weight: 0.8 },
    { name: 'Written Communication', source: 'communication_score', weight: 0.7 },
    { name: 'Problem Solving', source: 'problem_solving_score', weight: 0.7 }],

    learningPath: ['Domain fundamentals', 'Research methodology', 'Statistics & tools', 'Literature review practice', 'Paper or thesis project'],
    entryRoles: ['Research Assistant', 'Lab Associate', 'Junior Research Analyst'],
    growth: ['Research Associate', 'Senior Researcher', 'Principal Investigator'],
    responsibilities: 'Literature review, study design, analysis and publication.',
    related: ['ai_ml', 'data', 'cybersecurity']
  },
  cloud: {
    id: 'cloud',
    title: 'Cloud / DevOps Engineer',
    family: 'Technology',
    tagline: 'Keep software running reliably, automatically and at scale.',
    overview:
    'Cloud and DevOps engineers build the infrastructure and automation that lets teams ship software safely and often.',
    whatYouDo: [
    'Automate builds, tests and deployments',
    'Design cloud infrastructure',
    'Monitor reliability and cost',
    'Support developers with tooling'],

    technicalSkills: ['Linux', 'Cloud platforms', 'CI/CD', 'Containers', 'Infrastructure as code'],
    softSkills: ['Ownership', 'Calm incident handling', 'Documentation'],
    requiredSkills: [
    { name: 'Linux & Scripting', source: 'coding_preference', weight: 0.9 },
    { name: 'Technical Confidence', source: 'technical_confidence', weight: 1 },
    { name: 'Problem Solving', source: 'problem_solving_score', weight: 0.9 },
    { name: 'Systems Thinking', source: 'analytical_score', weight: 0.7 },
    { name: 'Teamwork', source: 'teamwork_score', weight: 0.6 }],

    learningPath: ['Linux & networking', 'One cloud platform', 'Containers', 'CI/CD pipelines', 'Infrastructure as code'],
    entryRoles: ['Cloud Support Associate', 'DevOps Intern', 'Junior Platform Engineer'],
    growth: ['DevOps Engineer', 'Site Reliability Engineer', 'Platform Lead'],
    responsibilities: 'Infrastructure, automation, reliability and deployment.',
    related: ['software', 'cybersecurity', 'ai_ml']
  },
  product: {
    id: 'product',
    title: 'Product Manager',
    family: 'Product',
    tagline: 'Decide what to build, why, and in what order.',
    overview:
    'Product managers sit between users, business goals and engineering — defining problems worth solving and guiding a team to solve them.',
    whatYouDo: [
    'Talk to users and gather evidence',
    'Define problems and success metrics',
    'Prioritise a roadmap with the team',
    'Coordinate launch and measure outcomes'],

    technicalSkills: ['Product discovery', 'Analytics', 'Roadmapping', 'Prototyping literacy', 'Writing specs'],
    softSkills: ['Influence without authority', 'Prioritisation', 'Clear writing'],
    requiredSkills: [
    { name: 'Communication', source: 'communication_score', weight: 1 },
    { name: 'Leadership', source: 'leadership_score', weight: 0.9 },
    { name: 'User Understanding', source: 'people_orientation', weight: 0.8 },
    { name: 'Analytical Thinking', source: 'analytical_score', weight: 0.8 },
    { name: 'Business Thinking', source: 'business_orientation', weight: 0.8 }],

    learningPath: ['Product fundamentals', 'User research basics', 'Analytics & metrics', 'Prioritisation frameworks', 'Case study portfolio'],
    entryRoles: ['Associate Product Manager', 'Product Analyst', 'Product Intern'],
    growth: ['Product Manager', 'Senior PM', 'Head of Product'],
    responsibilities: 'Discovery, prioritisation, specs and launch coordination.',
    related: ['uiux', 'business', 'data']
  }
};

export const CAREER_LIST = Object.values(CAREERS);

export const CAREER_FAMILY_COLORS: Record<string, string> = {
  Technology: 'bg-brand-50 text-brand-700',
  Data: 'bg-brand-50 text-brand-700',
  Design: 'bg-warnSoft text-warn',
  Business: 'bg-goodSoft text-good',
  Communication: 'bg-warnSoft text-warn',
  Science: 'bg-brand-50 text-brand-700',
  Product: 'bg-goodSoft text-good'
};