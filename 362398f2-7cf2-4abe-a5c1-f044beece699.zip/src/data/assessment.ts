import type { JourneyId, Question, UserCategoryId } from '../types';
import {
  CAREER_CATEGORY_QUESTIONS,
  NOT_SURE_QUESTIONS,
  SKILL_CATEGORY_QUESTIONS,
  SKILL_SHARED_QUESTIONS } from
'./questionBank';

/**
 * Shared core questions. Every option carries the feature weights that are fed
 * into the ML feature vector (see ml/features.ts).
 */
export const CORE_QUESTIONS: Question[] = [
{
  id: 'interest',
  type: 'multi',
  kind: 'Interest',
  title: 'Which areas are you most curious to explore?',
  helper: 'Pick up to 3 — choose what genuinely pulls your attention.',
  maxSelect: 3,
  options: [
  {
    id: 'tech',
    label: 'Technology & AI',
    icon: 'Cpu',
    weights: { interest_technology: 1, technical_confidence: 0.3 }
  },
  {
    id: 'design',
    label: 'Design & Creativity',
    icon: 'Palette',
    weights: { interest_design: 1, creativity_score: 0.3 }
  },
  {
    id: 'business',
    label: 'Business & Management',
    icon: 'Briefcase',
    weights: { interest_business: 1, business_orientation: 0.4 }
  },
  {
    id: 'data',
    label: 'Data & Analytics',
    icon: 'BarChart3',
    weights: { interest_data: 1, analytical_score: 0.3 }
  },
  {
    id: 'science',
    label: 'Science & Research',
    icon: 'FlaskConical',
    weights: { interest_science: 1, research_preference: 0.4 }
  },
  {
    id: 'media',
    label: 'Media & Communication',
    icon: 'Megaphone',
    weights: { interest_communication: 1, communication_score: 0.3 }
  }]

},
{
  id: 'activity',
  type: 'single',
  kind: 'Activity',
  title: 'What kind of activity would you naturally enjoy spending time on?',
  helper: 'Choose the option that feels most like you.',
  options: [
  {
    id: 'designing',
    label: 'Designing & creating',
    icon: 'PenTool',
    weights: { design_preference: 1, creativity_score: 0.6, interest_design: 0.4 }
  },
  {
    id: 'coding',
    label: 'Building & coding',
    icon: 'Code2',
    weights: { coding_preference: 1, technical_confidence: 0.5, interest_technology: 0.4 }
  },
  {
    id: 'solving',
    label: 'Solving problems',
    icon: 'Lightbulb',
    weights: { problem_solving_score: 0.8, analytical_score: 0.4 }
  },
  {
    id: 'analysing',
    label: 'Analysing data',
    icon: 'LineChart',
    weights: { analytical_score: 0.9, interest_data: 0.5 }
  },
  {
    id: 'people',
    label: 'Helping & working with people',
    icon: 'Users',
    weights: { people_orientation: 1, teamwork_score: 0.5, communication_score: 0.4 }
  },
  {
    id: 'research',
    label: 'Researching & exploring',
    icon: 'Search',
    weights: { research_preference: 1, interest_science: 0.4 }
  }]

},
{
  id: 'project',
  type: 'single',
  kind: 'Category',
  title: 'Which type of project would excite you the most?',
  helper: 'Imagine you have a free month to work on one thing.',
  options: [
  {
    id: 'app',
    label: 'Building an app or website',
    icon: 'AppWindow',
    weights: { coding_preference: 0.9, interest_technology: 0.5 }
  },
  {
    id: 'digital',
    label: 'Designing a digital product',
    icon: 'Layers',
    weights: { design_preference: 0.9, creativity_score: 0.5 }
  },
  {
    id: 'realdata',
    label: 'Analysing real-world data',
    icon: 'Database',
    weights: { analytical_score: 0.8, interest_data: 0.6 }
  },
  {
    id: 'social',
    label: 'Solving a social problem',
    icon: 'HeartHandshake',
    weights: { people_orientation: 0.7, problem_solving_score: 0.5, research_preference: 0.3 }
  },
  {
    id: 'innovative',
    label: 'Creating something innovative',
    icon: 'Sparkles',
    weights: { creativity_score: 0.7, research_preference: 0.4, interest_science: 0.3 }
  },
  {
    id: 'team',
    label: 'Leading a team project',
    icon: 'Flag',
    weights: { leadership_score: 0.9, business_orientation: 0.5, teamwork_score: 0.4 }
  }]

},
{
  id: 'scenario_ideas',
  type: 'single',
  kind: 'Scenario',
  scenarioContext: 'Scenario 1 of 2',
  title: 'Your team has two different ideas with strong arguments. What would you most likely do?',
  helper: 'There is no wrong answer — pick your honest instinct.',
  options: [
  {
    id: 'evidence',
    label: 'Choose the idea with stronger evidence',
    icon: 'ClipboardCheck',
    weights: { analytical_score: 0.8, research_preference: 0.4 }
  },
  {
    id: 'combine',
    label: 'Combine both ideas',
    icon: 'Combine',
    weights: { creativity_score: 0.7, problem_solving_score: 0.5 }
  },
  {
    id: 'discuss',
    label: 'Discuss and decide together',
    icon: 'MessagesSquare',
    weights: { teamwork_score: 0.8, communication_score: 0.6, people_orientation: 0.4 }
  },
  {
    id: 'prototype',
    label: 'Build quick versions and compare',
    icon: 'Rocket',
    weights: { coding_preference: 0.6, problem_solving_score: 0.7, technical_confidence: 0.4 }
  }]

},
{
  id: 'scenario_deadline',
  type: 'single',
  kind: 'Scenario',
  scenarioContext: 'Scenario 2 of 2',
  title: 'A project is behind schedule two days before the deadline. What is your first move?',
  helper: 'Choose what you would realistically do first.',
  options: [
  {
    id: 'replan',
    label: 'Re-plan the work and assign priorities',
    icon: 'ListChecks',
    weights: { leadership_score: 0.8, business_orientation: 0.5 }
  },
  {
    id: 'root',
    label: 'Find the root cause of the delay',
    icon: 'Bug',
    weights: { problem_solving_score: 0.8, analytical_score: 0.5 }
  },
  {
    id: 'help',
    label: 'Check in with teammates who are stuck',
    icon: 'Handshake',
    weights: { people_orientation: 0.8, teamwork_score: 0.6, communication_score: 0.4 }
  },
  {
    id: 'ship',
    label: 'Cut scope and ship the essential part',
    icon: 'Scissors',
    weights: { business_orientation: 0.6, problem_solving_score: 0.5, creativity_score: 0.3 }
  }]

},
{
  id: 'rate_core',
  type: 'rating',
  kind: 'Rate yourself',
  title: 'How would you rate yourself right now?',
  helper: 'Part 1 of 2 · 1 = still learning, 5 = very confident.',
  items: [
  { id: 'communication', label: 'Communication', feature: 'communication_score' },
  { id: 'problem_solving', label: 'Problem solving', feature: 'problem_solving_score' },
  { id: 'creativity', label: 'Creativity', feature: 'creativity_score' },
  { id: 'leadership', label: 'Leadership', feature: 'leadership_score' }]

},
{
  id: 'rate_more',
  type: 'rating',
  kind: 'Rate yourself',
  title: 'A few more about how you work',
  helper: 'Part 2 of 2 · 1 = still learning, 5 = very confident.',
  items: [
  { id: 'analytical', label: 'Analytical thinking', feature: 'analytical_score' },
  { id: 'technical', label: 'Technical confidence', feature: 'technical_confidence' },
  { id: 'teamwork', label: 'Teamwork', feature: 'teamwork_score' },
  { id: 'research', label: 'Research ability', feature: 'research_preference' }]

},
{
  id: 'confidence_tools',
  type: 'rating',
  kind: 'Skill confidence',
  title: 'How confident are you with these today?',
  helper: 'Be honest — this shapes your skill gap, not your score.',
  items: [
  { id: 'coding_conf', label: 'Writing code or scripts', feature: 'coding_preference' },
  { id: 'design_conf', label: 'Designing screens or visuals', feature: 'design_preference' },
  { id: 'data_conf', label: 'Working with numbers and data', feature: 'interest_data' },
  { id: 'present_conf', label: 'Presenting ideas to a group', feature: 'communication_score' }]

},
{
  id: 'environment',
  type: 'single',
  kind: 'Category',
  title: 'Where would you do your best work?',
  helper: 'This helps us shape your roadmap and learning suggestions.',
  options: [
  {
    id: 'lab',
    label: 'A research lab or study group',
    icon: 'Microscope',
    weights: { research_preference: 0.9, interest_science: 0.5 }
  },
  {
    id: 'startup',
    label: 'A fast-moving product team',
    icon: 'Zap',
    weights: { coding_preference: 0.4, business_orientation: 0.5, problem_solving_score: 0.4 }
  },
  {
    id: 'studio',
    label: 'A creative studio',
    icon: 'Brush',
    weights: { design_preference: 0.8, creativity_score: 0.5 }
  },
  {
    id: 'enterprise',
    label: 'A structured organisation',
    icon: 'Building2',
    weights: { business_orientation: 0.7, leadership_score: 0.4, teamwork_score: 0.3 }
  }]

},
{
  id: 'motivation',
  type: 'single',
  kind: 'Category',
  title: 'What matters most in your first job?',
  helper: 'Last one — then we build your profile.',
  options: [
  {
    id: 'learning',
    label: 'Learning deeply in one field',
    icon: 'GraduationCap',
    weights: { research_preference: 0.6, technical_confidence: 0.4 }
  },
  {
    id: 'impact',
    label: 'Seeing real impact from my work',
    icon: 'Target',
    weights: { people_orientation: 0.5, business_orientation: 0.4, problem_solving_score: 0.3 }
  },
  {
    id: 'build',
    label: 'Building things people use',
    icon: 'Hammer',
    weights: { coding_preference: 0.6, design_preference: 0.4, creativity_score: 0.3 }
  },
  {
    id: 'lead',
    label: 'Growing into a leadership role',
    icon: 'TrendingUp',
    weights: { leadership_score: 0.8, communication_score: 0.4, business_orientation: 0.5 }
  }]

}];


const core = (id: string): Question => {
  const question = CORE_QUESTIONS.find((q) => q.id === id);
  if (!question) throw new Error(`Unknown core question: ${id}`);
  return question;
};

const categoryOrDefault = <T,>(bank: Record<string, T>, category: string, fallback: string): T =>
bank[category] ?? bank[fallback];

/**
 * JOURNEY COMPOSITION
 * The three journeys produce genuinely different assessments, and each one
 * adapts its wording and examples to the user's category. Feature weights are
 * consistent across banks, so the same ML pipeline reads every variant.
 */
export function getQuestions(journey: JourneyId | null, category: string): Question[] {
  const cat = (category || 'college') as UserCategoryId;

  if (journey === 'skill') {
    return [
    core('interest'),
    core('activity'),
    ...categoryOrDefault(SKILL_CATEGORY_QUESTIONS, cat, 'college'),
    ...SKILL_SHARED_QUESTIONS,
    core('motivation')];

  }

  if (journey === 'not_sure') {
    return [
    core('interest'),
    core('activity'),
    NOT_SURE_QUESTIONS[0],
    core('scenario_ideas'),
    core('rate_core'),
    core('rate_more'),
    core('confidence_tools'),
    NOT_SURE_QUESTIONS[1],
    categoryOrDefault(CAREER_CATEGORY_QUESTIONS, cat, 'college')[0],
    core('environment')];

  }

  // Career journey (default)
  const categoryQuestions =
  cat === 'other' ?
  [core('motivation')] :
  categoryOrDefault(CAREER_CATEGORY_QUESTIONS, cat, 'college');

  return [
  core('interest'),
  ...categoryQuestions,
  core('activity'),
  core('project'),
  core('scenario_ideas'),
  core('scenario_deadline'),
  core('rate_core'),
  core('rate_more'),
  core('environment')];

}

/** Flat index of every question in every bank — used by feature extraction. */
export const ALL_QUESTIONS: Question[] = [
...CORE_QUESTIONS,
...Object.values(CAREER_CATEGORY_QUESTIONS).flat(),
...Object.values(SKILL_CATEGORY_QUESTIONS).flat(),
...SKILL_SHARED_QUESTIONS,
...NOT_SURE_QUESTIONS];


export const QUESTION_INDEX: Record<string, Question> = ALL_QUESTIONS.reduce(
  (acc, question) => {
    acc[question.id] = question;
    return acc;
  },
  {} as Record<string, Question>
);

export const JOURNEY_META: Record<JourneyId, {label: string;outcome: string;resultRoute: string;}> = {
  career: {
    label: 'Career discovery',
    outcome: 'Career matches, clarity check, skill gap and institutions',
    resultRoute: '/results'
  },
  skill: {
    label: 'Skill analysis',
    outcome: 'Your skill profile, priority skills and where to learn them',
    resultRoute: '/skill-results'
  },
  not_sure: {
    label: 'Full discovery',
    outcome: 'Career direction and skill direction, then how to act on both',
    resultRoute: '/results'
  }
};

/** Back-compat export — the career journey for a college student. */
export const QUESTIONS: Question[] = getQuestions('career', 'college');
export const TOTAL_QUESTIONS = QUESTIONS.length;