import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type {
  AnswerValue,
  CareerCategoryId,
  CareerRecommendation,
  ClarityAnswers,
  JourneyId,
  RoadmapStep,
  RoleDiscovery,
  SkillGapItem,
  SkillProfileItem,
  SkillRecommendation,
  UserProfile } from
'../types';
import { getQuestions } from '../data/assessment';
import { extractFeatures } from '../ml/features';
import { recommendCareers } from '../ml/service';
import { discoverRoles } from '../ml/discovery';
import { buildSkillProfile, recommendSkills } from '../ml/skillProfile';
import { buildRoadmap, buildSkillGap } from '../ml/skillGap';

const STORAGE_KEY = 'skillbridge.profile.v1';

export const emptyProfile: UserProfile = {
  name: '',
  email: '',
  isGuest: false,
  language: 'English',
  userCategory: '',
  avatar: null,
  gender: null,
  careerPath: null,
  assessmentAnswers: {},
  assessmentComplete: false,
  features: null,
  recommendations: [],
  selectedCareer: null,
  roadmapProgress: {},
  savedCareers: [],
  savedInstitutions: [],
  savedAcademies: [],
  clarityAnswers: null,
  careerRelevance: null,
  skillNotes: {},
  focusSkill: null
};

export type SaveKind = 'savedCareers' | 'savedInstitutions' | 'savedAcademies';

interface UserContextValue {
  profile: UserProfile;
  isAuthenticated: boolean;
  /** The journey chosen on the path screen — decides the assessment and the result screen. */
  journey: JourneyId;
  questions: ReturnType<typeof getQuestions>;
  update: (patch: Partial<UserProfile>) => void;
  setAnswer: (questionId: string, value: AnswerValue) => void;
  runRecommendation: () => CareerRecommendation[];
  discovery: RoleDiscovery;
  skillProfile: SkillProfileItem[];
  skillRecommendations: SkillRecommendation[];
  skillGap: SkillGapItem[];
  roadmap: RoadmapStep[];
  roadmapPercent: number;
  toggleRoadmapStep: (stepId: string) => void;
  toggleSaved: (kind: SaveKind, id: string) => void;
  isSaved: (kind: SaveKind, id: string) => boolean;
  clarityScore: number | null;
  setClarity: (answers: ClarityAnswers, relevance: UserProfile['careerRelevance']) => void;
  login: (name: string, email: string) => void;
  loginAsGuest: () => void;
  logout: () => void;
  resetAssessment: () => void;
}

const UserContext = createContext<UserContextValue | null>(null);

function loadProfile(): UserProfile {
  if (typeof window === 'undefined') return emptyProfile;
  try {
    const raw = window.sessionStorage.getItem(STORAGE_KEY);
    if (!raw) return emptyProfile;
    return { ...emptyProfile, ...(JSON.parse(raw) as UserProfile) };
  } catch {
    return emptyProfile;
  }
}

export function UserProvider({ children }: {children: React.ReactNode;}) {
  const [profile, setProfile] = useState<UserProfile>(loadProfile);

  useEffect(() => {
    try {
      window.sessionStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
    } catch {

      /* session persistence is best-effort */}
  }, [profile]);

  const update = useCallback((patch: Partial<UserProfile>) => {
    setProfile((prev) => ({ ...prev, ...patch }));
  }, []);

  const setAnswer = useCallback((questionId: string, value: AnswerValue) => {
    setProfile((prev) => ({
      ...prev,
      assessmentAnswers: { ...prev.assessmentAnswers, [questionId]: value }
    }));
  }, []);

  const runRecommendation = useCallback(() => {
    let result: CareerRecommendation[] = [];
    setProfile((prev) => {
      const features = extractFeatures(prev.assessmentAnswers);
      const recommendations = recommendCareers(features);
      result = recommendations;
      return {
        ...prev,
        features,
        recommendations,
        assessmentComplete: true,
        selectedCareer: prev.selectedCareer ?? recommendations[0]?.careerId ?? null
      };
    });
    return result;
  }, []);

  const journey: JourneyId =
  profile.careerPath === 'skill' || profile.careerPath === 'not_sure' ?
  profile.careerPath :
  'career';

  const questions = useMemo(
    () => getQuestions(journey, profile.userCategory),
    [journey, profile.userCategory]
  );

  const discovery = useMemo(() => discoverRoles(profile.features), [profile.features]);

  const skillProfile = useMemo(
    () => buildSkillProfile(profile.features, profile.userCategory),
    [profile.features, profile.userCategory]
  );

  const skillRecommendations = useMemo(() => recommendSkills(profile.features), [profile.features]);

  const activeCareer: CareerCategoryId | null =
  profile.selectedCareer ?? profile.recommendations[0]?.careerId ?? null;

  const skillGap = useMemo(
    () => activeCareer ? buildSkillGap(activeCareer, profile.features) : [],
    [activeCareer, profile.features]
  );

  const roadmap = useMemo(
    () => activeCareer ? buildRoadmap(activeCareer, skillGap) : [],
    [activeCareer, skillGap]
  );

  const completedSteps = activeCareer ? profile.roadmapProgress[activeCareer] ?? [] : [];
  const roadmapPercent = roadmap.length ? Math.round(completedSteps.length / roadmap.length * 100) : 0;

  const toggleRoadmapStep = useCallback(
    (stepId: string) => {
      if (!activeCareer) return;
      setProfile((prev) => {
        const current = prev.roadmapProgress[activeCareer] ?? [];
        const next = current.includes(stepId) ?
        current.filter((s) => s !== stepId) :
        [...current, stepId];
        return { ...prev, roadmapProgress: { ...prev.roadmapProgress, [activeCareer]: next } };
      });
    },
    [activeCareer]
  );

  const toggleSaved = useCallback((kind: SaveKind, id: string) => {
    setProfile((prev) => {
      const list = prev[kind];
      return {
        ...prev,
        [kind]: list.includes(id) ? list.filter((x) => x !== id) : [...list, id]
      };
    });
  }, []);

  const isSaved = useCallback(
    (kind: SaveKind, id: string) => profile[kind].includes(id),
    [profile]
  );

  const clarityScore = useMemo(() => {
    if (!profile.clarityAnswers) return null;
    const values = Object.values(profile.clarityAnswers);
    const total = values.reduce((a, b) => a + b, 0);
    return Math.round(total / (values.length * 5) * 100);
  }, [profile.clarityAnswers]);

  const setClarity = useCallback((answers: ClarityAnswers, relevance: UserProfile['careerRelevance']) => {
    setProfile((prev) => ({ ...prev, clarityAnswers: answers, careerRelevance: relevance }));
  }, []);

  const login = useCallback((name: string, email: string) => {
    setProfile((prev) => ({ ...prev, name, email, isGuest: false }));
  }, []);

  const loginAsGuest = useCallback(() => {
    setProfile((prev) => ({ ...prev, name: 'Guest', email: '', isGuest: true }));
  }, []);

  const logout = useCallback(() => {
    setProfile(emptyProfile);
    try {
      window.sessionStorage.removeItem(STORAGE_KEY);
    } catch {

      /* noop */}
  }, []);

  const resetAssessment = useCallback(() => {
    setProfile((prev) => ({
      ...prev,
      assessmentAnswers: {},
      assessmentComplete: false,
      features: null,
      recommendations: [],
      selectedCareer: null
    }));
  }, []);

  const value: UserContextValue = {
    profile,
    isAuthenticated: Boolean(profile.email) && !profile.isGuest,
    journey,
    questions,
    update,
    setAnswer,
    runRecommendation,
    discovery,
    skillProfile,
    skillRecommendations,
    skillGap,
    roadmap,
    roadmapPercent,
    toggleRoadmapStep,
    toggleSaved,
    isSaved,
    clarityScore,
    setClarity,
    login,
    loginAsGuest,
    logout,
    resetAssessment
  };

  return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
}

export function useUser() {
  const ctx = useContext(UserContext);
  if (!ctx) throw new Error('useUser must be used inside UserProvider');
  return ctx;
}