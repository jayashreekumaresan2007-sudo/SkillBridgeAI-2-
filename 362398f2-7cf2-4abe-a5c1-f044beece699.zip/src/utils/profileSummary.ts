import type { FeatureKey, FeatureVector } from '../types';

const INTEREST_KEYS: {key: FeatureKey;label: string;}[] = [
{ key: 'interest_technology', label: 'Technology & AI' },
{ key: 'interest_design', label: 'Design & Creativity' },
{ key: 'interest_business', label: 'Business & Management' },
{ key: 'interest_data', label: 'Data & Analytics' },
{ key: 'interest_science', label: 'Science & Research' },
{ key: 'interest_communication', label: 'Media & Communication' }];


const STRENGTH_KEYS: {key: FeatureKey;label: string;}[] = [
{ key: 'creativity_score', label: 'Creativity' },
{ key: 'analytical_score', label: 'Analytical thinking' },
{ key: 'communication_score', label: 'Communication' },
{ key: 'leadership_score', label: 'Leadership' },
{ key: 'problem_solving_score', label: 'Problem solving' },
{ key: 'technical_confidence', label: 'Technical confidence' },
{ key: 'teamwork_score', label: 'Teamwork' }];


export interface ScoredTrait {
  label: string;
  value: number;
}

function rank(features: FeatureVector, source: {key: FeatureKey;label: string;}[]): ScoredTrait[] {
  return source.
  map(({ key, label }) => ({ label, value: Math.round(features[key] * 100) })).
  sort((a, b) => b.value - a.value);
}

export function topInterests(features: FeatureVector, limit = 3): ScoredTrait[] {
  return rank(features, INTEREST_KEYS).filter((t) => t.value > 0).slice(0, limit);
}

export function strengths(features: FeatureVector, limit = 3): ScoredTrait[] {
  return rank(features, STRENGTH_KEYS).slice(0, limit);
}

export function skillConfidence(features: FeatureVector): ScoredTrait[] {
  return rank(features, STRENGTH_KEYS);
}