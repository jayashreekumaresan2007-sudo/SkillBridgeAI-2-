import { FEATURE_KEYS } from './features';
import { buildTrainingSet, CATEGORY_ORDER } from './trainingData';

/**
 * Multinomial logistic regression (softmax) trained in the browser with
 * full-batch gradient descent. Small, deterministic and fast enough to run on
 * app start. Swap this file for an API call to a trained model without changing
 * any screen: the service contract in ml/service.ts stays identical.
 */
export interface TrainedModel {
  weights: number[][]; // [class][feature]
  bias: number[];
  trainAccuracy: number;
  epochs: number;
  samples: number;
}

function softmax(logits: number[]): number[] {
  const max = Math.max(...logits);
  const exps = logits.map((l) => Math.exp(l - max));
  const sum = exps.reduce((a, b) => a + b, 0);
  return exps.map((e) => e / sum);
}

export function forward(model: TrainedModel, x: number[]): number[] {
  const logits = model.weights.map((row, c) => {
    let sum = model.bias[c];
    for (let f = 0; f < row.length; f += 1) sum += row[f] * x[f];
    return sum;
  });
  return softmax(logits);
}

export function trainModel(epochs = 260, learningRate = 0.55, l2 = 0.002): TrainedModel {
  const data = buildTrainingSet();
  const numFeatures = FEATURE_KEYS.length;
  const numClasses = CATEGORY_ORDER.length;

  const weights: number[][] = Array.from({ length: numClasses }, () => new Array(numFeatures).fill(0));
  const bias = new Array(numClasses).fill(0);
  const model: TrainedModel = { weights, bias, trainAccuracy: 0, epochs, samples: data.length };

  for (let epoch = 0; epoch < epochs; epoch += 1) {
    const gradW: number[][] = Array.from({ length: numClasses }, () => new Array(numFeatures).fill(0));
    const gradB = new Array(numClasses).fill(0);

    data.forEach(({ x, y }) => {
      const probs = forward(model, x);
      for (let c = 0; c < numClasses; c += 1) {
        const error = probs[c] - (c === y ? 1 : 0);
        gradB[c] += error;
        for (let f = 0; f < numFeatures; f += 1) {
          gradW[c][f] += error * x[f];
        }
      }
    });

    const scale = learningRate / data.length;
    for (let c = 0; c < numClasses; c += 1) {
      bias[c] -= scale * gradB[c];
      for (let f = 0; f < numFeatures; f += 1) {
        weights[c][f] -= scale * (gradW[c][f] + l2 * weights[c][f]);
      }
    }
  }

  let correct = 0;
  data.forEach(({ x, y }) => {
    const probs = forward(model, x);
    const predicted = probs.indexOf(Math.max(...probs));
    if (predicted === y) correct += 1;
  });
  model.trainAccuracy = correct / data.length;

  return model;
}

let cached: TrainedModel | null = null;

export function getModel(): TrainedModel {
  if (!cached) cached = trainModel();
  return cached;
}