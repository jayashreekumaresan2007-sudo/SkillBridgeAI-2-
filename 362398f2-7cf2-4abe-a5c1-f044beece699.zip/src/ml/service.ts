import type { CareerCategoryId, CareerRecommendation, FeatureVector } from '../types';
import { FEATURE_KEYS, FEATURE_LABELS, toVector } from './features';
import { forward, getModel } from './model';
import { CATEGORY_ORDER } from './trainingData';

/**
 * Recommendation service boundary.
 * Screens only ever call `recommendCareers`. The current implementation runs the
 * in-browser softmax model (ml/model.ts) trained on the clearly-labelled DEMO
 * dataset. A production build can replace the body with a network call to a
 * trained model service — the return shape must stay the same.
 */
export const MODEL_MODE = 'On-device demo model';

export function recommendCareers(features: FeatureVector, limit = 5): CareerRecommendation[] {
  const model = getModel();
  const x = toVector(features);
  const probs = forward(model, x);

  const ranked = CATEGORY_ORDER.map((careerId, index) => ({
    careerId,
    score: probs[index],
    index
  })).sort((a, b) => b.score - a.score);

  const top = ranked.slice(0, limit);
  const best = top[0]?.score ?? 1;

  return top.map(({ careerId, score, index }) => {
    // Present the raw probability on a readable 0-100 scale, anchored on the
    // strongest class so the leader reads as a match rather than a raw softmax.
    const relative = best > 0 ? score / best : 0;
    const match = Math.round(Math.min(96, Math.max(41, 46 + relative * 48)));
    return {
      careerId: careerId as CareerCategoryId,
      score,
      match,
      confidence: score > 0.3 ? 'High' : score > 0.16 ? 'Moderate' : 'Emerging',
      reasons: explain(model.weights[index], features)
    };
  });
}

/** Top positive contributions of this profile to the predicted class. */
function explain(weights: number[], features: FeatureVector): string[] {
  return FEATURE_KEYS.map((key, i) => ({
    key,
    contribution: weights[i] * features[key]
  })).
  filter((c) => c.contribution > 0).
  sort((a, b) => b.contribution - a.contribution).
  slice(0, 4).
  map((c) => `Strong ${FEATURE_LABELS[c.key]} in your responses`);
}

export function modelSummary() {
  const model = getModel();
  return {
    mode: MODEL_MODE,
    accuracy: Math.round(model.trainAccuracy * 100),
    samples: model.samples,
    features: FEATURE_KEYS.length,
    classes: CATEGORY_ORDER.length
  };
}