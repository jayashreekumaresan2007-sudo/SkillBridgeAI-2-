import type {
  FeatureKey,
  FeatureVector,
  SkillAdviceKind,
  SkillLevel,
  SkillProfileItem,
  SkillRecommendation } from
'../types';
import { FEATURE_LABELS } from './features';
import { rankRoles } from './discovery';

/**
 * SKILL ANALYSIS LAYER (skill journey)
 *
 * The skill journey does not recommend a career — it reads the same feature
 * vector as a skill profile, then works out which skills to strengthen,
 * improve, learn, add as complements, or watch as emerging. Every item is
 * derived from the user's own answers, so two profiles never produce the same
 * list.
 */

interface Dimension {
  id: string;
  name: string;
  feature: FeatureKey;
  note: string;
}

const D: Record<string, Dimension> = {
  communication: { id: 'communication', name: 'Communication', feature: 'communication_score', note: 'Explaining your thinking so others can act on it.' },
  problem: { id: 'problem', name: 'Problem solving', feature: 'problem_solving_score', note: 'Breaking an unclear problem into steps you can attack.' },
  creativity: { id: 'creativity', name: 'Creativity', feature: 'creativity_score', note: 'Generating options instead of settling on the first idea.' },
  analytical: { id: 'analytical', name: 'Analytical thinking', feature: 'analytical_score', note: 'Reasoning from evidence and numbers rather than instinct.' },
  leadership: { id: 'leadership', name: 'Leadership', feature: 'leadership_score', note: 'Setting direction and carrying other people with you.' },
  teamwork: { id: 'teamwork', name: 'Teamwork', feature: 'teamwork_score', note: 'Producing good work with people you did not choose.' },
  technical: { id: 'technical', name: 'Technical confidence', feature: 'technical_confidence', note: 'Picking up unfamiliar tools without waiting for help.' },
  research: { id: 'research', name: 'Research ability', feature: 'research_preference', note: 'Finding, judging and using reliable sources.' },
  digital: { id: 'digital', name: 'Digital & building skills', feature: 'coding_preference', note: 'Making working things — scripts, apps, automations.' },
  design: { id: 'design', name: 'Design thinking', feature: 'design_preference', note: 'Shaping something around the person who will use it.' },
  business: { id: 'business', name: 'Commercial thinking', feature: 'business_orientation', note: 'Connecting the work to cost, value and priorities.' },
  people: { id: 'people', name: 'Working with people', feature: 'people_orientation', note: 'Reading needs and building working relationships.' }
};

/** The skill dimensions differ by category — a school student is not assessed on commercial thinking. */
export const SKILL_DIMENSIONS: Record<string, Dimension[]> = {
  school: [D.communication, D.problem, D.creativity, D.teamwork, D.research, D.technical, D.analytical, D.leadership],
  college: [D.digital, D.analytical, D.design, D.technical, D.communication, D.teamwork, D.research, D.leadership],
  graduate: [D.analytical, D.technical, D.digital, D.communication, D.problem, D.research, D.teamwork, D.leadership],
  working: [D.technical, D.analytical, D.business, D.communication, D.leadership, D.problem, D.digital, D.people],
  switcher: [D.communication, D.analytical, D.technical, D.people, D.digital, D.design, D.research, D.leadership],
  other: [D.communication, D.problem, D.analytical, D.creativity, D.technical, D.teamwork, D.research, D.leadership]
};

export function levelFor(value: number): SkillLevel {
  if (value >= 0.62) return 'Strong';
  if (value >= 0.34) return 'Developing';
  return 'Needs Improvement';
}

export function buildSkillProfile(features: FeatureVector | null, category: string): SkillProfileItem[] {
  if (!features) return [];
  const dimensions = SKILL_DIMENSIONS[category] ?? SKILL_DIMENSIONS.other;
  return dimensions.
  map((dimension) => ({
    id: dimension.id,
    name: dimension.name,
    feature: dimension.feature,
    note: dimension.note,
    value: features[dimension.feature],
    level: levelFor(features[dimension.feature])
  })).
  sort((a, b) => b.value - a.value);
}

/** Maps the shared skill vocabulary onto the closest feature proxy. */
const SKILL_FEATURE: Record<string, FeatureKey> = {
  Python: 'coding_preference',
  Programming: 'coding_preference',
  Scripting: 'coding_preference',
  'Machine Learning': 'technical_confidence',
  Databases: 'technical_confidence',
  'Networking & Systems': 'technical_confidence',
  'Linux & Scripting': 'technical_confidence',
  'Technical Confidence': 'technical_confidence',
  Statistics: 'analytical_score',
  SQL: 'analytical_score',
  Analytics: 'analytical_score',
  'Analytical Thinking': 'analytical_score',
  'Systems Thinking': 'analytical_score',
  'Spreadsheets & Tools': 'analytical_score',
  'Data Visualisation': 'interest_data',
  Figma: 'design_preference',
  'Visual & Interaction Design': 'design_preference',
  'User Research': 'research_preference',
  'Research Methods': 'research_preference',
  'Empathy for Users': 'people_orientation',
  Creativity: 'creativity_score',
  Communication: 'communication_score',
  'Written Communication': 'communication_score',
  'Problem Solving': 'problem_solving_score',
  Leadership: 'leadership_score',
  'Business Thinking': 'business_orientation'
};

export function featureForSkill(name: string): FeatureKey {
  return SKILL_FEATURE[name] ?? 'problem_solving_score';
}

function reasonFor(kind: SkillAdviceKind, skill: string, feature: FeatureKey, roleTitle: string) {
  const label = FEATURE_LABELS[feature];
  switch (kind) {
    case 'strengthen':
      return `Your ${label} already reads as a strength — ${skill} is where it converts into visible work for ${roleTitle}.`;
    case 'improve':
      return `You show partial ${label}. ${skill} is the next step that moves it from workable to reliable.`;
    case 'learn':
      return `${roleTitle} depends on ${skill}, and your answers show limited ${label} so far. Start here.`;
    case 'complementary':
      return `${skill} pairs with what you are already good at and widens the roles open to you.`;
    default:
      return `${skill} is growing in demand in ${roleTitle} work and fits the profile your answers describe.`;
  }
}

/**
 * Ranks the skills worth acting on, using the roles this profile matches.
 * Returns strengthen / improve / learn first, then complementary and emerging.
 */
export function recommendSkills(features: FeatureVector | null, limit = 8): SkillRecommendation[] {
  if (!features) return [];

  const ranked = rankRoles(features);
  const primary = ranked.slice(0, 3);
  const emerging = ranked.filter((role) => role.kind === 'emerging').slice(0, 2);
  const wider = ranked.filter((role) => role.kind === 'hidden' || role.kind === 'adjacent').slice(0, 2);

  const seen = new Set<string>();
  const out: SkillRecommendation[] = [];

  const push = (skill: string, kind: SkillAdviceKind, roleTitle: string, careerId: SkillRecommendation['careerId']) => {
    if (seen.has(skill)) return;
    seen.add(skill);
    const feature = featureForSkill(skill);
    const value = features[feature];
    const resolved: SkillAdviceKind =
    kind === 'complementary' || kind === 'emerging' ?
    kind :
    value >= 0.62 ?
    'strengthen' :
    value >= 0.34 ?
    'improve' :
    'learn';
    out.push({
      id: `${skill}-${roleTitle}`.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      name: skill,
      kind: resolved,
      reason: reasonFor(resolved, skill, feature, roleTitle),
      careerId,
      roleTitle,
      value
    });
  };

  primary.forEach((role) => role.skills.forEach((skill) => push(skill, 'improve', role.title, role.careerId)));
  wider.forEach((role) => role.skills.forEach((skill) => push(skill, 'complementary', role.title, role.careerId)));
  emerging.forEach((role) => role.skills.forEach((skill) => push(skill, 'emerging', role.title, role.careerId)));

  const order: Record<SkillAdviceKind, number> = {
    learn: 0,
    improve: 1,
    strengthen: 2,
    complementary: 3,
    emerging: 4
  };

  return out.sort((a, b) => order[a.kind] - order[b.kind] || a.value - b.value).slice(0, limit);
}

export const SKILL_ADVICE_LABEL: Record<SkillAdviceKind, string> = {
  strengthen: 'Strength to convert',
  improve: 'Improve next',
  learn: 'Priority to learn',
  complementary: 'Complementary',
  emerging: 'Emerging & high value'
};