import type {
  CareerCategoryId,
  FeatureKey,
  FeatureVector,
  Role,
  RoleDiscovery,
  RoleRecommendation } from
'../types';
import { ROLES } from '../data/roles';
import { FEATURE_LABELS } from './features';
import { recommendCareers } from './service';

/**
 * ROLE DISCOVERY LAYER
 *
 * Stage 1 — the model ranks the ten career categories (ml/service.ts).
 * Stage 2 — every role inside those categories is re-scored against the user's
 *           own feature vector, so two people matched to the same category can
 *           still surface different roles.
 * Stage 3 — roles are bucketed into best-fit / alternative / adjacent / hidden /
 *           emerging so the result screen can disclose them progressively.
 *
 * Swapping in a hosted model only means replacing `recommendCareers`; this
 * layer keeps working from whatever category distribution it returns.
 */

const CATEGORY_WEIGHT = 0.6;
const AFFINITY_WEIGHT = 0.4;

function affinityFit(role: Role, features: FeatureVector) {
  const entries = Object.entries(role.affinity) as [FeatureKey, number][];
  const totalWeight = entries.reduce((sum, [, weight]) => sum + weight, 0);
  if (!totalWeight) return 0;
  const score = entries.reduce((sum, [key, weight]) => sum + features[key] * weight, 0);
  return score / totalWeight;
}

function explainRole(role: Role, features: FeatureVector): string[] {
  const entries = Object.entries(role.affinity) as [FeatureKey, number][];
  return entries.
  map(([key, weight]) => ({ key, contribution: features[key] * weight, value: features[key] })).
  filter((entry) => entry.contribution > 0.05).
  sort((a, b) => b.contribution - a.contribution).
  slice(0, 4).
  map((entry) => {
    const label = FEATURE_LABELS[entry.key];
    if (entry.value >= 0.66) return `Your ${label} came through strongly`;
    if (entry.value >= 0.4) return `You show steady ${label}`;
    return `Some signal of ${label} in your answers`;
  });
}

function confidenceFor(match: number): RoleRecommendation['confidence'] {
  if (match >= 78) return 'High';
  if (match >= 62) return 'Moderate';
  return 'Emerging';
}

export interface RankedRole extends RoleRecommendation {
  score: number;
}

/** Every role, ranked for this profile. */
export function rankRoles(features: FeatureVector): RankedRole[] {
  const categoryScores = new Map<CareerCategoryId, number>();
  const ranking = recommendCareers(features, 10);
  const best = ranking[0]?.score ?? 1;
  ranking.forEach((item) => categoryScores.set(item.careerId, best > 0 ? item.score / best : 0));

  return ROLES.map((role) => {
    const category = categoryScores.get(role.careerId) ?? 0;
    const fit = affinityFit(role, features);
    const score = CATEGORY_WEIGHT * category + AFFINITY_WEIGHT * fit;
    const match = Math.round(Math.min(95, Math.max(45, 45 + score * 52)));
    return {
      roleId: role.id,
      title: role.title,
      careerId: role.careerId,
      kind: role.kind,
      summary: role.summary,
      skills: role.skills,
      why: explainRole(role, features),
      match,
      confidence: confidenceFor(match),
      score
    };
  }).sort((a, b) => b.score - a.score);
}

/**
 * Buckets the ranked roles into the five discovery slots shown on the results
 * screen. Hidden and emerging roles are surfaced deliberately — they are the
 * options most users would never search for themselves.
 */
export function discoverRoles(features: FeatureVector | null): RoleDiscovery {
  if (!features) {
    return { bestFit: null, alternative: null, adjacent: null, hidden: null, emerging: null };
  }

  const ranked = rankRoles(features);
  const used = new Set<string>();

  const take = (predicate: (role: RankedRole) => boolean): RoleRecommendation | null => {
    const found = ranked.find((role) => !used.has(role.roleId) && predicate(role));
    if (!found) return null;
    used.add(found.roleId);
    const { score: _score, ...recommendation } = found;
    return recommendation;
  };

  const bestFit = take(() => true);
  const alternative = take((role) => role.careerId !== bestFit?.careerId);
  const adjacent = take((role) => role.kind === 'adjacent');
  const hidden = take((role) => role.kind === 'hidden');
  const emerging = take((role) => role.kind === 'emerging');

  return { bestFit, alternative, adjacent, hidden, emerging };
}