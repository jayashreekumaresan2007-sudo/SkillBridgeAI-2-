import type { CareerCategoryId, FeatureVector, RoadmapStep, SkillGapItem, SkillLevel } from '../types';
import { CAREERS } from '../data/careers';

function levelFor(value: number): SkillLevel {
  if (value >= 0.62) return 'Strong';
  if (value >= 0.34) return 'Developing';
  return 'Needs Improvement';
}

/** ML recommended career → required skills → compared against the user profile. */
export function buildSkillGap(careerId: CareerCategoryId, features: FeatureVector | null): SkillGapItem[] {
  const career = CAREERS[careerId];
  return career.requiredSkills.
  map((skill) => {
    const value = features ? features[skill.source] : 0;
    return {
      name: skill.name,
      level: levelFor(value),
      value: Math.round(value * 100),
      weight: skill.weight
    };
  }).
  sort((a, b) => a.value - b.value);
}

/** Roadmap is generated from the gap: weakest, highest-weight skills come first. */
export function buildRoadmap(careerId: CareerCategoryId, gap: SkillGapItem[]): RoadmapStep[] {
  const career = CAREERS[careerId];
  const ordered = [...gap].sort((a, b) => a.value * (1 - a.weight * 0.4) - b.value * (1 - b.weight * 0.4));
  const focus = ordered.slice(0, 3).map((g) => g.name);
  const strengths = [...gap].sort((a, b) => b.value - a.value).slice(0, 2).map((g) => g.name);

  return [
  {
    id: 'step-1',
    title: 'Step 1 — Fundamentals',
    goal: `Build the base every ${career.title} needs.`,
    skills: [career.learningPath[0], focus[0]].filter(Boolean) as string[],
    activity: 'Complete one structured beginner course and take notes you can revisit.'
  },
  {
    id: 'step-2',
    title: 'Step 2 — Core skills',
    goal: `Close your biggest gap: ${focus[0] ?? career.technicalSkills[0]}.`,
    skills: [career.learningPath[1], focus[1]].filter(Boolean) as string[],
    activity: 'Practise weekly with small exercises until it feels routine.'
  },
  {
    id: 'step-3',
    title: 'Step 3 — Advanced skills',
    goal: `Go deeper into ${career.learningPath[2] ?? career.technicalSkills[1]}.`,
    skills: [career.learningPath[2], focus[2]].filter(Boolean) as string[],
    activity: 'Follow one advanced tutorial end to end and rebuild it from scratch.'
  },
  {
    id: 'step-4',
    title: 'Step 4 — Mini project',
    goal: 'Apply what you learned to a small, finished piece of work.',
    skills: career.technicalSkills.slice(0, 2),
    activity: `Build a small ${career.family.toLowerCase()} project and document your decisions.`
  },
  {
    id: 'step-5',
    title: 'Step 5 — Portfolio',
    goal: `Show your work in a way a recruiter understands, leaning on your strengths (${strengths.join(', ')}).`,
    skills: ['Documentation', 'Presentation'],
    activity: 'Publish two case studies explaining the problem, your approach and the result.'
  },
  {
    id: 'step-6',
    title: 'Step 6 — Career preparation',
    goal: `Get ready to apply for roles such as ${career.entryRoles[0]}.`,
    skills: ['Interview practice', 'Resume'],
    activity: 'Do three mock interviews and refine your resume around your projects.'
  }];

}