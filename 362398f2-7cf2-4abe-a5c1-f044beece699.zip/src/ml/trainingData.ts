import type { CareerCategoryId, FeatureKey } from '../types';
import { FEATURE_KEYS } from './features';

/**
 * DEMO / TRAINING DATA — SYNTHETIC.
 * These profiles are hand-authored archetypes used only to demonstrate the
 * pipeline. They are NOT real student data. Replace `PROFILE_ARCHETYPES` (or the
 * whole generator) with a real labelled dataset without touching the model code.
 */
export const DATASET_LABEL = 'DEMO dataset · synthetic profiles';

type Archetype = Partial<Record<FeatureKey, number>>;

export const PROFILE_ARCHETYPES: Record<CareerCategoryId, Archetype> = {
  ai_ml: {
    interest_technology: 0.9,
    interest_data: 0.85,
    interest_science: 0.6,
    analytical_score: 0.9,
    problem_solving_score: 0.85,
    technical_confidence: 0.85,
    coding_preference: 0.9,
    research_preference: 0.6,
    creativity_score: 0.45
  },
  software: {
    interest_technology: 0.9,
    analytical_score: 0.7,
    problem_solving_score: 0.85,
    technical_confidence: 0.85,
    coding_preference: 0.95,
    teamwork_score: 0.6,
    creativity_score: 0.5,
    interest_data: 0.4
  },
  data: {
    interest_data: 0.95,
    interest_business: 0.55,
    analytical_score: 0.9,
    communication_score: 0.65,
    technical_confidence: 0.6,
    coding_preference: 0.5,
    problem_solving_score: 0.65,
    business_orientation: 0.5
  },
  cybersecurity: {
    interest_technology: 0.85,
    analytical_score: 0.8,
    problem_solving_score: 0.85,
    technical_confidence: 0.9,
    coding_preference: 0.65,
    research_preference: 0.55,
    teamwork_score: 0.45
  },
  uiux: {
    interest_design: 0.95,
    creativity_score: 0.9,
    design_preference: 0.95,
    people_orientation: 0.7,
    communication_score: 0.7,
    research_preference: 0.6,
    technical_confidence: 0.4
  },
  business: {
    interest_business: 0.9,
    leadership_score: 0.9,
    communication_score: 0.85,
    business_orientation: 0.9,
    teamwork_score: 0.8,
    analytical_score: 0.6,
    people_orientation: 0.7
  },
  marketing: {
    interest_communication: 0.9,
    interest_business: 0.65,
    creativity_score: 0.8,
    communication_score: 0.9,
    people_orientation: 0.8,
    business_orientation: 0.6,
    analytical_score: 0.5,
    design_preference: 0.5
  },
  research: {
    interest_science: 0.95,
    research_preference: 0.95,
    analytical_score: 0.85,
    problem_solving_score: 0.7,
    communication_score: 0.55,
    technical_confidence: 0.5,
    interest_data: 0.55
  },
  cloud: {
    interest_technology: 0.9,
    technical_confidence: 0.9,
    coding_preference: 0.8,
    problem_solving_score: 0.85,
    analytical_score: 0.7,
    teamwork_score: 0.6,
    interest_data: 0.4
  },
  product: {
    interest_business: 0.75,
    interest_communication: 0.7,
    leadership_score: 0.8,
    communication_score: 0.9,
    people_orientation: 0.85,
    analytical_score: 0.75,
    business_orientation: 0.8,
    design_preference: 0.5,
    teamwork_score: 0.8
  }
};

export const CATEGORY_ORDER = Object.keys(PROFILE_ARCHETYPES) as CareerCategoryId[];

/** Deterministic pseudo-random generator so training is reproducible. */
function createRandom(seed: number) {
  let state = seed;
  return () => {
    state = (state * 1664525 + 1013904223) % 4294967296;
    return state / 4294967296;
  };
}

export interface TrainingSample {
  x: number[];
  y: number;
}

/** Generates the synthetic training set by adding noise around each archetype. */
export function buildTrainingSet(samplesPerClass = 26): TrainingSample[] {
  const random = createRandom(20260819);
  const samples: TrainingSample[] = [];

  CATEGORY_ORDER.forEach((category, classIndex) => {
    const archetype = PROFILE_ARCHETYPES[category];
    for (let i = 0; i < samplesPerClass; i += 1) {
      const x = FEATURE_KEYS.map((key) => {
        const base = archetype[key] ?? 0.12;
        const noise = (random() - 0.5) * 0.42;
        return Math.min(1, Math.max(0, base + noise));
      });
      samples.push({ x, y: classIndex });
    }
  });

  return samples;
}