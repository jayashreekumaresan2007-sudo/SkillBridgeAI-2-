import type { AnswerValue, FeatureKey, FeatureVector } from '../types';
import { QUESTION_INDEX } from '../data/assessment';

export const FEATURE_KEYS: FeatureKey[] = [
'interest_technology',
'interest_design',
'interest_business',
'interest_data',
'interest_science',
'interest_communication',
'creativity_score',
'analytical_score',
'communication_score',
'leadership_score',
'problem_solving_score',
'technical_confidence',
'teamwork_score',
'coding_preference',
'design_preference',
'research_preference',
'people_orientation',
'business_orientation'];


export const FEATURE_LABELS: Record<FeatureKey, string> = {
  interest_technology: 'interest in technology',
  interest_design: 'interest in design',
  interest_business: 'interest in business',
  interest_data: 'interest in data',
  interest_science: 'interest in science',
  interest_communication: 'interest in communication',
  creativity_score: 'creativity',
  analytical_score: 'analytical thinking',
  communication_score: 'communication',
  leadership_score: 'leadership',
  problem_solving_score: 'problem solving',
  technical_confidence: 'technical confidence',
  teamwork_score: 'teamwork',
  coding_preference: 'preference for building and coding',
  design_preference: 'preference for designing',
  research_preference: 'preference for research',
  people_orientation: 'people orientation',
  business_orientation: 'business orientation'
};

export function emptyFeatures(): FeatureVector {
  return FEATURE_KEYS.reduce((acc, key) => {
    acc[key] = 0;
    return acc;
  }, {} as FeatureVector);
}

const clamp = (n: number, min = 0, max = 1) => Math.min(max, Math.max(min, n));

/**
 * FEATURE EXTRACTION + NORMALISATION
 * Converts raw assessment answers into the normalised 0-1 feature vector that
 * the model consumes. Answers are additive; self-ratings are scaled to 0-1.5.
 */
export function extractFeatures(answers: Record<string, AnswerValue>): FeatureVector {
  const raw = emptyFeatures();

  // Driven by the answers themselves, so any journey's question set works.
  Object.keys(answers).forEach((questionId) => {
    const question = QUESTION_INDEX[questionId];
    const answer = answers[questionId];
    if (!question || !answer) return;

    if (question.type === 'rating' && question.items && !Array.isArray(answer)) {
      const ratings = answer as Record<string, number>;
      question.items.forEach((item) => {
        const value = ratings[item.id];
        if (typeof value === 'number') {
          raw[item.feature] += (value - 1) / 4 * 1.5;
        }
      });
      return;
    }

    if (Array.isArray(answer) && question.options) {
      answer.forEach((optionId) => {
        const option = question.options?.find((o) => o.id === optionId);
        if (!option) return;
        Object.entries(option.weights).forEach(([key, weight]) => {
          raw[key as FeatureKey] += weight as number;
        });
      });
    }
  });

  // Normalisation: scale into 0-1 so every feature is comparable to the model.
  const normalised = emptyFeatures();
  FEATURE_KEYS.forEach((key) => {
    normalised[key] = clamp(raw[key] / 2.2);
  });
  return normalised;
}

export function toVector(features: FeatureVector): number[] {
  return FEATURE_KEYS.map((key) => features[key]);
}