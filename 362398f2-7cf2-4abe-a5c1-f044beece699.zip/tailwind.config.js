/** @type {import('tailwindcss').Config} */
export default {
  content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      colors: {
        brand: {
          50: '#EEF3FF',
          100: '#DCE6FF',
          200: '#BACCFF',
          300: '#8FAAFF',
          400: '#5B82FA',
          500: '#2F5DE8',
          600: '#1E48CC',
          700: '#1838A0',
          800: '#152C78',
          900: '#101F52',
        },
        navy: {
          DEFAULT: '#0E1B3D',
          soft: '#1B2C57',
          muted: '#5A6684',
        },
        canvas: '#F5F7FC',
        surface: '#FFFFFF',
        hairline: '#E4E9F2',
        good: '#1B8A5A',
        goodSoft: '#E7F5EE',
        warn: '#B7791F',
        warnSoft: '#FBF3E2',
        bad: '#C3392C',
        badSoft: '#FBEAE8',
      },
      borderRadius: {
        xl: '14px',
        '2xl': '18px',
        '3xl': '24px',
      },
      boxShadow: {
        card: '0 1px 2px rgba(14,27,61,0.04), 0 8px 24px -12px rgba(14,27,61,0.12)',
        lift: '0 2px 6px rgba(14,27,61,0.06), 0 18px 40px -18px rgba(14,27,61,0.28)',
      },
    },
  },
  plugins: [],
}
