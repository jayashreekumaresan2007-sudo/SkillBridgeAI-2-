import { useState, useCallback, useEffect } from "react";
import type { Screen, AppState, AssessmentAnswers, UserProfile } from "./types";
import { runMLRecommendation, computeSkillGap } from "./engine";
import { CAREERS } from "./data";

import { SplashScreen, WalkthroughScreen } from "./screens/Onboarding";
import { LoginScreen, RegisterScreen, ForgotPasswordScreen } from "./screens/Auth";
import {
  LanguageCategoryScreen, GenderSelectScreen, AvatarSelectScreen,
  PathSelectScreen, AssessmentIntroScreen,
} from "./screens/Setup";
import { AssessmentScreen, AssessmentCompleteScreen } from "./screens/Assessment";
import { CareerResultsScreen, CareerDetailScreen, SkillGapScreen, RoadmapScreen } from "./screens/Results";
import { InstitutionsScreen, AcademiesScreen } from "./screens/Discovery";
import { ClarityCheckScreen } from "./screens/ClarityCheck";
import { DashboardScreen, ProfileScreen } from "./screens/Dashboard";

const DEFAULT_ANSWERS: AssessmentAnswers = {
  interests: [],
  activity: "",
  projectType: "",
  scenario: "",
  goal: "",
  ratings: {
    communication: 3,
    problemSolving: 3,
    creativity: 3,
    leadership: 3,
    analytical: 3,
    technical: 3,
    teamwork: 3,
  },
};

const DEFAULT_STATE: AppState = {
  screen: "splash",
  screenHistory: [],
  isDark: false,
  language: "English",
  user: null,
  assessmentAnswers: DEFAULT_ANSWERS,
  assessmentCurrentQ: 0,
  careerRecommendations: [],
  selectedCareerId: "",
  skillGaps: [],
  roadmapProgress: [],
  savedCareers: [],
  savedInstitutions: [],
  savedAcademies: [],
  clarityAnswers: [],
  clarityScore: 0,
  streak: 7,
  dailyProgress: 0,
};

export default function App() {
  const [state, setState] = useState<AppState>(DEFAULT_STATE);

  // Persist dark mode preference
  useEffect(() => {
    if (state.isDark) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [state.isDark]);

  const navigate = useCallback((screen: Screen) => {
    setState((prev) => ({
      ...prev,
      screen,
      screenHistory: [...prev.screenHistory, prev.screen],
    }));
  }, []);

  const goBack = useCallback(() => {
    setState((prev) => {
      const history = [...prev.screenHistory];
      const prevScreen = history.pop() ?? "splash";
      return { ...prev, screen: prevScreen, screenHistory: history };
    });
  }, []);

  const update = useCallback((updates: Partial<AppState>) => {
    setState((prev) => ({ ...prev, ...updates }));
  }, []);

  const toggleDark = useCallback(() => {
    setState((prev) => ({ ...prev, isDark: !prev.isDark }));
  }, []);

  const toggleSaveCareer = (id: string) => {
    setState((prev) => ({
      ...prev,
      savedCareers: prev.savedCareers.includes(id)
        ? prev.savedCareers.filter((x) => x !== id)
        : [...prev.savedCareers, id],
    }));
  };

  const toggleSaveInstitution = (id: string) => {
    setState((prev) => ({
      ...prev,
      savedInstitutions: prev.savedInstitutions.includes(id)
        ? prev.savedInstitutions.filter((x) => x !== id)
        : [...prev.savedInstitutions, id],
    }));
  };

  const toggleSaveAcademy = (id: string) => {
    setState((prev) => ({
      ...prev,
      savedAcademies: prev.savedAcademies.includes(id)
        ? prev.savedAcademies.filter((x) => x !== id)
        : [...prev.savedAcademies, id],
    }));
  };

  const handleLogin = (email: string, isGuest = false) => {
    const name = email.includes("@") ? email.split("@")[0].replace(/[^a-zA-Z ]/g, " ") : "Explorer";
    const user: UserProfile = {
      name: name.charAt(0).toUpperCase() + name.slice(1),
      email,
      language: "English",
      userCategory: "",
      gender: "",
      avatar: 0,
      path: "",
      isGuest,
    };
    update({ user });
    navigate("languageCategory");
  };

  const handleRegister = (name: string, email: string) => {
    const user: UserProfile = {
      name,
      email,
      language: "English",
      userCategory: "",
      gender: "",
      avatar: 0,
      path: "",
      isGuest: false,
    };
    update({ user });
    navigate("languageCategory");
  };

  const handleAssessmentComplete = (answers: AssessmentAnswers) => {
    const recs = runMLRecommendation(answers);
    const topCareerId = recs[0]?.id ?? "ai-ml";
    const gaps = computeSkillGap(topCareerId, answers);
    const career = CAREERS.find((c) => c.id === topCareerId);
    const roadmapProgress = Array(career?.roadmap.length ?? 6).fill(false);

    update({
      assessmentAnswers: answers,
      careerRecommendations: recs,
      selectedCareerId: topCareerId,
      skillGaps: gaps,
      roadmapProgress,
    });
    navigate("assessmentComplete");
  };

  const handleSelectCareer = (careerId: string) => {
    const gaps = computeSkillGap(careerId, state.assessmentAnswers);
    const career = CAREERS.find((c) => c.id === careerId);
    const roadmapProgress = Array(career?.roadmap.length ?? 6).fill(false);

    update({ selectedCareerId: careerId, skillGaps: gaps, roadmapProgress });
    navigate("careerDetail");
  };

  const handleToggleRoadmapStep = (i: number) => {
    setState((prev) => {
      const next = [...prev.roadmapProgress];
      next[i] = !next[i];
      return { ...prev, roadmapProgress: next };
    });
  };

  const handleClarityComplete = (score: number, answers: number[]) => {
    update({ clarityScore: score, clarityAnswers: answers });
    navigate("dashboard");
  };

  const { screen, isDark, language, user, assessmentAnswers, assessmentCurrentQ, careerRecommendations,
    selectedCareerId, skillGaps, roadmapProgress, savedCareers, savedInstitutions, savedAcademies,
    clarityScore, streak, dailyProgress } = state;

  const matchScore = careerRecommendations.find((r) => r.id === selectedCareerId)?.matchScore ?? 85;
  const assessmentDone = careerRecommendations.length > 0;

  // Guest mode shortcuts
  const handleGuest = () => {
    const guestUser: UserProfile = {
      name: "Guest",
      email: "guest@skillbridge.ai",
      language: "English",
      userCategory: "other",
      gender: "male",
      avatar: 0,
      path: "career",
      isGuest: true,
    };
    // Provide default answers so guest can see demo recommendations
    const demoAnswers: AssessmentAnswers = {
      interests: ["technology", "data"],
      activity: "coding",
      projectType: "app",
      scenario: "prototype",
      goal: "product",
      ratings: { communication: 3, problemSolving: 4, creativity: 3, leadership: 2, analytical: 4, technical: 4, teamwork: 3 },
    };
    const recs = runMLRecommendation(demoAnswers);
    const topCareerId = recs[0]?.id ?? "ai-ml";
    const gaps = computeSkillGap(topCareerId, demoAnswers);
    const career = CAREERS.find((c) => c.id === topCareerId);
    const prog = Array(career?.roadmap.length ?? 6).fill(false);

    setState((prev) => ({
      ...prev,
      user: guestUser,
      assessmentAnswers: demoAnswers,
      careerRecommendations: recs,
      selectedCareerId: topCareerId,
      skillGaps: gaps,
      roadmapProgress: prog,
      screen: "dashboard",
      screenHistory: [...prev.screenHistory, prev.screen],
    }));
  };

  // ── Render ──────────────────────────────────────────────────────
  const containerStyle: React.CSSProperties = {
    minHeight: "100dvh",
    background: isDark ? "#0A0F1E" : "#E2E8F0",
    display: "flex",
    alignItems: "flex-start",
    justifyContent: "center",
  };

  const phoneStyle: React.CSSProperties = {
    width: "100%",
    maxWidth: 430,
    minHeight: "100dvh",
    display: "flex",
    flexDirection: "column",
    background: isDark ? "#111827" : "#ffffff",
    position: "relative",
    overflowX: "hidden",
  };

  return (
    <div style={containerStyle}>
      <div style={phoneStyle}>
        {screen === "splash" && (
          <SplashScreen onDone={() => navigate("walkthrough")} />
        )}

        {screen === "walkthrough" && (
          <WalkthroughScreen onGetStarted={() => navigate("login")} isDark={isDark} />
        )}

        {screen === "login" && (
          <LoginScreen
            onLogin={handleLogin}
            onGuest={handleGuest}
            onRegister={() => navigate("register")}
            onForgot={() => navigate("forgotPassword")}
            isDark={isDark}
          />
        )}

        {screen === "register" && (
          <RegisterScreen
            onRegister={handleRegister}
            onLogin={() => navigate("login")}
            isDark={isDark}
          />
        )}

        {screen === "forgotPassword" && (
          <ForgotPasswordScreen onBack={() => navigate("login")} isDark={isDark} />
        )}

        {screen === "languageCategory" && (
          <LanguageCategoryScreen
            isDark={isDark}
            onNext={(data) => {
              setState((prev) => ({
                ...prev,
                user: prev.user ? { ...prev.user, language: data.language, userCategory: data.category } : null,
                language: data.language,
                screen: "genderSelect",
                screenHistory: [...prev.screenHistory, prev.screen],
              }));
            }}
            onBack={goBack}
          />
        )}

        {screen === "genderSelect" && (
          <GenderSelectScreen
            isDark={isDark}
            onNext={(data) => {
              setState((prev) => ({
                ...prev,
                user: prev.user ? { ...prev.user, gender: data.gender } : null,
                screen: "avatarSelect",
                screenHistory: [...prev.screenHistory, prev.screen],
              }));
            }}
            onBack={goBack}
          />
        )}

        {screen === "avatarSelect" && (
          <AvatarSelectScreen
            isDark={isDark}
            gender={user?.gender ?? "male"}
            onNext={(data) => {
              setState((prev) => ({
                ...prev,
                user: prev.user ? { ...prev.user, avatar: data.avatar } : null,
                screen: "pathSelect",
                screenHistory: [...prev.screenHistory, prev.screen],
              }));
            }}
            onBack={goBack}
          />
        )}

        {screen === "pathSelect" && (
          <PathSelectScreen
            isDark={isDark}
            onNext={(data) => {
              setState((prev) => ({
                ...prev,
                user: prev.user ? { ...prev.user, path: data.path } : null,
                screen: "assessmentIntro",
                screenHistory: [...prev.screenHistory, prev.screen],
              }));
            }}
            onBack={goBack}
          />
        )}

        {screen === "assessmentIntro" && (
          <AssessmentIntroScreen
            isDark={isDark}
            onNext={() => navigate("assessment")}
            onBack={goBack}
          />
        )}

        {screen === "assessment" && (
          <AssessmentScreen
            isDark={isDark}
            answers={assessmentAnswers}
            currentQ={assessmentCurrentQ}
            onAnswer={(ans, q) => update({ assessmentAnswers: ans, assessmentCurrentQ: q })}
            onComplete={handleAssessmentComplete}
            onBack={goBack}
          />
        )}

        {screen === "assessmentComplete" && (
          <AssessmentCompleteScreen
            isDark={isDark}
            answers={assessmentAnswers}
            onViewResults={() => navigate("careerResults")}
          />
        )}

        {screen === "careerResults" && (
          <CareerResultsScreen
            isDark={isDark}
            recommendations={careerRecommendations}
            answers={assessmentAnswers}
            savedCareers={savedCareers}
            onSelect={handleSelectCareer}
            onToggleSave={toggleSaveCareer}
            onBack={goBack}
            onDashboard={() => navigate("dashboard")}
          />
        )}

        {screen === "careerDetail" && (
          <CareerDetailScreen
            isDark={isDark}
            careerId={selectedCareerId}
            matchScore={matchScore}
            savedCareers={savedCareers}
            onToggleSave={toggleSaveCareer}
            onBuildRoadmap={() => navigate("skillGap")}
            onBack={goBack}
          />
        )}

        {screen === "skillGap" && (
          <SkillGapScreen
            isDark={isDark}
            careerId={selectedCareerId}
            gaps={skillGaps}
            onContinue={() => navigate("roadmap")}
            onBack={goBack}
          />
        )}

        {screen === "roadmap" && (
          <RoadmapScreen
            isDark={isDark}
            careerId={selectedCareerId}
            progress={roadmapProgress}
            onToggleStep={handleToggleRoadmapStep}
            onContinue={() => navigate("institutions")}
            onBack={goBack}
          />
        )}

        {screen === "institutions" && (
          <InstitutionsScreen
            isDark={isDark}
            careerId={selectedCareerId}
            savedInstitutions={savedInstitutions}
            onToggleSave={toggleSaveInstitution}
            onContinue={() => navigate("academies")}
            onBack={goBack}
          />
        )}

        {screen === "academies" && (
          <AcademiesScreen
            isDark={isDark}
            careerId={selectedCareerId}
            savedAcademies={savedAcademies}
            onToggleSave={toggleSaveAcademy}
            onContinue={() => navigate("clarityCheck")}
            onBack={goBack}
          />
        )}

        {screen === "clarityCheck" && (
          <ClarityCheckScreen
            isDark={isDark}
            onComplete={handleClarityComplete}
            onBack={goBack}
          />
        )}

        {screen === "dashboard" && (
          <DashboardScreen
            isDark={isDark}
            onToggleDark={toggleDark}
            language={language}
            userName={user?.name ?? "Explorer"}
            avatarId={user?.avatar ?? 0}
            gender={user?.gender ?? "male"}
            careerRecommendations={careerRecommendations}
            selectedCareerId={selectedCareerId}
            skillGaps={skillGaps}
            roadmapProgress={roadmapProgress}
            clarityScore={clarityScore}
            savedCareers={savedCareers}
            savedInstitutions={savedInstitutions}
            savedAcademies={savedAcademies}
            assessmentDone={assessmentDone}
            streak={streak}
            dailyProgress={dailyProgress}
            onDailyProgress={(p) => update({ dailyProgress: p })}
            onAssessment={() => navigate("assessment")}
            onCareerResults={() => navigate("careerResults")}
            onCareerDetail={handleSelectCareer}
            onSkillGap={() => navigate("skillGap")}
            onRoadmap={() => navigate("roadmap")}
            onInstitutions={() => navigate("institutions")}
            onAcademies={() => navigate("academies")}
            onClarityCheck={() => navigate("clarityCheck")}
            onSaved={() => {}}
            onProfile={() => navigate("profile")}
          />
        )}

        {screen === "profile" && (
          <ProfileScreen
            isDark={isDark}
            userName={user?.name ?? ""}
            email={user?.email ?? ""}
            language={user?.language ?? "English"}
            userCategory={user?.userCategory ?? ""}
            onBack={goBack}
          />
        )}
      </div>
    </div>
  );
}
