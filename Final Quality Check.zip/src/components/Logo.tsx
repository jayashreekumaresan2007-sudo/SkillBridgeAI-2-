interface LogoProps {
  size?: number;
  white?: boolean;
}

export default function Logo({ size = 32, white = false }: LogoProps) {
  const c1 = white ? "#ffffff" : "#146EF5";
  const c2 = white ? "rgba(255,255,255,0.35)" : "rgba(37,99,235,0.18)";
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect width="40" height="40" rx="10" fill={c2} />
      {/* Top bar */}
      <rect x="10" y="10" width="20" height="5" rx="2.5" fill={c1} />
      {/* Middle connector going right→left */}
      <rect x="10" y="17.5" width="12" height="5" rx="2.5" fill={c1} />
      {/* Bottom bar */}
      <rect x="10" y="25" width="20" height="5" rx="2.5" fill={c1} />
      {/* Right vertical bridge top */}
      <rect x="27.5" y="10" width="5" height="12.5" rx="2.5" fill={c1} />
      {/* Left vertical bridge bottom */}
      <rect x="7.5" y="17.5" width="5" height="12.5" rx="2.5" fill={c1} />
    </svg>
  );
}
