/**
 * SkillBridgeAI ML Recommendation Engine (MVP)
 *
 * Architecture: Feature vector extraction → weighted scoring → normalization
 * This is a rule-based ML simulation. The architecture is designed so a
 * real trained model can replace the weight matrix and scoring function
 * without changing the interface.
 *
 * DEMO/TRAINING DATA: Weights are hand-crafted for demonstration.
 * Replace CAREER_WEIGHTS with a trained model's coefficients in production.
 */

import type { AssessmentAnswers, CareerRecommendation, SkillGapItem } from "./types";
import { CAREERS } from "./data";

interface FeatureVector {
  // Interest domain features (0 or 1)
  int_technology: number;
  int_design: number;
  int_business: number;
  int_data: number;
  int_science: number;
  int_communication: number;
  // Activity preference (0 or 1)
  act_designing: number;
  act_coding: number;
  act_solving: number;
  act_analyzing: number;
  act_helping: number;
  act_researching: number;
  // Project type preference (0 or 1)
  proj_app: number;
  proj_product: number;
  proj_data: number;
  proj_social: number;
  proj_creative: number;
  proj_leadership: number;
  // Scenario preference (0 or 1)
  scen_evidence: number;
  scen_combine: number;
  scen_discuss: number;
  scen_prototype: number;
  // Skill self-ratings (normalized 0–1)
  sk_communication: number;
  sk_problemSolving: number;
  sk_creativity: number;
  sk_leadership: number;
  sk_analytical: number;
  sk_technical: number;
  sk_teamwork: number;
  // Goal preference (0 or 1)
  goal_product: number;
  goal_lead: number;
  goal_research: number;
  goal_design: number;
  goal_business: number;
}

// Career weight vectors — DEMO DATA
// Each weight represents how strongly a feature predicts this career
const CAREER_WEIGHTS: Record<string, Partial<FeatureVector>> = {
  "ai-ml": {
    int_technology: 0.9, int_data: 0.8, int_science: 0.4,
    act_coding: 0.85, act_analyzing: 0.8, act_solving: 0.7,
    proj_app: 0.5, proj_data: 0.8,
    scen_evidence: 0.7, scen_prototype: 0.6,
    sk_analytical: 0.9, sk_technical: 0.95, sk_problemSolving: 0.8,
    goal_product: 0.6, goal_research: 0.5,
  },
  "software-dev": {
    int_technology: 0.9, int_data: 0.4,
    act_coding: 0.95, act_solving: 0.75,
    proj_app: 0.9,
    scen_prototype: 0.7,
    sk_technical: 0.95, sk_problemSolving: 0.85, sk_analytical: 0.7,
    goal_product: 0.7,
  },
  "data-analyst": {
    int_data: 0.95, int_technology: 0.6, int_business: 0.4,
    act_analyzing: 0.95, act_researching: 0.6,
    proj_data: 0.9,
    scen_evidence: 0.8,
    sk_analytical: 0.95, sk_technical: 0.6, sk_problemSolving: 0.7,
    goal_research: 0.5,
  },
  "uxui-designer": {
    int_design: 0.95, int_communication: 0.5,
    act_designing: 0.95, act_solving: 0.6,
    proj_product: 0.9, proj_creative: 0.7,
    scen_combine: 0.6,
    sk_creativity: 0.95, sk_communication: 0.7, sk_problemSolving: 0.6,
    goal_design: 0.9, goal_product: 0.5,
  },
  "business-manager": {
    int_business: 0.95, int_communication: 0.6,
    act_helping: 0.7,
    proj_leadership: 0.9, proj_social: 0.6,
    scen_discuss: 0.9,
    sk_leadership: 0.95, sk_communication: 0.9, sk_teamwork: 0.85,
    goal_lead: 0.95, goal_business: 0.8,
  },
  "digital-marketer": {
    int_communication: 0.9, int_business: 0.7, int_design: 0.5,
    act_designing: 0.5, act_helping: 0.6,
    proj_creative: 0.7, proj_social: 0.7,
    scen_discuss: 0.6,
    sk_communication: 0.9, sk_creativity: 0.7, sk_analytical: 0.6,
    goal_business: 0.7,
  },
  "research-analyst": {
    int_science: 0.9, int_data: 0.7, int_technology: 0.4,
    act_researching: 0.95, act_analyzing: 0.8,
    proj_data: 0.7, proj_social: 0.5,
    scen_evidence: 0.9,
    sk_analytical: 0.9, sk_communication: 0.7, sk_problemSolving: 0.7,
    goal_research: 0.95,
  },
  "product-manager": {
    int_business: 0.7, int_technology: 0.6, int_design: 0.5,
    act_helping: 0.7, act_solving: 0.7,
    proj_leadership: 0.8, proj_product: 0.7,
    scen_discuss: 0.8, scen_combine: 0.7,
    sk_leadership: 0.8, sk_communication: 0.9, sk_analytical: 0.7, sk_teamwork: 0.8,
    goal_lead: 0.7, goal_product: 0.8,
  },
  // Emerging careers
  "ai-product-designer": {
    int_design: 0.9, int_technology: 0.7,
    act_designing: 0.9, act_solving: 0.6,
    proj_product: 0.85, proj_creative: 0.7,
    scen_combine: 0.7,
    sk_creativity: 0.9, sk_analytical: 0.65, sk_communication: 0.7,
    goal_design: 0.85, goal_product: 0.6,
  },
  "prompt-engineer": {
    int_technology: 0.8, int_communication: 0.7, int_science: 0.5,
    act_researching: 0.8, act_analyzing: 0.75, act_solving: 0.7,
    proj_data: 0.6, proj_creative: 0.5,
    scen_evidence: 0.8,
    sk_analytical: 0.85, sk_communication: 0.8, sk_technical: 0.65,
    goal_research: 0.6, goal_product: 0.5,
  },
  "mlops-specialist": {
    int_technology: 0.9, int_data: 0.75,
    act_coding: 0.8, act_solving: 0.8, act_analyzing: 0.65,
    proj_app: 0.7, proj_data: 0.75,
    scen_evidence: 0.7, scen_prototype: 0.6,
    sk_technical: 0.95, sk_analytical: 0.85, sk_problemSolving: 0.8,
    goal_product: 0.6,
  },
};

function extractFeatures(answers: AssessmentAnswers): FeatureVector {
  const fv: FeatureVector = {
    int_technology: 0, int_design: 0, int_business: 0, int_data: 0, int_science: 0, int_communication: 0,
    act_designing: 0, act_coding: 0, act_solving: 0, act_analyzing: 0, act_helping: 0, act_researching: 0,
    proj_app: 0, proj_product: 0, proj_data: 0, proj_social: 0, proj_creative: 0, proj_leadership: 0,
    scen_evidence: 0, scen_combine: 0, scen_discuss: 0, scen_prototype: 0,
    sk_communication: 0, sk_problemSolving: 0, sk_creativity: 0, sk_leadership: 0,
    sk_analytical: 0, sk_technical: 0, sk_teamwork: 0,
    goal_product: 0, goal_lead: 0, goal_research: 0, goal_design: 0, goal_business: 0,
  };

  // Interests (binary, each active interest = 1)
  for (const interest of answers.interests) {
    if (interest === "technology") fv.int_technology = 1;
    if (interest === "design") fv.int_design = 1;
    if (interest === "business") fv.int_business = 1;
    if (interest === "data") fv.int_data = 1;
    if (interest === "science") fv.int_science = 1;
    if (interest === "communication") fv.int_communication = 1;
  }

  // Activity
  const actMap: Record<string, keyof FeatureVector> = {
    designing: "act_designing", coding: "act_coding", solving: "act_solving",
    analyzing: "act_analyzing", helping: "act_helping", researching: "act_researching",
  };
  if (answers.activity && actMap[answers.activity]) {
    (fv as any)[actMap[answers.activity]] = 1;
  }

  // Project type
  const projMap: Record<string, keyof FeatureVector> = {
    app: "proj_app", product: "proj_product", data: "proj_data",
    social: "proj_social", creative: "proj_creative", leadership: "proj_leadership",
  };
  if (answers.projectType && projMap[answers.projectType]) {
    (fv as any)[projMap[answers.projectType]] = 1;
  }

  // Scenario
  const scenMap: Record<string, keyof FeatureVector> = {
    evidence: "scen_evidence", combine: "scen_combine",
    discuss: "scen_discuss", prototype: "scen_prototype",
  };
  if (answers.scenario && scenMap[answers.scenario]) {
    (fv as any)[scenMap[answers.scenario]] = 1;
  }

  // Skill ratings — normalize 1-5 to 0-1
  const r = answers.ratings;
  fv.sk_communication = (r.communication - 1) / 4;
  fv.sk_problemSolving = (r.problemSolving - 1) / 4;
  fv.sk_creativity = (r.creativity - 1) / 4;
  fv.sk_leadership = (r.leadership - 1) / 4;
  fv.sk_analytical = (r.analytical - 1) / 4;
  fv.sk_technical = (r.technical - 1) / 4;
  fv.sk_teamwork = (r.teamwork - 1) / 4;

  // Goal
  const goalMap: Record<string, keyof FeatureVector> = {
    product: "goal_product", lead: "goal_lead", research: "goal_research",
    design: "goal_design", business: "goal_business",
  };
  if (answers.goal && goalMap[answers.goal]) {
    (fv as any)[goalMap[answers.goal]] = 1;
  }

  return fv;
}

function scoreCareer(fv: FeatureVector, weights: Partial<FeatureVector>): number {
  let dot = 0;
  let weightSum = 0;
  for (const [key, w] of Object.entries(weights)) {
    if (w === undefined) continue;
    const featureVal = (fv as any)[key] ?? 0;
    dot += featureVal * w;
    weightSum += w;
  }
  return weightSum > 0 ? dot / weightSum : 0;
}

export function runMLRecommendation(answers: AssessmentAnswers): CareerRecommendation[] {
  const fv = extractFeatures(answers);

  const rawScores: Array<{ id: string; raw: number }> = CAREERS.map((career) => ({
    id: career.id,
    raw: scoreCareer(fv, CAREER_WEIGHTS[career.id] ?? {}),
  }));

  // Sort descending
  rawScores.sort((a, b) => b.raw - a.raw);

  // Normalize scores to 65–97 range so they feel like realistic match percentages
  const maxRaw = rawScores[0]?.raw ?? 1;
  const minRaw = rawScores[rawScores.length - 1]?.raw ?? 0;
  const range = maxRaw - minRaw || 1;

  return rawScores.map((s, i) => {
    const career = CAREERS.find((c) => c.id === s.id)!;
    // Scale: top score → 91–97, bottom → 62–68
    const normalized = ((s.raw - minRaw) / range) * 32 + 65;
    const matchScore = Math.round(Math.max(62, Math.min(97, normalized)));

    const reasons = buildReasons(fv, s.id);

    return {
      id: career.id,
      title: career.title,
      matchScore: i === 0 ? Math.max(matchScore, 85) : matchScore,
      reasons,
      domain: career.domain,
      emoji: career.emoji,
      color: career.color,
    };
  });
}

function buildReasons(fv: FeatureVector, careerId: string): string[] {
  const reasons: string[] = [];
  const w = CAREER_WEIGHTS[careerId] ?? {};

  if (fv.sk_analytical > 0.6 && (w.sk_analytical ?? 0) > 0.7) reasons.push("Strong analytical profile");
  if (fv.sk_technical > 0.6 && (w.sk_technical ?? 0) > 0.7) reasons.push("High technical confidence");
  if (fv.sk_creativity > 0.6 && (w.sk_creativity ?? 0) > 0.7) reasons.push("Strong creative ability");
  if (fv.sk_leadership > 0.6 && (w.sk_leadership ?? 0) > 0.7) reasons.push("Strong leadership potential");
  if (fv.sk_communication > 0.6 && (w.sk_communication ?? 0) > 0.7) reasons.push("Excellent communication skills");
  if (fv.sk_problemSolving > 0.6 && (w.sk_problemSolving ?? 0) > 0.7) reasons.push("Strong problem-solving mindset");
  if (fv.int_technology === 1 && (w.int_technology ?? 0) > 0.7) reasons.push("High interest in Technology & AI");
  if (fv.int_design === 1 && (w.int_design ?? 0) > 0.7) reasons.push("Strong interest in Design");
  if (fv.int_business === 1 && (w.int_business ?? 0) > 0.7) reasons.push("High interest in Business");
  if (fv.int_data === 1 && (w.int_data ?? 0) > 0.7) reasons.push("High interest in Data & Analytics");
  if (fv.int_science === 1 && (w.int_science ?? 0) > 0.7) reasons.push("High interest in Science & Research");
  if (fv.act_coding === 1) reasons.push("Natural affinity for building and coding");
  if (fv.act_designing === 1) reasons.push("Enjoys designing and creating");
  if (fv.act_analyzing === 1) reasons.push("Enjoys data analysis");
  if (fv.act_researching === 1) reasons.push("Loves research and exploration");

  // Always return at least 2 reasons
  if (reasons.length === 0) reasons.push("Balanced profile suitable for this field", "Assessment indicates good potential");
  if (reasons.length === 1) reasons.push("Assessment shows alignment with this career");

  return reasons.slice(0, 4);
}

export function computeSkillGap(careerId: string, answers: AssessmentAnswers): SkillGapItem[] {
  const career = CAREERS.find((c) => c.id === careerId);
  if (!career) return [];

  const req = career.requiredLevels;
  const user = answers.ratings;

  const skills: Array<{ key: keyof typeof req; label: string }> = [
    { key: "communication", label: "Communication" },
    { key: "problemSolving", label: "Problem Solving" },
    { key: "creativity", label: "Creativity" },
    { key: "leadership", label: "Leadership" },
    { key: "analytical", label: "Analytical Thinking" },
    { key: "technical", label: "Technical Confidence" },
    { key: "teamwork", label: "Teamwork" },
  ];

  return skills.map(({ key, label }) => {
    const userLevel = user[key] ?? 3;
    const requiredLevel = req[key];
    const diff = requiredLevel - userLevel;
    const status: SkillGapItem["status"] =
      diff <= 0 ? "strong" : diff === 1 ? "developing" : "needs-improvement";

    return { skill: label, userLevel, requiredLevel, status };
  });
}
