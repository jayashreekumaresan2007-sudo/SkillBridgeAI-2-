import type { RoadmapStep } from "./types";

export const LANGUAGES = ["English", "Tamil", "Hindi", "Malayalam"];

export const USER_CATEGORIES = [
  { id: "school", label: "School Student", emoji: "🏫" },
  { id: "college", label: "College Student", emoji: "🎓" },
  { id: "graduate", label: "Graduate", emoji: "👨‍💼" },
  { id: "working", label: "Working Professional", emoji: "💼" },
  { id: "other", label: "Other", emoji: "🌟" },
];

export const PATHS = [
  {
    id: "career",
    title: "Career Guidance",
    desc: "Find which career is right for me",
    icon: "🎯",
  },
  {
    id: "skill",
    title: "Skill Development",
    desc: "Build skills for my chosen path",
    icon: "📈",
  },
  {
    id: "unsure",
    title: "I Am Not Sure",
    desc: "Let SkillBridgeAI figure out what I need",
    icon: "🔍",
  },
];

export const AVATAR_GROUPS = {
  male: [
    { id: 0, bg: "#DBEAFE", emoji: "👨🏻‍💻" },
    { id: 1, bg: "#FEE2E2", emoji: "👨🏾‍🎓" },
    { id: 2, bg: "#D1FAE5", emoji: "👨🏽‍🔬" },
    { id: 3, bg: "#FEF3C7", emoji: "👨🏼‍💼" },
    { id: 4, bg: "#EDE9FE", emoji: "👨🏻‍🎨" },
    { id: 5, bg: "#FCE7F3", emoji: "👨🏾‍🏫" },
  ],
  female: [
    { id: 6, bg: "#DBEAFE", emoji: "👩🏻‍💻" },
    { id: 7, bg: "#FEE2E2", emoji: "👩🏾‍🎓" },
    { id: 8, bg: "#D1FAE5", emoji: "👩🏽‍🔬" },
    { id: 9, bg: "#FEF3C7", emoji: "👩🏼‍💼" },
    { id: 10, bg: "#EDE9FE", emoji: "👩🏻‍🎨" },
    { id: 11, bg: "#FCE7F3", emoji: "👩🏾‍🏫" },
  ],
};

export interface Question {
  id: number;
  type: "multiselect" | "single" | "grid" | "rating";
  category: string;
  question: string;
  subtitle: string;
  options?: Array<{ id: string; label: string; emoji?: string }>;
  ratingLabel?: string;
}

export const ASSESSMENT_QUESTIONS: Question[] = [
  {
    id: 1,
    type: "multiselect",
    category: "interest",
    question: "Which area are you most curious to explore?",
    subtitle: "Choose up to 2 options that feel most like you",
    options: [
      { id: "technology", label: "Technology & AI", emoji: "💻" },
      { id: "design", label: "Design & Creativity", emoji: "🎨" },
      { id: "business", label: "Business & Management", emoji: "📊" },
      { id: "data", label: "Data & Analytics", emoji: "📈" },
      { id: "science", label: "Science & Research", emoji: "🔬" },
      { id: "communication", label: "Media & Communication", emoji: "📣" },
    ],
  },
  {
    id: 2,
    type: "grid",
    category: "activity",
    question: "What kind of activity would you naturally enjoy?",
    subtitle: "Choose the option that feels most like you",
    options: [
      { id: "designing", label: "Designing & Creating", emoji: "🎨" },
      { id: "coding", label: "Building & Coding", emoji: "💻" },
      { id: "solving", label: "Solving Problems", emoji: "🧩" },
      { id: "analyzing", label: "Analysing Data", emoji: "📊" },
      { id: "helping", label: "Helping & Working with People", emoji: "🤝" },
      { id: "researching", label: "Research & Exploring", emoji: "🔭" },
    ],
  },
  {
    id: 3,
    type: "grid",
    category: "project",
    question: "Which type of project would excite you the most?",
    subtitle: "Choose the option that feels most like you",
    options: [
      { id: "app", label: "Building an app or website", emoji: "📱" },
      { id: "product", label: "Designing a digital product", emoji: "✏️" },
      { id: "data", label: "Analysing real-world data", emoji: "📉" },
      { id: "social", label: "Solving a social problem", emoji: "🌍" },
      { id: "creative", label: "Creating something innovative", emoji: "💡" },
      { id: "leadership", label: "Leading a team project", emoji: "👥" },
    ],
  },
  {
    id: 4,
    type: "single",
    category: "scenario",
    question: "Your team has two completely different ideas for a project. What would you do?",
    subtitle: "Be honest — there is no right or wrong answer",
    options: [
      { id: "evidence", label: "Choose the idea with strongest evidence" },
      { id: "combine", label: "Combine both ideas if possible" },
      { id: "discuss", label: "Discuss and decide together" },
      { id: "prototype", label: "Build quick versions and compare them" },
    ],
  },
  {
    id: 5,
    type: "rating",
    category: "skill",
    question: "Rate your Communication skills",
    subtitle: "1 = Beginner  ·  5 = Very Confident",
    ratingLabel: "communication",
  },
  {
    id: 6,
    type: "rating",
    category: "skill",
    question: "Rate your Problem Solving ability",
    subtitle: "1 = Beginner  ·  5 = Very Confident",
    ratingLabel: "problemSolving",
  },
  {
    id: 7,
    type: "rating",
    category: "skill",
    question: "Rate your Creativity",
    subtitle: "1 = Beginner  ·  5 = Very Confident",
    ratingLabel: "creativity",
  },
  {
    id: 8,
    type: "rating",
    category: "skill",
    question: "Rate your Leadership",
    subtitle: "1 = Beginner  ·  5 = Very Confident",
    ratingLabel: "leadership",
  },
  {
    id: 9,
    type: "rating",
    category: "skill",
    question: "Rate your Analytical Thinking",
    subtitle: "1 = Beginner  ·  5 = Very Confident",
    ratingLabel: "analytical",
  },
  {
    id: 10,
    type: "rating",
    category: "skill",
    question: "Rate your Technical Confidence",
    subtitle: "1 = Beginner  ·  5 = Very Confident",
    ratingLabel: "technical",
  },
  {
    id: 11,
    type: "rating",
    category: "skill",
    question: "Rate your Teamwork",
    subtitle: "1 = Beginner  ·  5 = Very Confident",
    ratingLabel: "teamwork",
  },
  {
    id: 12,
    type: "single",
    category: "goal",
    question: "What would you most like to achieve in 3 years?",
    subtitle: "Choose the option that best represents your ambition",
    options: [
      { id: "product", label: "Build a product used by thousands", emoji: "🚀" },
      { id: "lead", label: "Lead a team or department", emoji: "👑" },
      { id: "research", label: "Publish research or meaningful analysis", emoji: "📝" },
      { id: "design", label: "Create designs that inspire people", emoji: "🎨" },
      { id: "business", label: "Start a business or venture", emoji: "💼" },
    ],
  },
];

export interface CareerData {
  id: string;
  title: string;
  domain: string;
  emoji: string;
  color: string;
  tagline: string;
  overview: string;
  responsibilities: string[];
  technicalSkills: string[];
  softSkills: string[];
  requiredLevels: {
    communication: number;
    problemSolving: number;
    creativity: number;
    leadership: number;
    analytical: number;
    technical: number;
    teamwork: number;
  };
  roadmap: RoadmapStep[];
  entryRoles: string[];
  growthRoles: string[];
  relatedCareers: string[];
  avgSalary: string;
  growth: string;
}

export const CAREERS: CareerData[] = [
  {
    id: "ai-ml",
    title: "AI / ML Engineer",
    domain: "Technology",
    emoji: "🤖",
    color: "#146EF5",
    tagline: "Build intelligent systems that learn and adapt",
    overview:
      "AI/ML Engineers design and deploy machine learning models, neural networks, and AI systems that power intelligent applications across industries.",
    responsibilities: [
      "Design and train machine learning models",
      "Process and analyse large datasets",
      "Collaborate with data scientists and engineers",
      "Deploy and monitor AI systems in production",
      "Research state-of-the-art ML techniques",
    ],
    technicalSkills: ["Python", "TensorFlow / PyTorch", "SQL", "Cloud platforms", "Statistics", "Data pipelines"],
    softSkills: ["Analytical thinking", "Problem solving", "Communication", "Curiosity"],
    requiredLevels: { communication: 3, problemSolving: 5, creativity: 3, leadership: 2, analytical: 5, technical: 5, teamwork: 3 },
    entryRoles: ["ML Intern", "Junior Data Scientist", "AI Research Assistant"],
    growthRoles: ["Senior ML Engineer", "AI Architect", "Research Scientist", "ML Lead"],
    relatedCareers: ["Data Analyst", "Software Developer", "Research Analyst"],
    avgSalary: "₹8–30 LPA",
    growth: "Very High",
    roadmap: [
      { step: 1, title: "Fundamentals", goal: "Build a strong mathematical foundation", skills: ["Python basics", "Statistics", "Linear Algebra"], activity: "Complete a Python + Statistics course", duration: "4–6 weeks" },
      { step: 2, title: "Core ML Concepts", goal: "Learn supervised and unsupervised learning", skills: ["Scikit-learn", "Regression", "Classification", "Clustering"], activity: "Build 3 ML projects with real datasets", duration: "6–8 weeks" },
      { step: 3, title: "Deep Learning", goal: "Master neural networks and deep learning", skills: ["TensorFlow/PyTorch", "CNNs", "RNNs", "Transformers"], activity: "Train an image classifier and an NLP model", duration: "6–8 weeks" },
      { step: 4, title: "Data Engineering", goal: "Learn to work with large-scale data", skills: ["SQL", "Pandas", "Data pipelines", "Cloud storage"], activity: "Build an end-to-end data pipeline", duration: "4 weeks" },
      { step: 5, title: "Portfolio Project", goal: "Build a complete AI application", skills: ["Model deployment", "APIs", "Monitoring"], activity: "Deploy an ML model as a web application", duration: "4–6 weeks" },
      { step: 6, title: "Career Preparation", goal: "Land your first AI/ML role", skills: ["Interview prep", "GitHub portfolio", "Resume writing"], activity: "Apply to 20+ positions with a polished portfolio", duration: "4 weeks" },
    ],
  },
  {
    id: "software-dev",
    title: "Software Developer",
    domain: "Technology",
    emoji: "💻",
    color: "#7C3AED",
    tagline: "Turn ideas into software that millions use",
    overview:
      "Software Developers design, build, and maintain applications and systems that power modern digital experiences — from mobile apps to enterprise platforms.",
    responsibilities: [
      "Write clean, maintainable code",
      "Design software architecture",
      "Collaborate with design and product teams",
      "Review code and mentor junior developers",
      "Debug and improve existing systems",
    ],
    technicalSkills: ["JavaScript/TypeScript", "React / Node.js", "Databases", "APIs", "Git", "Testing"],
    softSkills: ["Problem solving", "Teamwork", "Communication", "Attention to detail"],
    requiredLevels: { communication: 3, problemSolving: 5, creativity: 3, leadership: 2, analytical: 4, technical: 5, teamwork: 3 },
    entryRoles: ["Junior Developer", "Frontend Intern", "Software Engineer Trainee"],
    growthRoles: ["Senior Developer", "Tech Lead", "Software Architect", "Engineering Manager"],
    relatedCareers: ["AI / ML Engineer", "Cloud / DevOps", "Product Manager"],
    avgSalary: "₹6–25 LPA",
    growth: "High",
    roadmap: [
      { step: 1, title: "Programming Fundamentals", goal: "Master core programming concepts", skills: ["Variables", "Functions", "Data structures", "Algorithms"], activity: "Solve 50 coding problems on LeetCode", duration: "4–6 weeks" },
      { step: 2, title: "Web Development", goal: "Build modern web applications", skills: ["HTML/CSS", "JavaScript", "React", "Node.js"], activity: "Build 5 web projects from scratch", duration: "8–10 weeks" },
      { step: 3, title: "Backend & Databases", goal: "Build robust server-side systems", skills: ["REST APIs", "SQL/NoSQL", "Authentication", "Security"], activity: "Build a full-stack application with a database", duration: "6–8 weeks" },
      { step: 4, title: "System Design", goal: "Understand scalable architectures", skills: ["Microservices", "Caching", "Load balancing", "Cloud basics"], activity: "Design a scalable system on paper, then implement", duration: "4 weeks" },
      { step: 5, title: "Portfolio Project", goal: "Ship a real product", skills: ["Version control", "Deployment", "CI/CD", "Documentation"], activity: "Build and launch a SaaS or open-source project", duration: "6 weeks" },
      { step: 6, title: "Career Preparation", goal: "Land your first developer role", skills: ["System design interviews", "Coding interviews", "Portfolio"], activity: "Apply to 25+ companies with a polished portfolio", duration: "4 weeks" },
    ],
  },
  {
    id: "data-analyst",
    title: "Data Analyst",
    domain: "Data",
    emoji: "📊",
    color: "#059669",
    tagline: "Turn raw data into decisions that matter",
    overview:
      "Data Analysts collect, process, and interpret complex datasets to help organisations make informed decisions. They bridge the gap between raw data and actionable business insight.",
    responsibilities: [
      "Collect and clean large datasets",
      "Perform statistical analysis and modelling",
      "Create dashboards and reports",
      "Present findings to business stakeholders",
      "Identify trends and patterns",
    ],
    technicalSkills: ["Python / R", "SQL", "Excel", "Tableau / Power BI", "Statistics", "Data visualisation"],
    softSkills: ["Analytical thinking", "Communication", "Attention to detail", "Critical thinking"],
    requiredLevels: { communication: 4, problemSolving: 4, creativity: 2, leadership: 2, analytical: 5, technical: 4, teamwork: 3 },
    entryRoles: ["Junior Data Analyst", "Business Intelligence Intern", "Reporting Analyst"],
    growthRoles: ["Senior Data Analyst", "Data Scientist", "Analytics Manager", "BI Lead"],
    relatedCareers: ["AI / ML Engineer", "Business Manager", "Research Analyst"],
    avgSalary: "₹5–20 LPA",
    growth: "High",
    roadmap: [
      { step: 1, title: "Data Foundations", goal: "Build a strong data literacy foundation", skills: ["Statistics", "Excel", "Basic SQL"], activity: "Complete a Statistics and SQL course", duration: "4 weeks" },
      { step: 2, title: "SQL & Databases", goal: "Master data querying and manipulation", skills: ["Advanced SQL", "Database design", "Joins", "Aggregations"], activity: "Analyse 5 real datasets using SQL", duration: "4–6 weeks" },
      { step: 3, title: "Python for Data", goal: "Automate analysis and build data pipelines", skills: ["Pandas", "NumPy", "Matplotlib", "Seaborn"], activity: "Build an automated data analysis report", duration: "6 weeks" },
      { step: 4, title: "Visualisation & BI", goal: "Communicate data insights clearly", skills: ["Tableau / Power BI", "Dashboard design", "Storytelling with data"], activity: "Build 3 interactive dashboards", duration: "4 weeks" },
      { step: 5, title: "Portfolio Project", goal: "Complete an end-to-end data project", skills: ["Data cleaning", "EDA", "Modelling", "Presentation"], activity: "Publish a Kaggle or GitHub data analysis project", duration: "4–6 weeks" },
      { step: 6, title: "Career Preparation", goal: "Land your first data role", skills: ["Case study interviews", "Portfolio polish", "Networking"], activity: "Apply to analyst roles with a strong portfolio", duration: "4 weeks" },
    ],
  },
  {
    id: "uxui-designer",
    title: "UX / UI Designer",
    domain: "Design",
    emoji: "🎨",
    color: "#DB2777",
    tagline: "Design experiences that people love to use",
    overview:
      "UX/UI Designers create the look, feel, and flow of digital products. They research user behaviour, design interfaces, and ensure every interaction feels intuitive and meaningful.",
    responsibilities: [
      "Conduct user research and usability tests",
      "Create wireframes and interactive prototypes",
      "Design visual systems and component libraries",
      "Collaborate with developers and product managers",
      "Iterate designs based on user feedback",
    ],
    technicalSkills: ["Figma / Sketch", "Prototyping", "Design systems", "User research methods", "Accessibility"],
    softSkills: ["Creativity", "Empathy", "Communication", "Attention to detail", "Problem solving"],
    requiredLevels: { communication: 4, problemSolving: 4, creativity: 5, leadership: 2, analytical: 3, technical: 3, teamwork: 3 },
    entryRoles: ["Junior UX Designer", "UI Design Intern", "Product Design Trainee"],
    growthRoles: ["Senior UX Designer", "Product Designer", "Design Lead", "Head of Design"],
    relatedCareers: ["Product Manager", "Digital Marketer", "Software Developer"],
    avgSalary: "₹5–22 LPA",
    growth: "High",
    roadmap: [
      { step: 1, title: "Design Fundamentals", goal: "Master visual design principles", skills: ["Typography", "Colour theory", "Layout", "Hierarchy"], activity: "Complete a visual design crash course + redesign 3 existing apps", duration: "4–6 weeks" },
      { step: 2, title: "UX Research", goal: "Learn how to understand users", skills: ["User interviews", "Personas", "Journey maps", "Usability testing"], activity: "Conduct 5 user research interviews", duration: "4 weeks" },
      { step: 3, title: "Figma & Prototyping", goal: "Master professional design tools", skills: ["Figma", "Component libraries", "Auto-layout", "Prototyping"], activity: "Build a complete mobile app design in Figma", duration: "6–8 weeks" },
      { step: 4, title: "Design Systems", goal: "Build scalable and consistent design systems", skills: ["Tokens", "Components", "Documentation", "Handoff"], activity: "Create a full design system for a fictional product", duration: "4 weeks" },
      { step: 5, title: "Portfolio Project", goal: "Create a case study portfolio", skills: ["Problem framing", "Design process", "Presentation"], activity: "Publish 3 UX case studies on Behance or personal site", duration: "6 weeks" },
      { step: 6, title: "Career Preparation", goal: "Land your first design role", skills: ["Portfolio presentation", "Design critique", "Interview prep"], activity: "Apply to 20+ design roles with a case study portfolio", duration: "4 weeks" },
    ],
  },
  {
    id: "business-manager",
    title: "Business Manager",
    domain: "Business",
    emoji: "📋",
    color: "#D97706",
    tagline: "Lead teams, build strategy, drive results",
    overview:
      "Business Managers oversee operations, lead teams, and drive organisational goals. They sit at the intersection of strategy, people management, and execution.",
    responsibilities: [
      "Set strategic direction and team goals",
      "Manage budgets and resources",
      "Lead cross-functional projects",
      "Coach and develop team members",
      "Report to stakeholders and senior leadership",
    ],
    technicalSkills: ["Excel / Sheets", "Project management tools", "Data analysis basics", "Presentation tools", "CRM"],
    softSkills: ["Leadership", "Communication", "Decision making", "Teamwork", "Conflict resolution"],
    requiredLevels: { communication: 5, problemSolving: 4, creativity: 3, leadership: 5, analytical: 4, technical: 2, teamwork: 5 },
    entryRoles: ["Management Trainee", "Business Analyst", "Operations Associate"],
    growthRoles: ["Senior Manager", "Department Head", "VP Operations", "CEO"],
    relatedCareers: ["Product Manager", "Digital Marketer", "Data Analyst"],
    avgSalary: "₹6–30 LPA",
    growth: "High",
    roadmap: [
      { step: 1, title: "Business Fundamentals", goal: "Understand how businesses work", skills: ["Finance basics", "Operations", "Marketing basics", "Strategy"], activity: "Complete a business management certificate course", duration: "4–6 weeks" },
      { step: 2, title: "People & Leadership", goal: "Develop leadership and people management skills", skills: ["Team management", "Coaching", "Conflict resolution", "Motivation"], activity: "Lead a volunteer or student project team", duration: "6 weeks" },
      { step: 3, title: "Project Management", goal: "Deliver projects on time and on budget", skills: ["Agile / Scrum", "Gantt charts", "Risk management", "Stakeholder communication"], activity: "Complete a PMP or Google Project Management certificate", duration: "6–8 weeks" },
      { step: 4, title: "Analytics for Managers", goal: "Make data-driven decisions", skills: ["Excel", "Dashboards", "KPIs", "Business intelligence"], activity: "Build a business dashboard for a real problem", duration: "4 weeks" },
      { step: 5, title: "Strategy & Growth", goal: "Learn how to build and execute strategy", skills: ["SWOT", "OKRs", "Competitive analysis", "Business models"], activity: "Write a business strategy for a fictional company", duration: "4–6 weeks" },
      { step: 6, title: "Career Preparation", goal: "Land a management track role", skills: ["Case interviews", "MBA preparation", "Networking"], activity: "Apply to management trainee programmes", duration: "4 weeks" },
    ],
  },
  {
    id: "digital-marketer",
    title: "Digital Marketer",
    domain: "Marketing",
    emoji: "📣",
    color: "#EA580C",
    tagline: "Connect brands with the people who need them",
    overview:
      "Digital Marketers create and execute strategies that grow brands online — through social media, content, SEO, paid ads, and email campaigns.",
    responsibilities: [
      "Plan and execute digital marketing campaigns",
      "Create and manage social media content",
      "Optimise content for search engines (SEO)",
      "Analyse campaign performance and ROI",
      "Manage paid advertising campaigns",
    ],
    technicalSkills: ["Google Analytics", "SEO tools", "Meta Ads / Google Ads", "Email marketing platforms", "Canva / Figma basics"],
    softSkills: ["Creativity", "Communication", "Analytical thinking", "Adaptability"],
    requiredLevels: { communication: 5, problemSolving: 3, creativity: 4, leadership: 3, analytical: 4, technical: 3, teamwork: 3 },
    entryRoles: ["Social Media Executive", "Content Writer", "Digital Marketing Intern"],
    growthRoles: ["Senior Digital Marketer", "Growth Hacker", "Marketing Manager", "CMO"],
    relatedCareers: ["Business Manager", "UX / UI Designer", "Product Manager"],
    avgSalary: "₹4–18 LPA",
    growth: "High",
    roadmap: [
      { step: 1, title: "Marketing Fundamentals", goal: "Understand digital marketing landscape", skills: ["Marketing basics", "Consumer psychology", "Brand positioning"], activity: "Complete Google Digital Marketing certificate", duration: "4 weeks" },
      { step: 2, title: "Content & SEO", goal: "Master content creation and SEO", skills: ["SEO", "Content writing", "Keyword research", "Blogging"], activity: "Create and optimise 10 SEO blog posts", duration: "6 weeks" },
      { step: 3, title: "Social Media Marketing", goal: "Build and grow social media presence", skills: ["Instagram / LinkedIn", "Content strategy", "Community management"], activity: "Grow a social media account to 500+ followers", duration: "6–8 weeks" },
      { step: 4, title: "Paid Advertising", goal: "Run effective paid campaigns", skills: ["Google Ads", "Meta Ads", "Budget optimisation", "A/B testing"], activity: "Run a ₹2000 test campaign and analyse results", duration: "4 weeks" },
      { step: 5, title: "Analytics & Growth", goal: "Measure and improve marketing performance", skills: ["Google Analytics", "Conversion optimisation", "Reporting"], activity: "Build a marketing performance dashboard", duration: "4 weeks" },
      { step: 6, title: "Career Preparation", goal: "Land your first marketing role", skills: ["Portfolio", "Case studies", "Interview prep"], activity: "Apply to marketing roles with a results-based portfolio", duration: "4 weeks" },
    ],
  },
  {
    id: "research-analyst",
    title: "Research Analyst",
    domain: "Research",
    emoji: "🔬",
    color: "#0891B2",
    tagline: "Uncover the insights that drive the world forward",
    overview:
      "Research Analysts gather, interpret, and synthesise information to produce insights for industry, academia, consulting firms, or policy organisations.",
    responsibilities: [
      "Design and conduct research studies",
      "Collect and analyse qualitative and quantitative data",
      "Write research reports and white papers",
      "Present findings to stakeholders",
      "Monitor industry trends",
    ],
    technicalSkills: ["Statistical analysis", "R / Python", "Survey tools", "Literature review", "Data visualisation"],
    softSkills: ["Analytical thinking", "Writing", "Critical thinking", "Attention to detail", "Curiosity"],
    requiredLevels: { communication: 4, problemSolving: 4, creativity: 2, leadership: 2, analytical: 5, technical: 3, teamwork: 2 },
    entryRoles: ["Research Intern", "Junior Research Analyst", "Market Research Associate"],
    growthRoles: ["Senior Research Analyst", "Research Manager", "Principal Researcher"],
    relatedCareers: ["Data Analyst", "AI / ML Engineer", "Business Manager"],
    avgSalary: "₹5–18 LPA",
    growth: "Medium",
    roadmap: [
      { step: 1, title: "Research Methods", goal: "Learn the foundations of research methodology", skills: ["Quantitative research", "Qualitative research", "Survey design", "Literature review"], activity: "Complete a research methods course and write a mini literature review", duration: "4–6 weeks" },
      { step: 2, title: "Statistics & Analysis", goal: "Analyse data confidently", skills: ["Descriptive statistics", "Inferential statistics", "SPSS / R basics"], activity: "Analyse a published dataset and write findings", duration: "6 weeks" },
      { step: 3, title: "Data Collection Tools", goal: "Master research data collection", skills: ["Survey platforms", "Interview techniques", "Focus groups", "Observational research"], activity: "Conduct a small primary research study", duration: "4 weeks" },
      { step: 4, title: "Report Writing", goal: "Communicate research clearly and credibly", skills: ["Academic writing", "Executive summaries", "Data visualisation", "Presentations"], activity: "Write a full research report on a topic of interest", duration: "4 weeks" },
      { step: 5, title: "Portfolio Project", goal: "Complete an independent research project", skills: ["End-to-end research process", "Publication / sharing"], activity: "Publish a research project on LinkedIn or Academia.edu", duration: "6 weeks" },
      { step: 6, title: "Career Preparation", goal: "Land a research or analyst role", skills: ["Resume for research roles", "Portfolio", "Networking in academia / industry"], activity: "Apply to research associate and analyst roles", duration: "4 weeks" },
    ],
  },
  {
    id: "product-manager",
    title: "Product Manager",
    domain: "Product",
    emoji: "🗺️",
    color: "#7C3AED",
    tagline: "Define what gets built and why it matters",
    overview:
      "Product Managers own the vision, strategy, and roadmap of a product. They connect user needs with business goals and work with cross-functional teams to deliver results.",
    responsibilities: [
      "Define product vision and strategy",
      "Prioritise features and manage the product backlog",
      "Collaborate with design, engineering, and business teams",
      "Analyse user data and feedback",
      "Launch and iterate on product features",
    ],
    technicalSkills: ["Product analytics", "Wireframing basics", "Agile / Scrum", "SQL basics", "Roadmapping tools"],
    softSkills: ["Leadership", "Communication", "Decision making", "Empathy", "Analytical thinking"],
    requiredLevels: { communication: 5, problemSolving: 4, creativity: 3, leadership: 4, analytical: 4, technical: 3, teamwork: 5 },
    entryRoles: ["Associate Product Manager", "Product Analyst", "Business Analyst"],
    growthRoles: ["Product Manager", "Senior PM", "Director of Product", "CPO"],
    relatedCareers: ["Business Manager", "UX / UI Designer", "Software Developer"],
    avgSalary: "₹8–30 LPA",
    growth: "Very High",
    roadmap: [
      { step: 1, title: "Product Foundations", goal: "Understand what product management is", skills: ["Product lifecycle", "Agile basics", "User stories", "PRDs"], activity: "Complete a PM crash course and write your first PRD", duration: "4 weeks" },
      { step: 2, title: "User Research", goal: "Understand users deeply", skills: ["User interviews", "Jobs-to-be-done", "Empathy mapping", "Surveys"], activity: "Conduct 10 user interviews for a product idea", duration: "4–6 weeks" },
      { step: 3, title: "Strategy & Prioritisation", goal: "Make smart product decisions", skills: ["OKRs", "RICE / ICE scoring", "Competitive analysis", "Roadmapping"], activity: "Build a 6-month product roadmap for a real or fictional product", duration: "4 weeks" },
      { step: 4, title: "Analytics & Metrics", goal: "Use data to make decisions", skills: ["Product analytics", "Funnels", "Cohorts", "A/B testing"], activity: "Analyse and improve the funnel of a real product", duration: "4 weeks" },
      { step: 5, title: "Portfolio Project", goal: "Build a PM portfolio", skills: ["Case studies", "Product teardowns", "Mockups"], activity: "Write 3 product case studies and 2 feature proposals", duration: "6 weeks" },
      { step: 6, title: "Career Preparation", goal: "Land an APM or PM role", skills: ["PM interviews", "Product sense", "Estimation questions"], activity: "Apply to APM programmes at product companies", duration: "4 weeks" },
    ],
  },
  // ── Emerging Careers ──────────────────────────────────────────────
  {
    id: "ai-product-designer",
    title: "AI Product Designer",
    domain: "Emerging · Design + AI",
    emoji: "✨",
    color: "#6366F1",
    tagline: "Design intelligent products that adapt to people",
    overview:
      "AI Product Designers sit at the intersection of UX design and artificial intelligence — crafting interfaces, interaction models and experiences that leverage AI capabilities while remaining intuitive and human-centred.",
    responsibilities: [
      "Design AI-powered user experiences and interaction flows",
      "Define how AI outputs are communicated to users",
      "Collaborate with ML engineers on capability and limitation boundaries",
      "Run user research to inform AI feature design",
      "Create prototypes of AI-driven product concepts",
    ],
    technicalSkills: ["Figma", "Prototyping", "Prompt design basics", "AI API integration concepts", "UX research"],
    softSkills: ["Creative thinking", "Systems thinking", "Communication", "Empathy", "Curiosity"],
    requiredLevels: { communication: 4, problemSolving: 4, creativity: 5, leadership: 2, analytical: 4, technical: 3, teamwork: 3 },
    entryRoles: ["Junior UX Designer", "AI Product Intern", "Interaction Designer"],
    growthRoles: ["Senior AI Product Designer", "Head of AI Experience", "Design Director"],
    relatedCareers: ["UX / UI Designer", "Product Manager", "AI / ML Engineer"],
    avgSalary: "₹10–35 LPA",
    growth: "Very High",
    roadmap: [
      { step: 1, title: "Design Fundamentals", goal: "Master visual and interaction design", skills: ["Typography", "Figma", "Design systems"], activity: "Redesign 3 AI-powered apps with better UX", duration: "4–6 weeks" },
      { step: 2, title: "AI Literacy", goal: "Understand AI capabilities and limitations", skills: ["Prompt engineering basics", "LLM fundamentals", "AI ethics"], activity: "Explore 10 AI products and document UX patterns", duration: "4 weeks" },
      { step: 3, title: "AI UX Patterns", goal: "Learn AI-specific design patterns", skills: ["Error states for AI", "Trust signals", "Progressive disclosure"], activity: "Create an AI UX pattern library", duration: "6 weeks" },
      { step: 4, title: "Prototyping AI Products", goal: "Build realistic AI product prototypes", skills: ["Figma advanced", "AI API demos", "Scenario mapping"], activity: "Prototype an AI tutoring assistant end-to-end", duration: "6–8 weeks" },
      { step: 5, title: "Portfolio", goal: "Showcase AI product design thinking", skills: ["Case studies", "Process documentation"], activity: "Publish 3 AI product design case studies", duration: "4–6 weeks" },
      { step: 6, title: "Career Preparation", goal: "Land a role in AI product design", skills: ["AI company research", "Portfolio review", "Interview prep"], activity: "Apply to AI-first startups and design teams", duration: "4 weeks" },
    ],
  },
  {
    id: "prompt-engineer",
    title: "Prompt Engineer",
    domain: "Emerging · AI",
    emoji: "⚡",
    color: "#F59E0B",
    tagline: "Shape how AI thinks, responds and performs",
    overview:
      "Prompt Engineers design, test and optimise text inputs that guide large language models (LLMs) to produce accurate, reliable and useful outputs across various applications.",
    responsibilities: [
      "Design and test prompts for LLMs and generative AI systems",
      "Evaluate and benchmark AI output quality",
      "Document prompt strategies and maintain prompt libraries",
      "Collaborate with product teams to integrate AI into workflows",
      "Research prompt engineering techniques and best practices",
    ],
    technicalSkills: ["LLM APIs (GPT, Claude, Gemini)", "Python basics", "JSON", "Evaluation frameworks", "RAG concepts"],
    softSkills: ["Analytical thinking", "Written communication", "Curiosity", "Patience", "Attention to detail"],
    requiredLevels: { communication: 5, problemSolving: 4, creativity: 4, leadership: 2, analytical: 5, technical: 3, teamwork: 2 },
    entryRoles: ["Prompt Specialist", "AI Content Analyst", "AI Operations Intern"],
    growthRoles: ["Senior Prompt Engineer", "AI Systems Designer", "LLM Product Lead"],
    relatedCareers: ["AI / ML Engineer", "AI Product Designer", "Research Analyst"],
    avgSalary: "₹8–28 LPA",
    growth: "Very High",
    roadmap: [
      { step: 1, title: "LLM Fundamentals", goal: "Understand how large language models work", skills: ["Transformer basics", "Tokenization", "Context windows"], activity: "Read 5 core papers on LLMs and summarise learnings", duration: "3–4 weeks" },
      { step: 2, title: "Prompting Techniques", goal: "Master core prompt engineering patterns", skills: ["Zero-shot", "Few-shot", "Chain-of-thought", "Role prompting"], activity: "Build a test suite of 50+ prompts across 5 tasks", duration: "4–6 weeks" },
      { step: 3, title: "Evaluation & Quality", goal: "Measure and improve AI output quality", skills: ["Evaluation metrics", "Benchmarking", "RLHF concepts"], activity: "Evaluate a real LLM application and write an improvement report", duration: "4 weeks" },
      { step: 4, title: "Advanced Techniques", goal: "Apply advanced prompting and RAG", skills: ["RAG pipelines", "Agentic frameworks", "Fine-tuning concepts"], activity: "Build a RAG-based Q&A system with prompt optimisation", duration: "6 weeks" },
      { step: 5, title: "Portfolio", goal: "Showcase prompt engineering work", skills: ["Documentation", "Case studies", "Public prompt libraries"], activity: "Publish a prompt engineering playbook on GitHub", duration: "4 weeks" },
      { step: 6, title: "Career Preparation", goal: "Land a prompt engineering role", skills: ["AI job market", "Portfolio polish", "Technical communication"], activity: "Apply to AI startups and product teams", duration: "4 weeks" },
    ],
  },
  {
    id: "mlops-specialist",
    title: "MLOps Specialist",
    domain: "Emerging · AI + DevOps",
    emoji: "⚙️",
    color: "#059669",
    tagline: "Bridge the gap between AI models and production systems",
    overview:
      "MLOps Specialists operationalise machine learning — handling model deployment, monitoring, versioning and infrastructure so that AI systems run reliably at scale in production environments.",
    responsibilities: [
      "Build and maintain ML pipelines and infrastructure",
      "Deploy ML models to production using cloud platforms",
      "Monitor model performance and detect data drift",
      "Manage model versioning and experiment tracking",
      "Collaborate with data scientists to productionise models",
    ],
    technicalSkills: ["Python", "Docker / Kubernetes", "MLflow / DVC", "AWS / GCP / Azure", "CI/CD", "Monitoring tools"],
    softSkills: ["Problem solving", "Attention to detail", "Communication", "Systems thinking"],
    requiredLevels: { communication: 3, problemSolving: 5, creativity: 2, leadership: 2, analytical: 5, technical: 5, teamwork: 4 },
    entryRoles: ["Junior MLOps Engineer", "DevOps Intern", "ML Infrastructure Analyst"],
    growthRoles: ["Senior MLOps Engineer", "ML Platform Lead", "AI Infrastructure Architect"],
    relatedCareers: ["AI / ML Engineer", "Software Developer", "Data Analyst"],
    avgSalary: "₹10–35 LPA",
    growth: "Very High",
    roadmap: [
      { step: 1, title: "Foundations", goal: "Build software engineering and ML fundamentals", skills: ["Python", "Git", "Linux basics", "ML basics"], activity: "Build and deploy a basic ML model with Flask", duration: "6 weeks" },
      { step: 2, title: "Containerisation", goal: "Learn Docker and Kubernetes", skills: ["Docker", "Kubernetes basics", "Container orchestration"], activity: "Containerise an ML model and deploy with Docker Compose", duration: "4–6 weeks" },
      { step: 3, title: "ML Pipelines", goal: "Build automated ML pipelines", skills: ["Airflow / Prefect", "Feature stores", "DVC", "MLflow"], activity: "Build an end-to-end automated training pipeline", duration: "6–8 weeks" },
      { step: 4, title: "Cloud Deployment", goal: "Deploy models on cloud platforms", skills: ["AWS SageMaker / GCP Vertex AI", "Model endpoints", "Auto-scaling"], activity: "Deploy a model to a cloud provider with monitoring", duration: "6 weeks" },
      { step: 5, title: "Monitoring & Reliability", goal: "Ensure models perform reliably in production", skills: ["Data drift detection", "Alerting", "A/B model testing"], activity: "Set up a model monitoring dashboard", duration: "4 weeks" },
      { step: 6, title: "Career Preparation", goal: "Land an MLOps or ML engineer role", skills: ["Portfolio", "System design", "Cloud certifications"], activity: "Complete an MLOps capstone project end-to-end", duration: "4 weeks" },
    ],
  },
];

export interface InstitutionData {
  id: string;
  name: string;
  type: string;
  location: string;
  programs: string[];
  relevantCareers: string[];
  rating: number;
  fees: string;
  description: string;
  tags: string[];
}

export const INSTITUTIONS: InstitutionData[] = [
  {
    id: "iit-madras",
    name: "IIT Madras",
    type: "Premier University",
    location: "Chennai, Tamil Nadu",
    programs: ["B.Tech CS", "M.Tech AI", "Data Science", "MBA"],
    relevantCareers: ["ai-ml", "software-dev", "data-analyst", "research-analyst"],
    rating: 4.9,
    fees: "₹2–10 LPA",
    description: "India's top-ranked engineering institution with world-class research facilities and industry connections.",
    tags: ["IIT", "Engineering", "Research", "AI"],
  },
  {
    id: "nid-ahmedabad",
    name: "National Institute of Design",
    type: "Design Institution",
    location: "Ahmedabad, Gujarat",
    programs: ["B.Des UX", "M.Des Interaction Design", "Communication Design"],
    relevantCareers: ["uxui-designer", "digital-marketer", "product-manager"],
    rating: 4.8,
    fees: "₹1.5–4 LPA",
    description: "India's premier design institution known for producing world-class designers across disciplines.",
    tags: ["Design", "UX", "Creativity", "NID"],
  },
  {
    id: "iim-bangalore",
    name: "IIM Bangalore",
    type: "Management Institution",
    location: "Bengaluru, Karnataka",
    programs: ["MBA", "Executive MBA", "Business Analytics", "Entrepreneurship"],
    relevantCareers: ["business-manager", "product-manager", "digital-marketer"],
    rating: 4.9,
    fees: "₹20–25 LPA",
    description: "One of India's top management institutions with exceptional alumni network and placement record.",
    tags: ["MBA", "Management", "Leadership", "IIM"],
  },
  {
    id: "bits-pilani",
    name: "BITS Pilani",
    type: "University",
    location: "Pilani, Rajasthan",
    programs: ["B.E. CS", "M.S. Software Systems", "Data Science", "MBA Tech"],
    relevantCareers: ["software-dev", "ai-ml", "data-analyst"],
    rating: 4.7,
    fees: "₹4–8 LPA",
    description: "Leading private engineering institution with dual-degree programs and strong industry partnerships.",
    tags: ["Engineering", "Technology", "Private University"],
  },
  {
    id: "psg-tech",
    name: "PSG College of Technology",
    type: "Engineering College",
    location: "Coimbatore, Tamil Nadu",
    programs: ["B.E. CS", "B.Tech AI & DS", "M.E. Software Engg", "MCA"],
    relevantCareers: ["software-dev", "ai-ml", "data-analyst"],
    rating: 4.5,
    fees: "₹0.8–2 LPA",
    description: "Reputed autonomous engineering institution in Coimbatore with excellent placement records in top IT companies.",
    tags: ["Engineering", "Autonomous", "Coimbatore", "IT"],
  },
  {
    id: "srm-university",
    name: "SRM University",
    type: "Private University",
    location: "Chennai, Tamil Nadu",
    programs: ["B.Tech CS", "AI & ML", "Data Science", "Design"],
    relevantCareers: ["ai-ml", "software-dev", "uxui-designer", "data-analyst"],
    rating: 4.3,
    fees: "₹2–5 LPA",
    description: "Large private university offering diverse programs with modern infrastructure and active industry collaborations.",
    tags: ["Private University", "Technology", "Design"],
  },
  {
    id: "symbiosis",
    name: "Symbiosis International University",
    type: "Private University",
    location: "Pune, Maharashtra",
    programs: ["MBA", "BBA", "Digital Marketing", "Communication"],
    relevantCareers: ["business-manager", "digital-marketer", "product-manager"],
    rating: 4.4,
    fees: "₹3–12 LPA",
    description: "Internationally recognised university with strong business, communication, and management programs.",
    tags: ["Management", "Communication", "International"],
  },
  {
    id: "lpu",
    name: "Lovely Professional University",
    type: "Private University",
    location: "Phagwara, Punjab",
    programs: ["B.Tech CS", "BCA", "MCA", "MBA", "B.Des"],
    relevantCareers: ["software-dev", "uxui-designer", "business-manager"],
    rating: 4.1,
    fees: "₹1.5–4 LPA",
    description: "One of India's largest private universities with diverse programs and 100% placement assistance.",
    tags: ["Private", "Placement", "Diverse Programs"],
  },
];

export interface AcademyData {
  id: string;
  name: string;
  course: string;
  skills: string[];
  mode: "Online" | "Offline" | "Hybrid";
  duration: string;
  level: "Beginner" | "Intermediate" | "Advanced";
  relevantCareers: string[];
  rating: number;
  price: string;
  description: string;
  provider: string;
  tags: string[];
}

export const ACADEMIES: AcademyData[] = [
  {
    id: "coursera-ml",
    name: "Coursera",
    course: "Machine Learning Specialization",
    skills: ["Python", "ML algorithms", "Neural networks", "TensorFlow"],
    mode: "Online",
    duration: "3 months",
    level: "Intermediate",
    relevantCareers: ["ai-ml", "data-analyst", "software-dev"],
    rating: 4.9,
    price: "₹3,999/month",
    description: "Andrew Ng's world-famous ML course — the gold standard for learning machine learning fundamentals.",
    provider: "Andrew Ng / DeepLearning.AI",
    tags: ["Coursera", "ML", "AI", "Certificate"],
  },
  {
    id: "udemy-webdev",
    name: "Udemy",
    course: "The Complete Web Developer Bootcamp",
    skills: ["HTML/CSS", "JavaScript", "React", "Node.js", "MongoDB"],
    mode: "Online",
    duration: "6 months",
    level: "Beginner",
    relevantCareers: ["software-dev", "uxui-designer"],
    rating: 4.7,
    price: "₹499 (lifetime)",
    description: "Comprehensive web development bootcamp covering front-end to back-end with real project builds.",
    provider: "Dr. Angela Yu",
    tags: ["Udemy", "Web Dev", "Full Stack", "Beginner"],
  },
  {
    id: "google-ux",
    name: "Google",
    course: "Google UX Design Professional Certificate",
    skills: ["UX research", "Wireframing", "Figma", "Prototyping", "Usability testing"],
    mode: "Online",
    duration: "6 months",
    level: "Beginner",
    relevantCareers: ["uxui-designer", "product-manager"],
    rating: 4.8,
    price: "₹3,999/month",
    description: "Google's official UX design program covering the entire design process from research to hi-fi prototype.",
    provider: "Google on Coursera",
    tags: ["Google", "UX", "Design", "Certificate"],
  },
  {
    id: "upgrad-data",
    name: "upGrad",
    course: "PG Program in Data Science",
    skills: ["Python", "SQL", "Machine Learning", "Tableau", "NLP"],
    mode: "Online",
    duration: "12 months",
    level: "Intermediate",
    relevantCareers: ["data-analyst", "ai-ml", "research-analyst"],
    rating: 4.5,
    price: "₹1.6 LPA",
    description: "Industry-aligned postgraduate program in data science with mentorship from top data professionals.",
    provider: "upGrad + Liverpool John Moores University",
    tags: ["upGrad", "PG Diploma", "Data Science", "Mentored"],
  },
  {
    id: "iim-digital-mkt",
    name: "IIM Skills",
    course: "Digital Marketing Master Course",
    skills: ["SEO", "Google Ads", "Social Media", "Email Marketing", "Analytics"],
    mode: "Online",
    duration: "3 months",
    level: "Beginner",
    relevantCareers: ["digital-marketer", "business-manager"],
    rating: 4.6,
    price: "₹34,900",
    description: "Comprehensive digital marketing course with live projects, tools access, and industry certification.",
    provider: "IIM Skills",
    tags: ["IIM Skills", "Marketing", "Certificate", "Live Projects"],
  },
  {
    id: "brandmonk-ux",
    name: "Brand Monk Academy",
    course: "UX Design Masterclass",
    skills: ["Design thinking", "Figma", "UX Research", "Case Studies"],
    mode: "Offline",
    duration: "3 months",
    level: "Beginner",
    relevantCareers: ["uxui-designer", "product-manager"],
    rating: 4.8,
    price: "₹45,000",
    description: "Hands-on UX design masterclass with real client projects and portfolio mentorship in Coimbatore.",
    provider: "Brand Monk Academy, Coimbatore",
    tags: ["Offline", "Coimbatore", "UX", "Portfolio"],
  },
  {
    id: "simplilearn-pm",
    name: "Simplilearn",
    course: "Product Management Certification",
    skills: ["Product strategy", "Agile", "Roadmapping", "Analytics", "User research"],
    mode: "Online",
    duration: "4 months",
    level: "Intermediate",
    relevantCareers: ["product-manager", "business-manager", "software-dev"],
    rating: 4.4,
    price: "₹49,999",
    description: "Industry-recognised PM certification with case studies, tools practice, and interview preparation.",
    provider: "Simplilearn + Purdue University",
    tags: ["Simplilearn", "Product", "Certificate", "Agile"],
  },
  {
    id: "nptel-research",
    name: "NPTEL",
    course: "Research Methodology & Statistics",
    skills: ["Research design", "Statistics", "SPSS", "Report writing"],
    mode: "Online",
    duration: "8 weeks",
    level: "Beginner",
    relevantCareers: ["research-analyst", "data-analyst"],
    rating: 4.5,
    price: "Free (Exam: ₹1,000)",
    description: "IIT/NIT faculty-led free online courses on research methodology with verified NPTEL certification.",
    provider: "NPTEL / IIT Faculty",
    tags: ["Free", "NPTEL", "Research", "IIT"],
  },
];
