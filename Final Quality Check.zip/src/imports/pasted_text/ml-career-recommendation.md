============================================================
MACHINE LEARNING — CORE MVP FEATURE
============================================================

SkillBridgeAI must use a MACHINE LEARNING-BASED CAREER
RECOMMENDATION SYSTEM.

Do NOT make the career recommendation purely rule-based.

The ML system should learn from the user's assessment profile,
including:

- Interest responses
- Category preferences
- Scenario-based responses
- Rate-yourself scores
- Skill confidence
- Activity preferences
- User category
- Selected career interests
- Assessment behaviour

Create a structured feature vector from these inputs.

Example features:

interest_technology
interest_design
interest_business
interest_data
interest_science
interest_communication

creativity_score
analytical_score
communication_score
leadership_score
problem_solving_score
technical_confidence
teamwork_score

coding_preference
design_preference
research_preference
people_orientation
business_orientation

============================================================
ML PIPELINE
============================================================

USER ASSESSMENT
       ↓
DATA COLLECTION
       ↓
FEATURE EXTRACTION
       ↓
FEATURE NORMALIZATION
       ↓
ML CAREER RECOMMENDATION MODEL
       ↓
CAREER PROBABILITY / MATCH SCORE
       ↓
TOP CAREER RECOMMENDATIONS
       ↓
SKILL GAP ANALYSIS
       ↓
PERSONALIZED ROADMAP

============================================================
MODEL REQUIREMENT
============================================================

For the MVP, implement a lightweight supervised ML approach
suitable for structured assessment data.

Use a classification or ranking approach to predict
career-category suitability.

Possible career categories:

- AI / Machine Learning
- Software Development
- Data Analytics
- Cybersecurity
- UI/UX Design
- Business / Management
- Digital Marketing
- Research
- Cloud / DevOps
- Product Management

The model should return multiple career recommendations
ranked by suitability.

Example:

AI / ML Engineer       91%
Data Analyst           86%
Software Developer     81%
Cybersecurity          74%

These percentages must be generated from the model's
prediction/ranking output and must NOT be hard-coded.

============================================================
PERSONALIZATION
============================================================

Different users with different assessment responses
must receive different recommendations.

Do NOT return the same career percentages for every user.

The recommendation engine should process the user's
individual feature vector.

Example:

User A:
High analytical + technical + coding preference
→ AI/ML, Data, Software

User B:
High creativity + visual preference
→ UI/UX, Product Design, Digital Media

User C:
High communication + leadership + business preference
→ Management, Product, Marketing

============================================================
MODEL + DATA
============================================================

For the MVP, create a small structured training dataset
representing assessment profiles mapped to career categories.

Use synthetic/mock training data ONLY for demonstration.

Clearly label it internally as DEMO/TRAINING DATA.

Do NOT claim that the model is trained on real-world
student data unless such data is actually provided.

Keep the ML pipeline modular so a real dataset can replace
the demo dataset later.

============================================================
MODEL OUTPUT
============================================================

The ML model should produce:

1. Top career category
2. Ranked career recommendations
3. Suitability score
4. Confidence indicator
5. Relevant skill requirements

Example:

CAREER MATCH

AI / ML Engineer
91% suitability

Why this career:
- Strong analytical profile
- High technical confidence
- Strong problem-solving preference
- High interest in technology

============================================================
ML → SKILL GAP CONNECTION
============================================================

The ML recommendation must connect directly to
Skill Gap Analysis.

ML Recommended Career
        ↓
Required Skills Dataset
        ↓
Compare with User Skill Profile
        ↓
Skill Gap
        ↓
Personalized Roadmap

Example:

Recommended Career:
AI / ML Engineer

User Skills:
Python — Strong
Statistics — Developing
Machine Learning — Needs Improvement
SQL — Developing

Generate the roadmap based on the identified gaps.

============================================================
MODEL TRANSPARENCY
============================================================

Do not present the ML prediction as a guaranteed career outcome.

Use language such as:

"Based on your assessment"
"Recommended career paths"
"Your profile shows strong alignment with..."

Do not say:

"You are definitely suited for this career."

Provide an understandable explanation of
why a career was recommended.

============================================================
FALLBACK
============================================================

If the ML model cannot run in the current prototype environment,
create a modular ML service interface and use a clearly labelled
DEMO prediction layer temporarily.

The architecture must make it possible to replace the demo
prediction with the trained ML model without redesigning
the application.

DO NOT falsely claim that a production ML model is running
if the environment cannot actually execute it.