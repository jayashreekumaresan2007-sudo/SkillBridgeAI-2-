export type Screen =
  | "splash"
  | "walkthrough"
  | "login"
  | "register"
  | "forgotPassword"
  | "languageCategory"
  | "genderSelect"
  | "avatarSelect"
  | "pathSelect"
  | "assessmentIntro"
  | "assessment"
  | "assessmentComplete"
  | "careerResults"
  | "careerDetail"
  | "skillGap"
  | "roadmap"
  | "institutions"
  | "academies"
  | "clarityCheck"
  | "dashboard"
  | "profile"
  | "saved";

export interface AssessmentAnswers {
  interests: string[];
  activity: string;
  projectType: string;
  scenario: string;
  goal: string;
  ratings: {
    communication: number;
    problemSolving: number;
    creativity: number;
    leadership: number;
    analytical: number;
    technical: number;
    teamwork: number;
  };
}

export interface CareerRecommendation {
  id: string;
  title: string;
  matchScore: number;
  reasons: string[];
  domain: string;
  emoji: string;
  color: string;
}

export interface SkillGapItem {
  skill: string;
  userLevel: number;
  requiredLevel: number;
  status: "strong" | "developing" | "needs-improvement";
}

export interface RoadmapStep {
  step: number;
  title: string;
  goal: string;
  skills: string[];
  activity: string;
  duration: string;
}

export interface UserProfile {
  name: string;
  email: string;
  language: string;
  userCategory: string;
  gender: string;
  avatar: number;
  path: string;
  isGuest: boolean;
}

export interface AppState {
  screen: Screen;
  screenHistory: Screen[];
  isDark: boolean;
  language: import("./i18n").Language;
  user: UserProfile | null;
  assessmentAnswers: AssessmentAnswers;
  assessmentCurrentQ: number;
  careerRecommendations: CareerRecommendation[];
  selectedCareerId: string;
  skillGaps: SkillGapItem[];
  roadmapProgress: boolean[];
  savedCareers: string[];
  savedInstitutions: string[];
  savedAcademies: string[];
  clarityAnswers: number[];
  clarityScore: number;
  streak: number;
  dailyProgress: number;
}
