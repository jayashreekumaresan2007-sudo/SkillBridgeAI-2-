import { useState } from "react";

interface ClarityCheckProps {
  isDark: boolean;
  onComplete: (score: number, answers: number[]) => void;
  onBack: () => void;
}

const QUESTIONS = [
  {
    id: 0,
    question: "How clear are you about your career direction now?",
    labels: ["Very unclear", "Slightly unclear", "Somewhat clear", "Clear", "Very clear"],
  },
  {
    id: 1,
    question: "Do you understand which skills you need to develop?",
    labels: ["Not at all", "Slightly", "Somewhat", "Mostly yes", "Definitely yes"],
  },
  {
    id: 2,
    question: "Do you know which career path you want to explore?",
    labels: ["Very confused", "Still unsure", "Getting clearer", "Yes, mostly", "Absolutely yes"],
  },
  {
    id: 3,
    question: "Do you feel confident about your next step?",
    labels: ["Not at all confident", "A little", "Somewhat", "Fairly confident", "Very confident"],
  },
];

export function ClarityCheckScreen({ isDark, onComplete, onBack }: ClarityCheckProps) {
  const [answers, setAnswers] = useState<number[]>([0, 0, 0, 0]);
  const [submitted, setSubmitted] = useState(false);
  const [clarityScore, setClarityScore] = useState(0);

  const bg = isDark ? "#111827" : "#F5F9FF";
  const surface = isDark ? "#1E293B" : "#ffffff";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const textMuted = isDark ? "#94A3B8" : "#64748B";
  const border = isDark ? "#334155" : "#E2E8F0";

  const allAnswered = answers.every((a) => a > 0);

  const handleSubmit = () => {
    const total = answers.reduce((sum, a) => sum + a, 0);
    const maxTotal = QUESTIONS.length * 5;
    const score = Math.round((total / maxTotal) * 100);
    setClarityScore(score);
    setSubmitted(true);
    onComplete(score, answers);
  };

  const getScoreLabel = (score: number) => {
    if (score >= 80) return { label: "High Clarity", color: "#10B981", emoji: "🌟" };
    if (score >= 60) return { label: "Growing Clarity", color: "#146EF5", emoji: "📈" };
    if (score >= 40) return { label: "Developing", color: "#F59E0B", emoji: "🔄" };
    return { label: "Early Stage", color: "#EF4444", emoji: "🌱" };
  };

  const getMessage = (score: number) => {
    if (score >= 80) return "You now have a clear direction and a practical next step. You are ready to take action.";
    if (score >= 60) return "You are building a clearer career direction. Continue exploring and learning.";
    if (score >= 40) return "Your career clarity is developing. Keep exploring your interests and skills.";
    return "Career clarity takes time. Continue your journey and revisit this check as you progress.";
  };

  if (submitted) {
    const { label, color, emoji } = getScoreLabel(clarityScore);
    const r = (56 - 8) / 2;
    const circ = 2 * Math.PI * r;
    const dash = (clarityScore / 100) * circ;

    return (
      <div className="flex-1 flex flex-col items-center justify-center px-6" style={{ background: bg }}>
        <div className="w-full max-w-sm">
          {/* Score display */}
          <div className="flex flex-col items-center mb-8">
            <div className="relative mb-4">
              <svg width="140" height="140" viewBox="0 0 140 140">
                <circle cx="70" cy="70" r="56" fill="none" stroke={isDark ? "#1E293B" : "#E2E8F0"} strokeWidth="10" />
                <circle
                  cx="70" cy="70" r="56"
                  fill="none"
                  stroke={color}
                  strokeWidth="10"
                  strokeDasharray={`${dash} ${circ}`}
                  strokeDashoffset={circ / 4}
                  strokeLinecap="round"
                />
                <text x="70" y="58" textAnchor="middle" fontSize="28" fontWeight="800" fill={color}>{clarityScore}%</text>
                <text x="70" y="78" textAnchor="middle" fontSize="11" fill={textMuted}>CAREER</text>
                <text x="70" y="92" textAnchor="middle" fontSize="11" fill={textMuted}>CLARITY</text>
              </svg>
            </div>

            <span className="text-2xl mb-2">{emoji}</span>
            <h2 className="text-xl font-extrabold mb-2" style={{ color: textMain }}>{label}</h2>
            <p className="text-sm text-center leading-relaxed" style={{ color: textMuted }}>
              {getMessage(clarityScore)}
            </p>
          </div>

          {/* Per-question summary */}
          <div className="rounded-2xl p-4 mb-6 space-y-3" style={{ background: surface }}>
            <h3 className="text-xs font-bold mb-2" style={{ color: textMain }}>Your Responses</h3>
            {QUESTIONS.map((q, i) => (
              <div key={q.id} className="flex items-center gap-3">
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((v) => (
                    <div
                      key={v}
                      className="w-4 h-4 rounded-sm"
                      style={{ background: answers[i] >= v ? color : isDark ? "#334155" : "#E2E8F0" }}
                    />
                  ))}
                </div>
                <span className="text-[10px] leading-tight" style={{ color: textMuted }}>{q.question.slice(0, 35)}…</span>
              </div>
            ))}
          </div>

          <div className="rounded-2xl p-3 mb-6" style={{ background: isDark ? "#1E293B" : "#EAF2FF" }}>
            <p className="text-[10px] text-center" style={{ color: textMuted }}>
              This is a self-reported clarity indicator, not a scientifically validated score. Use it as a reflection tool.
            </p>
          </div>

          <button
            className="w-full py-4 rounded-2xl text-white font-bold text-base transition-all active:scale-95"
            style={{ background: "#146EF5" }}
            onClick={() => onComplete(clarityScore, answers)}
          >
            Go to My Dashboard →
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-y-auto scrollbar-hide" style={{ background: bg }}>
      <div className="px-5 pt-5 pb-2 flex items-center justify-between">
        <button onClick={onBack} className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: isDark ? "#1E293B" : "#ffffff" }}>
          <span style={{ color: textMain }}>←</span>
        </button>
        <h2 className="text-base font-bold" style={{ color: textMain }}>Career Clarity Check</h2>
        <div className="w-9" />
      </div>

      <div className="px-5 pb-6 flex-1">
        <div className="text-center mb-6">
          <span className="text-4xl block mb-2">🧭</span>
          <p className="text-sm leading-relaxed" style={{ color: textMuted }}>
            Rate how you feel right now. This helps track your career clarity progress.
          </p>
        </div>

        <div className="space-y-5">
          {QUESTIONS.map((q, i) => (
            <div key={q.id} className="rounded-2xl p-4" style={{ background: surface, border: `1px solid ${border}` }}>
              <p className="text-sm font-semibold mb-3 leading-snug" style={{ color: textMain }}>{q.question}</p>

              {/* Rating buttons */}
              <div className="flex gap-1.5 mb-2">
                {[1, 2, 3, 4, 5].map((val) => (
                  <button
                    key={val}
                    className="flex-1 h-10 rounded-lg text-sm font-bold border-2 transition-all duration-200 active:scale-90"
                    style={{
                      borderColor: answers[i] >= val ? "#146EF5" : border,
                      background: answers[i] >= val ? "#146EF5" : (isDark ? "#334155" : "#F5F9FF"),
                      color: answers[i] >= val ? "#ffffff" : textMuted,
                    }}
                    onClick={() => {
                      const next = [...answers];
                      next[i] = val;
                      setAnswers(next);
                    }}
                  >
                    {val}
                  </button>
                ))}
              </div>
              {answers[i] > 0 && (
                <p className="text-[10px] text-center font-medium" style={{ color: "#146EF5" }}>
                  {q.labels[answers[i] - 1]}
                </p>
              )}
            </div>
          ))}
        </div>

        <div className="pt-4 pb-4">
          <button
            className="w-full py-4 rounded-2xl text-white font-bold text-base transition-all active:scale-95 disabled:opacity-40"
            style={{ background: "#146EF5" }}
            disabled={!allAnswered}
            onClick={handleSubmit}
          >
            See My Clarity Score →
          </button>
        </div>
      </div>
    </div>
  );
}
