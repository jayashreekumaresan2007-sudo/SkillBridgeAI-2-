import { useState } from "react";
import { INSTITUTIONS, ACADEMIES, CAREERS } from "../data";
import type { InstitutionData, AcademyData } from "../data";

// ─── Institutions ───────────────────────────────────────────────────
interface InstitutionsProps {
  isDark: boolean;
  careerId: string;
  savedInstitutions: string[];
  onToggleSave: (id: string) => void;
  onContinue: () => void;
  onBack: () => void;
}

export function InstitutionsScreen({ isDark, careerId, savedInstitutions, onToggleSave, onContinue, onBack }: InstitutionsProps) {
  const career = CAREERS.find((c) => c.id === careerId) ?? CAREERS[0];
  const [filter, setFilter] = useState<"all" | "relevant">("relevant");
  const [typeFilter, setTypeFilter] = useState("All");

  const bg = isDark ? "#111827" : "#F5F9FF";
  const surface = isDark ? "#1E293B" : "#ffffff";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const textMuted = isDark ? "#94A3B8" : "#64748B";
  const border = isDark ? "#334155" : "#E2E8F0";

  const types = ["All", "Premier University", "Design Institution", "Management Institution", "University", "Engineering College", "Private University"];

  const filtered = INSTITUTIONS.filter((inst) => {
    const relevantMatch = filter === "all" || inst.relevantCareers.includes(careerId);
    const typeMatch = typeFilter === "All" || inst.type === typeFilter;
    return relevantMatch && typeMatch;
  });

  return (
    <div className="flex-1 flex flex-col overflow-y-auto scrollbar-hide" style={{ background: bg }}>
      {/* Header */}
      <div className="px-5 pt-5 pb-2 flex items-center justify-between">
        <button onClick={onBack} className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: isDark ? "#1E293B" : "#ffffff" }}>
          <span style={{ color: textMain }}>←</span>
        </button>
        <h2 className="text-base font-bold" style={{ color: textMain }}>Institutions</h2>
        <div className="w-9" />
      </div>

      <div className="px-5 pb-6 space-y-4">
        {/* Context */}
        <div className="rounded-xl p-3" style={{ background: surface, border: `1px solid ${border}` }}>
          <p className="text-xs" style={{ color: textMuted }}>
            Showing institutions relevant to <strong style={{ color: "#146EF5" }}>{career.title}</strong> and your profile.
          </p>
          <p className="text-[10px] mt-0.5" style={{ color: textMuted }}>
            Mock data for demonstration. Always verify with institution directly.
          </p>
        </div>

        {/* Filter toggle */}
        <div className="flex gap-2">
          {(["relevant", "all"] as const).map((f) => (
            <button
              key={f}
              className="px-4 py-2 rounded-full text-xs font-semibold transition-all"
              style={{
                background: filter === f ? "#146EF5" : (isDark ? "#1E293B" : "#E2E8F0"),
                color: filter === f ? "#ffffff" : textMuted,
              }}
              onClick={() => setFilter(f)}
            >
              {f === "relevant" ? "Best Matches" : "All Institutions"}
            </button>
          ))}
        </div>

        {/* Type filter scroll */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
          {types.map((t) => (
            <button
              key={t}
              className="shrink-0 px-3 py-1.5 rounded-full text-[11px] font-medium transition-all border"
              style={{
                background: typeFilter === t ? "#EAF2FF" : "transparent",
                borderColor: typeFilter === t ? "#146EF5" : border,
                color: typeFilter === t ? "#146EF5" : textMuted,
              }}
              onClick={() => setTypeFilter(t)}
            >
              {t}
            </button>
          ))}
        </div>

        {/* Results */}
        {filtered.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-4xl mb-3">🏫</p>
            <p className="text-sm font-semibold" style={{ color: textMain }}>No institutions found</p>
            <p className="text-xs mt-1" style={{ color: textMuted }}>Try changing your filters</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map((inst) => (
              <InstitutionCard
                key={inst.id}
                inst={inst}
                careerId={careerId}
                saved={savedInstitutions.includes(inst.id)}
                onToggleSave={onToggleSave}
                isDark={isDark}
                textMain={textMain}
                textMuted={textMuted}
                surface={surface}
                border={border}
              />
            ))}
          </div>
        )}

        <button
          className="w-full py-4 rounded-2xl text-white font-bold text-base transition-all active:scale-95"
          style={{ background: "#146EF5" }}
          onClick={onContinue}
        >
          Explore Academies →
        </button>
      </div>
    </div>
  );
}

function InstitutionCard({
  inst, careerId, saved, onToggleSave, isDark, textMain, textMuted, surface, border,
}: {
  inst: InstitutionData;
  careerId: string;
  saved: boolean;
  onToggleSave: (id: string) => void;
  isDark: boolean;
  textMain: string;
  textMuted: string;
  surface: string;
  border: string;
}) {
  const isRelevant = inst.relevantCareers.includes(careerId);
  return (
    <div className="rounded-2xl p-4" style={{ background: surface, border: `1px solid ${border}` }}>
      <div className="flex items-start justify-between mb-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm font-bold" style={{ color: textMain }}>{inst.name}</span>
            {isRelevant && (
              <span className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold" style={{ background: "#EAF2FF", color: "#146EF5" }}>
                Relevant
              </span>
            )}
          </div>
          <p className="text-xs mt-0.5" style={{ color: textMuted }}>{inst.type} · {inst.location}</p>
        </div>
        <button onClick={() => onToggleSave(inst.id)} className="ml-2 shrink-0">
          <span className="text-lg">{saved ? "🔖" : "🏷️"}</span>
        </button>
      </div>

      <p className="text-xs leading-relaxed mb-3" style={{ color: textMuted }}>{inst.description}</p>

      {/* Programs */}
      <div className="flex flex-wrap gap-1.5 mb-3">
        {inst.programs.slice(0, 4).map((p) => (
          <span key={p} className="text-[10px] px-2 py-0.5 rounded-full font-medium" style={{ background: isDark ? "#334155" : "#F1F5F9", color: textMain }}>
            {p}
          </span>
        ))}
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1">
            <span className="text-yellow-400 text-xs">★</span>
            <span className="text-xs font-semibold" style={{ color: textMain }}>{inst.rating}</span>
          </div>
          <span className="text-xs" style={{ color: "#146EF5" }}>{inst.fees}</span>
        </div>
        <button className="text-xs font-semibold px-3 py-1.5 rounded-full" style={{ background: "#EAF2FF", color: "#146EF5" }}>
          View Details →
        </button>
      </div>
    </div>
  );
}

// ─── Academies ────────────────────────────────────────────────────
interface AcademiesProps {
  isDark: boolean;
  careerId: string;
  savedAcademies: string[];
  onToggleSave: (id: string) => void;
  onContinue: () => void;
  onBack: () => void;
}

export function AcademiesScreen({ isDark, careerId, savedAcademies, onToggleSave, onContinue, onBack }: AcademiesProps) {
  const career = CAREERS.find((c) => c.id === careerId) ?? CAREERS[0];
  const [filter, setFilter] = useState<"all" | "relevant">("relevant");
  const [modeFilter, setModeFilter] = useState("All");
  const [levelFilter, setLevelFilter] = useState("All");

  const bg = isDark ? "#111827" : "#F5F9FF";
  const surface = isDark ? "#1E293B" : "#ffffff";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const textMuted = isDark ? "#94A3B8" : "#64748B";
  const border = isDark ? "#334155" : "#E2E8F0";

  const modes = ["All", "Online", "Offline", "Hybrid"];
  const levels = ["All", "Beginner", "Intermediate", "Advanced"];

  const filtered = ACADEMIES.filter((a) => {
    const relevant = filter === "all" || a.relevantCareers.includes(careerId);
    const modeOk = modeFilter === "All" || a.mode === modeFilter;
    const levelOk = levelFilter === "All" || a.level === levelFilter;
    return relevant && modeOk && levelOk;
  });

  return (
    <div className="flex-1 flex flex-col overflow-y-auto scrollbar-hide" style={{ background: bg }}>
      {/* Header */}
      <div className="px-5 pt-5 pb-2 flex items-center justify-between">
        <button onClick={onBack} className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: isDark ? "#1E293B" : "#ffffff" }}>
          <span style={{ color: textMain }}>←</span>
        </button>
        <h2 className="text-base font-bold" style={{ color: textMain }}>Learning Academies</h2>
        <div className="w-9" />
      </div>

      <div className="px-5 pb-6 space-y-4">
        {/* Context */}
        <div className="rounded-xl p-3" style={{ background: surface, border: `1px solid ${border}` }}>
          <p className="text-xs" style={{ color: textMuted }}>
            Courses and academies relevant to <strong style={{ color: "#146EF5" }}>{career.title}</strong>. Mock data only — verify course details independently.
          </p>
        </div>

        {/* Filter toggle */}
        <div className="flex gap-2">
          {(["relevant", "all"] as const).map((f) => (
            <button
              key={f}
              className="px-4 py-2 rounded-full text-xs font-semibold transition-all"
              style={{
                background: filter === f ? "#146EF5" : (isDark ? "#1E293B" : "#E2E8F0"),
                color: filter === f ? "#ffffff" : textMuted,
              }}
              onClick={() => setFilter(f)}
            >
              {f === "relevant" ? "Best Matches" : "All Courses"}
            </button>
          ))}
        </div>

        {/* Mode filter */}
        <div>
          <p className="text-[10px] font-semibold mb-1.5" style={{ color: textMuted }}>Mode</p>
          <div className="flex gap-2 overflow-x-auto scrollbar-hide">
            {modes.map((m) => (
              <button
                key={m}
                className="shrink-0 px-3 py-1.5 rounded-full text-[11px] font-medium transition-all border"
                style={{
                  background: modeFilter === m ? "#EAF2FF" : "transparent",
                  borderColor: modeFilter === m ? "#146EF5" : border,
                  color: modeFilter === m ? "#146EF5" : textMuted,
                }}
                onClick={() => setModeFilter(m)}
              >
                {m}
              </button>
            ))}
          </div>
        </div>

        {/* Level filter */}
        <div>
          <p className="text-[10px] font-semibold mb-1.5" style={{ color: textMuted }}>Level</p>
          <div className="flex gap-2 overflow-x-auto scrollbar-hide">
            {levels.map((l) => (
              <button
                key={l}
                className="shrink-0 px-3 py-1.5 rounded-full text-[11px] font-medium transition-all border"
                style={{
                  background: levelFilter === l ? "#EAF2FF" : "transparent",
                  borderColor: levelFilter === l ? "#146EF5" : border,
                  color: levelFilter === l ? "#146EF5" : textMuted,
                }}
                onClick={() => setLevelFilter(l)}
              >
                {l}
              </button>
            ))}
          </div>
        </div>

        {/* Results */}
        {filtered.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-4xl mb-3">📚</p>
            <p className="text-sm font-semibold" style={{ color: textMain }}>No academies found</p>
            <p className="text-xs mt-1" style={{ color: textMuted }}>Try changing your filters</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map((academy) => (
              <AcademyCard
                key={academy.id}
                academy={academy}
                careerId={careerId}
                saved={savedAcademies.includes(academy.id)}
                onToggleSave={onToggleSave}
                isDark={isDark}
                textMain={textMain}
                textMuted={textMuted}
                surface={surface}
                border={border}
              />
            ))}
          </div>
        )}

        <button
          className="w-full py-4 rounded-2xl text-white font-bold text-base transition-all active:scale-95"
          style={{ background: "#146EF5" }}
          onClick={onContinue}
        >
          Career Clarity Check →
        </button>
      </div>
    </div>
  );
}

function AcademyCard({
  academy, careerId, saved, onToggleSave, isDark, textMain, textMuted, surface, border,
}: {
  academy: AcademyData;
  careerId: string;
  saved: boolean;
  onToggleSave: (id: string) => void;
  isDark: boolean;
  textMain: string;
  textMuted: string;
  surface: string;
  border: string;
}) {
  const isRelevant = academy.relevantCareers.includes(careerId);
  const modeColors: Record<string, { bg: string; color: string }> = {
    Online: { bg: "#EAF2FF", color: "#146EF5" },
    Offline: { bg: "#ECFDF5", color: "#059669" },
    Hybrid: { bg: "#FEF3C7", color: "#D97706" },
  };
  const modeStyle = modeColors[academy.mode] ?? modeColors.Online;
  const levelColors: Record<string, string> = { Beginner: "#10B981", Intermediate: "#F59E0B", Advanced: "#EF4444" };

  return (
    <div className="rounded-2xl p-4" style={{ background: surface, border: `1px solid ${border}` }}>
      <div className="flex items-start justify-between mb-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-bold" style={{ color: "#146EF5" }}>{academy.name}</span>
            {isRelevant && (
              <span className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold" style={{ background: "#EAF2FF", color: "#146EF5" }}>
                Relevant
              </span>
            )}
          </div>
          <p className="text-sm font-bold mt-0.5 leading-tight" style={{ color: textMain }}>{academy.course}</p>
          <p className="text-xs mt-0.5" style={{ color: textMuted }}>{academy.provider}</p>
        </div>
        <button onClick={() => onToggleSave(academy.id)} className="ml-2 shrink-0">
          <span className="text-lg">{saved ? "🔖" : "🏷️"}</span>
        </button>
      </div>

      {/* Skills */}
      <div className="flex flex-wrap gap-1 mb-3">
        {academy.skills.slice(0, 4).map((s) => (
          <span key={s} className="text-[10px] px-2 py-0.5 rounded-full" style={{ background: isDark ? "#334155" : "#F1F5F9", color: textMuted }}>
            {s}
          </span>
        ))}
      </div>

      {/* Details row */}
      <div className="flex items-center gap-2 flex-wrap mb-3">
        <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold" style={modeStyle}>{academy.mode}</span>
        <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold" style={{ background: isDark ? "#334155" : "#F1F5F9", color: levelColors[academy.level] ?? textMuted }}>
          {academy.level}
        </span>
        <span className="text-[10px]" style={{ color: textMuted }}>⏱ {academy.duration}</span>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1">
            <span className="text-yellow-400 text-xs">★</span>
            <span className="text-xs font-semibold" style={{ color: textMain }}>{academy.rating}</span>
          </div>
          <span className="text-xs font-bold" style={{ color: "#146EF5" }}>{academy.price}</span>
        </div>
        <button className="text-xs font-semibold px-3 py-1.5 rounded-full" style={{ background: "#EAF2FF", color: "#146EF5" }}>
          View Course →
        </button>
      </div>
    </div>
  );
}

// ─── Saved Screen ──────────────────────────────────────────────────
interface SavedProps {
  isDark: boolean;
  savedCareers: string[];
  savedInstitutions: string[];
  savedAcademies: string[];
  onBack: () => void;
  onViewCareer: (id: string) => void;
}

export function SavedScreen({ isDark, savedCareers, savedInstitutions, savedAcademies, onBack, onViewCareer }: SavedProps) {
  const [tab, setTab] = useState<"careers" | "institutions" | "academies">("careers");

  const bg = isDark ? "#111827" : "#F5F9FF";
  const surface = isDark ? "#1E293B" : "#ffffff";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const textMuted = isDark ? "#94A3B8" : "#64748B";
  const border = isDark ? "#334155" : "#E2E8F0";

  const savedCareerData = CAREERS.filter((c) => savedCareers.includes(c.id));
  const savedInstData = INSTITUTIONS.filter((i) => savedInstitutions.includes(i.id));
  const savedAcadData = ACADEMIES.filter((a) => savedAcademies.includes(a.id));

  const tabs: Array<{ key: typeof tab; label: string; count: number }> = [
    { key: "careers", label: "Careers", count: savedCareers.length },
    { key: "institutions", label: "Institutions", count: savedInstitutions.length },
    { key: "academies", label: "Academies", count: savedAcademies.length },
  ];

  const Empty = ({ msg }: { msg: string }) => (
    <div className="text-center py-12">
      <p className="text-4xl mb-3">🔖</p>
      <p className="text-sm font-semibold" style={{ color: textMain }}>No saved {msg} yet</p>
      <p className="text-xs mt-1" style={{ color: textMuted }}>Bookmark items to find them here</p>
    </div>
  );

  return (
    <div className="flex-1 flex flex-col overflow-y-auto scrollbar-hide" style={{ background: bg }}>
      <div className="px-5 pt-5 pb-2 flex items-center justify-between">
        <button onClick={onBack} className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: isDark ? "#1E293B" : "#ffffff" }}>
          <span style={{ color: textMain }}>←</span>
        </button>
        <h2 className="text-base font-bold" style={{ color: textMain }}>Saved Items</h2>
        <div className="w-9" />
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mx-5 mb-4 p-1 rounded-xl" style={{ background: isDark ? "#1E293B" : "#E2E8F0" }}>
        {tabs.map((t) => (
          <button
            key={t.key}
            className="flex-1 py-2 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1"
            style={{
              background: tab === t.key ? (isDark ? "#0F172A" : "#ffffff") : "transparent",
              color: tab === t.key ? textMain : textMuted,
            }}
            onClick={() => setTab(t.key)}
          >
            {t.label}
            <span
              className="w-4 h-4 rounded-full text-[9px] flex items-center justify-center font-bold"
              style={{ background: tab === t.key ? "#146EF5" : "transparent", color: tab === t.key ? "#ffffff" : textMuted }}
            >
              {t.count}
            </span>
          </button>
        ))}
      </div>

      <div className="px-5 pb-6">
        {tab === "careers" && (
          savedCareerData.length === 0 ? <Empty msg="careers" /> : (
            <div className="space-y-3">
              {savedCareerData.map((c) => (
                <button
                  key={c.id}
                  className="w-full flex items-center gap-3 p-4 rounded-2xl text-left transition-all active:scale-95"
                  style={{ background: surface, border: `1px solid ${border}` }}
                  onClick={() => onViewCareer(c.id)}
                >
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl" style={{ background: c.color + "20" }}>{c.emoji}</div>
                  <div className="flex-1">
                    <p className="text-sm font-bold" style={{ color: textMain }}>{c.title}</p>
                    <p className="text-xs" style={{ color: textMuted }}>{c.domain} · {c.avgSalary}</p>
                  </div>
                  <span style={{ color: textMuted }}>›</span>
                </button>
              ))}
            </div>
          )
        )}

        {tab === "institutions" && (
          savedInstData.length === 0 ? <Empty msg="institutions" /> : (
            <div className="space-y-3">
              {savedInstData.map((inst) => (
                <div key={inst.id} className="p-4 rounded-2xl" style={{ background: surface, border: `1px solid ${border}` }}>
                  <p className="text-sm font-bold" style={{ color: textMain }}>{inst.name}</p>
                  <p className="text-xs mt-0.5" style={{ color: textMuted }}>{inst.type} · {inst.location}</p>
                  <p className="text-xs mt-1" style={{ color: textMuted }}>{inst.fees}</p>
                </div>
              ))}
            </div>
          )
        )}

        {tab === "academies" && (
          savedAcadData.length === 0 ? <Empty msg="academies" /> : (
            <div className="space-y-3">
              {savedAcadData.map((a) => (
                <div key={a.id} className="p-4 rounded-2xl" style={{ background: surface, border: `1px solid ${border}` }}>
                  <p className="text-xs font-bold" style={{ color: "#146EF5" }}>{a.name}</p>
                  <p className="text-sm font-bold mt-0.5" style={{ color: textMain }}>{a.course}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs" style={{ color: textMuted }}>{a.mode}</span>
                    <span className="text-xs" style={{ color: textMuted }}>·</span>
                    <span className="text-xs font-semibold" style={{ color: "#146EF5" }}>{a.price}</span>
                  </div>
                </div>
              ))}
            </div>
          )
        )}
      </div>
    </div>
  );
}
