import { useState } from "react";
import { CAREERS } from "../data";
import type { CareerRecommendation, SkillGapItem, AssessmentAnswers } from "../types";

// ─── Shared helpers ────────────────────────────────────────────────
const pct = (n: number) => `${n}%`;

function MatchRing({ score, color, size = 80 }: { score: number; color: string; size?: number }) {
  const r = (size - 8) / 2;
  const circ = 2 * Math.PI * r;
  const dash = (score / 100) * circ;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(0,0,0,0.06)" strokeWidth="6" />
      <circle
        cx={size / 2} cy={size / 2} r={r}
        fill="none"
        stroke={color}
        strokeWidth="6"
        strokeDasharray={`${dash} ${circ}`}
        strokeDashoffset={circ / 4}
        strokeLinecap="round"
      />
      <text x={size / 2} y={size / 2 + 6} textAnchor="middle" fontSize="14" fontWeight="800" fill={color}>
        {score}%
      </text>
    </svg>
  );
}

// ─── Career Results ────────────────────────────────────────────────
interface CareerResultsProps {
  isDark: boolean;
  recommendations: CareerRecommendation[];
  answers: AssessmentAnswers;
  savedCareers: string[];
  onSelect: (id: string) => void;
  onToggleSave: (id: string) => void;
  onBack: () => void;
  onDashboard: () => void;
}

export function CareerResultsScreen({
  isDark, recommendations, answers, savedCareers, onSelect, onToggleSave, onBack, onDashboard,
}: CareerResultsProps) {
  const bg = isDark ? "#111827" : "#F5F9FF";
  const surface = isDark ? "#1E293B" : "#ffffff";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const textMuted = isDark ? "#94A3B8" : "#64748B";
  const border = isDark ? "#334155" : "#E2E8F0";

  const top = recommendations[0];

  // Strengths derived from ratings
  const strengthLabels: Record<string, string> = {
    communication: "Communication", problemSolving: "Problem Solving",
    creativity: "Creativity", leadership: "Leadership",
    analytical: "Analytical Thinking", technical: "Technical Skills", teamwork: "Teamwork",
  };
  const strengths = Object.entries(answers.ratings)
    .filter(([, v]) => v >= 4)
    .map(([k]) => strengthLabels[k] ?? k)
    .slice(0, 3);

  const topInterests = answers.interests.map((i) => {
    const map: Record<string, string> = {
      technology: "Technology & AI", design: "Design", business: "Business",
      data: "Data & Analytics", science: "Science", communication: "Communication",
    };
    return map[i] ?? i;
  });

  return (
    <div className="flex-1 flex flex-col overflow-y-auto scrollbar-hide" style={{ background: bg }}>
      {/* Header */}
      <div className="px-5 pt-5 pb-2 flex items-center justify-between sticky top-0 z-10" style={{ background: bg }}>
        <button onClick={onBack} className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: isDark ? "#1E293B" : "#ffffff" }}>
          <span style={{ color: textMain }}>←</span>
        </button>
        <h2 className="text-base font-bold" style={{ color: textMain }}>Career Results</h2>
        <button onClick={onDashboard} className="text-xs font-semibold" style={{ color: "#146EF5" }}>Dashboard</button>
      </div>

      <div className="px-5 pb-6 space-y-5">
        {/* Top career hero */}
        {top && (
          <div className="rounded-3xl p-5" style={{ background: top.color + "18", border: `2px solid ${top.color}30` }}>
            <div className="flex items-start justify-between mb-3">
              <div>
                <span className="text-xs font-semibold px-2 py-1 rounded-full" style={{ background: top.color + "25", color: top.color }}>
                  Top Match
                </span>
                <h2 className="text-xl font-extrabold mt-2" style={{ color: textMain }}>{top.emoji} {top.title}</h2>
                <p className="text-xs mt-0.5" style={{ color: textMuted }}>Based on your assessment profile</p>
              </div>
              <MatchRing score={top.matchScore} color={top.color} size={72} />
            </div>
            <div className="space-y-1.5 mt-3">
              {top.reasons.slice(0, 3).map((r, i) => (
                <div key={i} className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: top.color }} />
                  <span className="text-xs" style={{ color: textMuted }}>{r}</span>
                </div>
              ))}
            </div>
            <button
              className="w-full mt-4 py-3 rounded-xl text-white text-sm font-bold transition-all active:scale-95"
              style={{ background: top.color }}
              onClick={() => onSelect(top.id)}
            >
              Explore Career →
            </button>
          </div>
        )}

        {/* Profile summary */}
        <div className="rounded-2xl p-4" style={{ background: surface }}>
          <h3 className="text-sm font-bold mb-3" style={{ color: textMain }}>Your Career Interest Profile</h3>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <p className="text-xs font-semibold mb-1.5" style={{ color: textMuted }}>Strengths</p>
              {strengths.length > 0 ? strengths.map((s) => (
                <div key={s} className="flex items-center gap-1.5 mb-1">
                  <span className="text-green-500 text-xs">✓</span>
                  <span className="text-xs" style={{ color: textMain }}>{s}</span>
                </div>
              )) : <p className="text-xs" style={{ color: textMuted }}>Complete more ratings</p>}
            </div>
            <div>
              <p className="text-xs font-semibold mb-1.5" style={{ color: textMuted }}>Top Interests</p>
              {topInterests.length > 0 ? topInterests.map((i) => (
                <div key={i} className="flex items-center gap-1.5 mb-1">
                  <span className="text-blue-500 text-xs">★</span>
                  <span className="text-xs" style={{ color: textMain }}>{i}</span>
                </div>
              )) : <p className="text-xs" style={{ color: textMuted }}>Complete interests section</p>}
            </div>
          </div>
        </div>

        {/* All recommendations */}
        <div>
          <h3 className="text-sm font-bold mb-3" style={{ color: textMain }}>All Recommended Careers</h3>
          <div className="space-y-3">
            {recommendations.map((rec, i) => (
              <div
                key={rec.id}
                className="rounded-2xl p-4"
                style={{ background: surface, border: `1px solid ${border}` }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl shrink-0" style={{ background: rec.color + "20" }}>
                    {rec.emoji}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-bold" style={{ color: textMain }}>{rec.title}</p>
                      {i === 0 && <span className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold" style={{ background: "#DCFCE7", color: "#059669" }}>Best</span>}
                    </div>
                    <p className="text-xs mt-0.5" style={{ color: textMuted }}>{rec.domain}</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <MatchRing score={rec.matchScore} color={rec.color} size={48} />
                    <button onClick={() => onToggleSave(rec.id)}>
                      <span className="text-lg">{savedCareers.includes(rec.id) ? "🔖" : "🏷️"}</span>
                    </button>
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  <button
                    className="flex-1 py-2 rounded-xl text-xs font-semibold transition-all active:scale-95"
                    style={{ background: rec.color + "15", color: rec.color }}
                    onClick={() => onSelect(rec.id)}
                  >
                    Explore →
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <p className="text-center text-[10px] px-4" style={{ color: textMuted }}>
          Match percentages are AI-assisted recommendations based on your assessment. They are not scientifically validated career predictions.
        </p>
      </div>
    </div>
  );
}

// ─── Career Detail ─────────────────────────────────────────────────
interface CareerDetailProps {
  isDark: boolean;
  careerId: string;
  matchScore: number;
  savedCareers: string[];
  onToggleSave: (id: string) => void;
  onBuildRoadmap: () => void;
  onBack: () => void;
}

export function CareerDetailScreen({ isDark, careerId, matchScore, savedCareers, onToggleSave, onBuildRoadmap, onBack }: CareerDetailProps) {
  const [tab, setTab] = useState<"overview" | "skills" | "growth">("overview");
  const career = CAREERS.find((c) => c.id === careerId) ?? CAREERS[0];

  const bg = isDark ? "#111827" : "#F5F9FF";
  const surface = isDark ? "#1E293B" : "#ffffff";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const textMuted = isDark ? "#94A3B8" : "#64748B";
  const border = isDark ? "#334155" : "#E2E8F0";

  const tabs = ["overview", "skills", "growth"] as const;

  return (
    <div className="flex-1 flex flex-col overflow-y-auto scrollbar-hide" style={{ background: bg }}>
      {/* Header */}
      <div className="px-5 pt-5 pb-4 sticky top-0 z-10" style={{ background: bg }}>
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: isDark ? "#1E293B" : "#ffffff" }}>
            <span style={{ color: textMain }}>←</span>
          </button>
          <button onClick={() => onToggleSave(career.id)}>
            <span className="text-xl">{savedCareers.includes(career.id) ? "🔖" : "🏷️"}</span>
          </button>
        </div>
      </div>

      {/* Hero */}
      <div className="mx-5 rounded-3xl p-5 mb-4" style={{ background: career.color + "18", border: `2px solid ${career.color}30` }}>
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-4xl shrink-0" style={{ background: career.color + "25" }}>
            {career.emoji}
          </div>
          <div className="flex-1">
            <h1 className="text-xl font-extrabold leading-tight" style={{ color: textMain }}>{career.title}</h1>
            <p className="text-xs mt-1" style={{ color: textMuted }}>{career.tagline}</p>
            <div className="flex items-center gap-2 mt-2">
              <span className="text-xs px-2 py-1 rounded-full font-semibold" style={{ background: career.color + "20", color: career.color }}>
                {matchScore}% Match
              </span>
              <span className="text-xs px-2 py-1 rounded-full font-semibold" style={{ background: career.growth === "Very High" ? "#DCFCE7" : "#DBEAFE", color: career.growth === "Very High" ? "#059669" : "#146EF5" }}>
                {career.growth} Growth
              </span>
            </div>
          </div>
        </div>
        <div className="flex gap-2 mt-3">
          <div className="flex-1 rounded-xl py-2 text-center" style={{ background: isDark ? "#1E293B" : "rgba(255,255,255,0.7)" }}>
            <p className="text-xs font-bold" style={{ color: career.color }}>{career.avgSalary}</p>
            <p className="text-[10px]" style={{ color: textMuted }}>Avg. Salary</p>
          </div>
          <div className="flex-1 rounded-xl py-2 text-center" style={{ background: isDark ? "#1E293B" : "rgba(255,255,255,0.7)" }}>
            <p className="text-xs font-bold" style={{ color: career.color }}>{career.domain}</p>
            <p className="text-[10px]" style={{ color: textMuted }}>Domain</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mx-5 mb-4 p-1 rounded-xl" style={{ background: isDark ? "#1E293B" : "#E2E8F0" }}>
        {tabs.map((t) => (
          <button
            key={t}
            className="flex-1 py-2 rounded-lg text-xs font-semibold capitalize transition-all duration-200"
            style={{
              background: tab === t ? (isDark ? "#0F172A" : "#ffffff") : "transparent",
              color: tab === t ? textMain : textMuted,
              boxShadow: tab === t ? "0 1px 4px rgba(0,0,0,0.1)" : "none",
            }}
            onClick={() => setTab(t)}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="px-5 pb-6 space-y-4">
        {tab === "overview" && (
          <>
            <div className="rounded-2xl p-4" style={{ background: surface }}>
              <h3 className="text-sm font-bold mb-2" style={{ color: textMain }}>What this role does</h3>
              <p className="text-xs leading-relaxed" style={{ color: textMuted }}>{career.overview}</p>
            </div>
            <div className="rounded-2xl p-4" style={{ background: surface }}>
              <h3 className="text-sm font-bold mb-3" style={{ color: textMain }}>Key Responsibilities</h3>
              <div className="space-y-2">
                {career.responsibilities.map((r, i) => (
                  <div key={i} className="flex items-start gap-2">
                    <span className="text-xs font-bold mt-0.5" style={{ color: career.color }}>→</span>
                    <span className="text-xs leading-relaxed" style={{ color: textMuted }}>{r}</span>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {tab === "skills" && (
          <>
            <div className="rounded-2xl p-4" style={{ background: surface }}>
              <h3 className="text-sm font-bold mb-3" style={{ color: textMain }}>Technical Skills</h3>
              <div className="flex flex-wrap gap-2">
                {career.technicalSkills.map((s) => (
                  <span key={s} className="text-xs px-2.5 py-1 rounded-full font-medium" style={{ background: career.color + "15", color: career.color }}>
                    {s}
                  </span>
                ))}
              </div>
            </div>
            <div className="rounded-2xl p-4" style={{ background: surface }}>
              <h3 className="text-sm font-bold mb-3" style={{ color: textMain }}>Soft Skills</h3>
              <div className="flex flex-wrap gap-2">
                {career.softSkills.map((s) => (
                  <span key={s} className="text-xs px-2.5 py-1 rounded-full font-medium" style={{ background: isDark ? "#334155" : "#F1F5F9", color: textMain }}>
                    {s}
                  </span>
                ))}
              </div>
            </div>
          </>
        )}

        {tab === "growth" && (
          <>
            <div className="rounded-2xl p-4" style={{ background: surface }}>
              <h3 className="text-sm font-bold mb-3" style={{ color: textMain }}>Entry Level Roles</h3>
              <div className="space-y-2">
                {career.entryRoles.map((r, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <div className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold" style={{ background: career.color + "20", color: career.color }}>{i + 1}</div>
                    <span className="text-xs" style={{ color: textMain }}>{r}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="rounded-2xl p-4" style={{ background: surface }}>
              <h3 className="text-sm font-bold mb-3" style={{ color: textMain }}>Growth Opportunities</h3>
              <div className="space-y-2">
                {career.growthRoles.map((r, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <span className="text-yellow-500 text-xs">⬆</span>
                    <span className="text-xs" style={{ color: textMain }}>{r}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="rounded-2xl p-4" style={{ background: surface }}>
              <h3 className="text-sm font-bold mb-3" style={{ color: textMain }}>Related Careers</h3>
              <div className="flex flex-wrap gap-2">
                {career.relatedCareers.map((r) => (
                  <span key={r} className="text-xs px-3 py-1.5 rounded-full border font-medium" style={{ borderColor: border, color: textMuted }}>
                    {r}
                  </span>
                ))}
              </div>
            </div>
          </>
        )}
      </div>

      {/* CTA */}
      <div className="px-5 pb-8 sticky bottom-0 pt-2" style={{ background: bg }}>
        <button
          className="w-full py-4 rounded-2xl text-white font-bold text-base transition-all active:scale-95"
          style={{ background: "#146EF5" }}
          onClick={onBuildRoadmap}
        >
          Build My Roadmap →
        </button>
      </div>
    </div>
  );
}

// ─── Skill Gap ─────────────────────────────────────────────────────
interface SkillGapProps {
  isDark: boolean;
  careerId: string;
  gaps: SkillGapItem[];
  onContinue: () => void;
  onBack: () => void;
}

export function SkillGapScreen({ isDark, careerId, gaps, onContinue, onBack }: SkillGapProps) {
  const career = CAREERS.find((c) => c.id === careerId) ?? CAREERS[0];

  const bg = isDark ? "#111827" : "#F5F9FF";
  const surface = isDark ? "#1E293B" : "#ffffff";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const textMuted = isDark ? "#94A3B8" : "#64748B";

  const statusConfig = {
    "strong": { label: "Strong", color: "#10B981", bg: "#DCFCE7", emoji: "✅" },
    "developing": { label: "Developing", color: "#F59E0B", bg: "#FEF3C7", emoji: "🔄" },
    "needs-improvement": { label: "Needs Improvement", color: "#EF4444", bg: "#FEE2E2", emoji: "📈" },
  };

  const counts = {
    strong: gaps.filter((g) => g.status === "strong").length,
    developing: gaps.filter((g) => g.status === "developing").length,
    needsImprovement: gaps.filter((g) => g.status === "needs-improvement").length,
  };

  return (
    <div className="flex-1 flex flex-col overflow-y-auto scrollbar-hide" style={{ background: bg }}>
      <div className="px-5 pt-5 pb-2 flex items-center justify-between">
        <button onClick={onBack} className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: isDark ? "#1E293B" : "#ffffff" }}>
          <span style={{ color: textMain }}>←</span>
        </button>
        <h2 className="text-base font-bold" style={{ color: textMain }}>Skill Gap Analysis</h2>
        <div className="w-9" />
      </div>

      <div className="px-5 pb-6 space-y-4 flex-1">
        {/* Career context */}
        <div className="rounded-2xl p-4" style={{ background: surface, borderLeft: `4px solid ${career.color}` }}>
          <p className="text-xs font-semibold mb-0.5" style={{ color: textMuted }}>Analysing skills for</p>
          <p className="text-base font-bold" style={{ color: textMain }}>{career.emoji} {career.title}</p>
          <p className="text-xs mt-1" style={{ color: textMuted }}>
            Comparing your self-rated skills with what this career typically requires
          </p>
        </div>

        {/* Summary */}
        <div className="grid grid-cols-3 gap-2">
          <div className="rounded-xl py-3 text-center" style={{ background: "#DCFCE7" }}>
            <p className="text-xl font-extrabold" style={{ color: "#10B981" }}>{counts.strong}</p>
            <p className="text-[10px] font-semibold" style={{ color: "#059669" }}>Strong</p>
          </div>
          <div className="rounded-xl py-3 text-center" style={{ background: "#FEF3C7" }}>
            <p className="text-xl font-extrabold" style={{ color: "#F59E0B" }}>{counts.developing}</p>
            <p className="text-[10px] font-semibold" style={{ color: "#D97706" }}>Developing</p>
          </div>
          <div className="rounded-xl py-3 text-center" style={{ background: "#FEE2E2" }}>
            <p className="text-xl font-extrabold" style={{ color: "#EF4444" }}>{counts.needsImprovement}</p>
            <p className="text-[10px] font-semibold" style={{ color: "#DC2626" }}>Needs Work</p>
          </div>
        </div>

        {/* Skills */}
        <div className="rounded-2xl p-4 space-y-4" style={{ background: surface }}>
          <h3 className="text-sm font-bold" style={{ color: textMain }}>Skill Comparison</h3>
          {gaps.map((gap) => {
            const cfg = statusConfig[gap.status];
            return (
              <div key={gap.skill}>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-semibold" style={{ color: textMain }}>{gap.skill}</span>
                  <span
                    className="text-[9px] font-semibold px-2 py-0.5 rounded-full"
                    style={{ background: cfg.bg, color: cfg.color }}
                  >
                    {cfg.emoji} {cfg.label}
                  </span>
                </div>
                <div className="relative h-5 rounded-full overflow-hidden" style={{ background: isDark ? "#334155" : "#F1F5F9" }}>
                  {/* Required level line */}
                  <div
                    className="absolute top-0 bottom-0 w-0.5 z-10"
                    style={{ left: `${(gap.requiredLevel / 5) * 100}%`, background: "#CBD5E1" }}
                  />
                  {/* User level bar */}
                  <div
                    className="h-full rounded-full transition-all duration-700"
                    style={{
                      width: `${(gap.userLevel / 5) * 100}%`,
                      background: cfg.color,
                      opacity: 0.8,
                    }}
                  />
                </div>
                <div className="flex justify-between mt-0.5">
                  <span className="text-[9px]" style={{ color: textMuted }}>Your level: {gap.userLevel}/5</span>
                  <span className="text-[9px]" style={{ color: textMuted }}>Required: {gap.requiredLevel}/5</span>
                </div>
              </div>
            );
          })}
        </div>

        <div className="rounded-2xl p-4" style={{ background: isDark ? "#1E293B" : "#EAF2FF" }}>
          <p className="text-xs" style={{ color: textMuted }}>
            <strong style={{ color: textMain }}>What's next?</strong> Your personalized roadmap will focus on developing your gaps while building on your existing strengths.
          </p>
        </div>

        <button
          className="w-full py-4 rounded-2xl text-white font-bold text-base transition-all active:scale-95"
          style={{ background: "#146EF5" }}
          onClick={onContinue}
        >
          View My Roadmap →
        </button>
      </div>
    </div>
  );
}

// ─── Roadmap ───────────────────────────────────────────────────────
interface RoadmapProps {
  isDark: boolean;
  careerId: string;
  progress: boolean[];
  onToggleStep: (i: number) => void;
  onContinue: () => void;
  onBack: () => void;
}

export function RoadmapScreen({ isDark, careerId, progress, onToggleStep, onContinue, onBack }: RoadmapProps) {
  const career = CAREERS.find((c) => c.id === careerId) ?? CAREERS[0];
  const steps = career.roadmap;
  const completedCount = progress.filter(Boolean).length;
  const pctDone = Math.round((completedCount / steps.length) * 100);

  const bg = isDark ? "#111827" : "#F5F9FF";
  const surface = isDark ? "#1E293B" : "#ffffff";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const textMuted = isDark ? "#94A3B8" : "#64748B";

  return (
    <div className="flex-1 flex flex-col overflow-y-auto scrollbar-hide" style={{ background: bg }}>
      <div className="px-5 pt-5 pb-2 flex items-center justify-between">
        <button onClick={onBack} className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: isDark ? "#1E293B" : "#ffffff" }}>
          <span style={{ color: textMain }}>←</span>
        </button>
        <h2 className="text-base font-bold" style={{ color: textMain }}>My Roadmap</h2>
        <div className="w-9" />
      </div>

      <div className="px-5 pb-6 space-y-4">
        {/* Header card */}
        <div className="rounded-2xl p-4" style={{ background: career.color + "18", border: `2px solid ${career.color}30` }}>
          <div className="flex items-center justify-between mb-2">
            <div>
              <p className="text-xs font-semibold" style={{ color: textMuted }}>Roadmap for</p>
              <p className="text-base font-bold" style={{ color: textMain }}>{career.emoji} {career.title}</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-extrabold" style={{ color: career.color }}>{pctDone}%</p>
              <p className="text-[10px]" style={{ color: textMuted }}>Complete</p>
            </div>
          </div>
          <div className="h-2 rounded-full overflow-hidden" style={{ background: "rgba(0,0,0,0.1)" }}>
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{ width: `${pctDone}%`, background: career.color }}
            />
          </div>
          <p className="text-xs mt-1.5" style={{ color: textMuted }}>{completedCount}/{steps.length} steps completed</p>
        </div>

        {/* Steps */}
        <div className="relative">
          {steps.map((step, i) => {
            const done = progress[i] ?? false;
            return (
              <div key={step.step} className="flex gap-4 mb-4">
                {/* Timeline */}
                <div className="flex flex-col items-center">
                  <button
                    className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold border-2 shrink-0 transition-all duration-200 active:scale-90 z-10"
                    style={{
                      borderColor: done ? career.color : isDark ? "#334155" : "#E2E8F0",
                      background: done ? career.color : isDark ? "#1E293B" : "#ffffff",
                      color: done ? "#ffffff" : textMuted,
                    }}
                    onClick={() => onToggleStep(i)}
                  >
                    {done ? "✓" : step.step}
                  </button>
                  {i < steps.length - 1 && (
                    <div className="w-0.5 flex-1 mt-1" style={{ background: done ? career.color : isDark ? "#334155" : "#E2E8F0", minHeight: 32 }} />
                  )}
                </div>

                {/* Content */}
                <div
                  className="flex-1 rounded-2xl p-4 mb-1"
                  style={{
                    background: done ? career.color + "12" : surface,
                    border: `1px solid ${done ? career.color + "30" : isDark ? "#334155" : "#E2E8F0"}`,
                    opacity: done ? 0.85 : 1,
                  }}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className="text-xs font-bold" style={{ color: career.color }}>Step {step.step}</p>
                      <p className="text-sm font-bold mt-0.5" style={{ color: textMain, textDecoration: done ? "line-through" : "none" }}>
                        {step.title}
                      </p>
                      <p className="text-xs mt-1 leading-relaxed" style={{ color: textMuted }}>{step.goal}</p>
                    </div>
                    <span className="text-xs shrink-0 ml-2 px-2 py-0.5 rounded-full" style={{ background: isDark ? "#334155" : "#F1F5F9", color: textMuted }}>
                      {step.duration}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {step.skills.map((s) => (
                      <span key={s} className="text-[10px] px-2 py-0.5 rounded-full font-medium" style={{ background: career.color + "18", color: career.color }}>
                        {s}
                      </span>
                    ))}
                  </div>
                  <p className="text-xs mt-2 italic" style={{ color: textMuted }}>📌 {step.activity}</p>
                </div>
              </div>
            );
          })}
        </div>

        {pctDone === 100 && (
          <div className="rounded-2xl p-4 text-center" style={{ background: "#DCFCE7" }}>
            <p className="text-xl mb-1">🎉</p>
            <p className="text-sm font-bold" style={{ color: "#059669" }}>Roadmap Completed!</p>
            <p className="text-xs mt-1" style={{ color: "#064E3B" }}>You've completed all steps in your roadmap.</p>
          </div>
        )}

        <button
          className="w-full py-4 rounded-2xl text-white font-bold text-base transition-all active:scale-95"
          style={{ background: "#146EF5" }}
          onClick={onContinue}
        >
          Explore Institutions →
        </button>
      </div>
    </div>
  );
}
