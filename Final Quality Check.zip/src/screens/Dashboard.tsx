import { useState } from "react";
import Logo from "../components/Logo";
import { CAREERS, INSTITUTIONS, ACADEMIES, AVATAR_GROUPS } from "../data";
import type { CareerRecommendation, SkillGapItem } from "../types";
import type { Language } from "../i18n";
import { t } from "../i18n";

// ─── Dashboard ────────────────────────────────────────────────────
interface DashboardProps {
  isDark: boolean;
  onToggleDark: () => void;
  language: Language;
  userName: string;
  avatarId: number;
  gender: string;
  careerRecommendations: CareerRecommendation[];
  selectedCareerId: string;
  skillGaps: SkillGapItem[];
  roadmapProgress: boolean[];
  clarityScore: number;
  savedCareers: string[];
  savedInstitutions: string[];
  savedAcademies: string[];
  assessmentDone: boolean;
  streak: number;
  dailyProgress: number;
  onDailyProgress: (p: number) => void;
  // Navigation
  onAssessment: () => void;
  onCareerResults: () => void;
  onCareerDetail: (id: string) => void;
  onSkillGap: () => void;
  onRoadmap: () => void;
  onInstitutions: () => void;
  onAcademies: () => void;
  onClarityCheck: () => void;
  onSaved: () => void;
  onProfile: () => void;
}

export function DashboardScreen({
  isDark, onToggleDark, language, userName, avatarId, gender, careerRecommendations, selectedCareerId,
  skillGaps, roadmapProgress, clarityScore, savedCareers, savedInstitutions, savedAcademies,
  assessmentDone, streak, dailyProgress, onDailyProgress,
  onAssessment, onCareerResults, onCareerDetail, onSkillGap, onRoadmap,
  onInstitutions, onAcademies, onClarityCheck, onSaved, onProfile,
}: DashboardProps) {
  const [activeTab, setActiveTab] = useState<"home" | "explore" | "roadmap" | "progress" | "profile">("home");

  const bg = isDark ? "#0A0F1E" : "#F5F9FF";
  const surface = isDark ? "#111827" : "#ffffff";
  const surfaceEl = isDark ? "#1E293B" : "#F1F5F9";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const textMuted = isDark ? "#94A3B8" : "#64748B";
  const border = isDark ? "#1E293B" : "#E2E8F0";

  const career = CAREERS.find((c) => c.id === selectedCareerId) ?? CAREERS[0];
  const topRec = careerRecommendations[0];
  const completedSteps = roadmapProgress.filter(Boolean).length;
  const roadmapPct = roadmapProgress.length > 0 ? Math.round((completedSteps / roadmapProgress.length) * 100) : 0;
  const strongSkills = skillGaps.filter((g) => g.status === "strong").length;

  const allAvatars = [...AVATAR_GROUPS.male, ...AVATAR_GROUPS.female];
  const avatar = allAvatars.find((a) => a.id === avatarId) ?? allAvatars[0];

  const hour = new Date().getHours();
  const greetingKey = hour < 12 ? "good_morning" : hour < 18 ? "good_afternoon" : "good_evening";
  const greeting = t(greetingKey, language);

  const tabs = [
    { id: "home" as const, icon: "🏠", label: t("home", language) },
    { id: "explore" as const, icon: "🔍", label: t("explore", language) },
    { id: "roadmap" as const, icon: "🗺️", label: language === "English" ? "Roadmap" : t("roadmap", language) },
    { id: "progress" as const, icon: "📈", label: t("progress", language) },
    { id: "profile" as const, icon: "👤", label: t("profile", language) },
  ];

  return (
    <div className="flex-1 flex flex-col" style={{ background: bg }}>
      {/* Main content */}
      <div className="flex-1 overflow-y-auto scrollbar-hide pb-20">
        {activeTab === "home" && (
          <HomeTab
            isDark={isDark} surface={surface} surfaceEl={surfaceEl} textMain={textMain} textMuted={textMuted}
            border={border} bg={bg} greeting={greeting} userName={userName} avatar={avatar}
            assessmentDone={assessmentDone} topRec={topRec} career={career} clarityScore={clarityScore}
            roadmapPct={roadmapPct} completedSteps={completedSteps} roadmapTotal={roadmapProgress.length}
            strongSkills={strongSkills} skillGapsTotal={skillGaps.length} careerRecommendations={careerRecommendations}
            streak={streak} dailyProgress={dailyProgress} onDailyProgress={onDailyProgress}
            onAssessment={onAssessment} onCareerResults={onCareerResults} onCareerDetail={onCareerDetail}
            onSkillGap={onSkillGap} onRoadmap={onRoadmap} onInstitutions={onInstitutions}
            onAcademies={onAcademies} onClarityCheck={onClarityCheck}
          />
        )}
        {activeTab === "explore" && (
          <ExploreTab
            isDark={isDark} surface={surface} textMain={textMain} textMuted={textMuted} border={border} bg={bg}
            onCareerDetail={onCareerDetail} onInstitutions={onInstitutions} onAcademies={onAcademies}
          />
        )}
        {activeTab === "roadmap" && (
          <RoadmapTabInline
            isDark={isDark} surface={surface} surfaceEl={surfaceEl} textMain={textMain} textMuted={textMuted}
            border={border} bg={bg} assessmentDone={assessmentDone} career={career} roadmapPct={roadmapPct}
            completedSteps={completedSteps} roadmapTotal={roadmapProgress.length}
            onRoadmap={onRoadmap} onAssessment={onAssessment}
          />
        )}
        {activeTab === "progress" && (
          <ProgressTabInline
            isDark={isDark} surface={surface} surfaceEl={surfaceEl} textMain={textMain} textMuted={textMuted}
            border={border} bg={bg} assessmentDone={assessmentDone} streak={streak} dailyProgress={dailyProgress}
            onDailyProgress={onDailyProgress} roadmapPct={roadmapPct} completedSteps={completedSteps}
            roadmapTotal={roadmapProgress.length} clarityScore={clarityScore} strongSkills={strongSkills}
            skillGapsTotal={skillGaps.length} onSkillGap={onSkillGap} onClarityCheck={onClarityCheck}
          />
        )}
        {activeTab === "profile" && (
          <ProfileTabInline
            isDark={isDark} onToggleDark={onToggleDark} surface={surface} textMain={textMain} textMuted={textMuted}
            border={border} bg={bg} userName={userName} avatar={avatar} assessmentDone={assessmentDone}
            clarityScore={clarityScore} streak={streak} onProfile={onProfile}
          />
        )}
      </div>

      {/* Bottom nav */}
      <div
        className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[430px] flex items-center border-t"
        style={{ background: surface, borderColor: border }}
      >
        {tabs.map((tab) => (
          <button
            key={tab.id}
            className="flex-1 flex flex-col items-center py-2 gap-0.5 transition-all"
            onClick={() => setActiveTab(tab.id)}
          >
            <span className="text-base" style={{ opacity: activeTab === tab.id ? 1 : 0.5 }}>{tab.icon}</span>
            <span
              className="text-[9px] font-semibold"
              style={{ color: activeTab === tab.id ? "#146EF5" : textMuted }}
            >
              {tab.label}
            </span>
            {activeTab === tab.id && (
              <div className="w-4 h-0.5 rounded-full" style={{ background: "#146EF5" }} />
            )}
          </button>
        ))}
      </div>
    </div>
  );
}

function HomeTab({
  isDark, surface, surfaceEl, textMain, textMuted, border, bg, greeting, userName, avatar,
  assessmentDone, topRec, career, clarityScore, roadmapPct, completedSteps, roadmapTotal,
  strongSkills, skillGapsTotal, careerRecommendations, streak, dailyProgress, onDailyProgress,
  onAssessment, onCareerResults, onCareerDetail, onSkillGap, onRoadmap, onInstitutions, onAcademies, onClarityCheck,
}: any) {
  return (
    <div className="px-5 pt-6 pb-4 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs" style={{ color: textMuted }}>{greeting},</p>
          <h1 className="text-xl font-extrabold" style={{ color: textMain }}>{userName || "Explorer"} 👋</h1>
        </div>
        <div className="flex items-center gap-2">
          {streak > 0 && (
            <div className="flex flex-col items-center px-2 py-1 rounded-xl" style={{ background: isDark ? "#1E293B" : "#FFF7ED" }}>
              <span className="text-base">🔥</span>
              <span className="text-[9px] font-bold" style={{ color: "#F59E0B" }}>{streak}d</span>
            </div>
          )}
          <div
            className="w-12 h-12 rounded-full flex items-center justify-center text-2xl border-2"
            style={{ background: avatar.bg, borderColor: "#146EF5" }}
          >
            {avatar.emoji}
          </div>
        </div>
      </div>

      {/* Daily progress */}
      {assessmentDone && (
        <div className="rounded-2xl p-4" style={{ background: surface }}>
          <div className="flex items-center justify-between mb-2">
            <div>
              <p className="text-xs font-bold" style={{ color: textMain }}>Today's Goal</p>
              <p className="text-[10px]" style={{ color: textMuted }}>Complete Python Functions</p>
            </div>
            <span className="text-sm font-extrabold" style={{ color: "#146EF5" }}>{dailyProgress}%</span>
          </div>
          <div className="h-2 rounded-full overflow-hidden mb-2" style={{ background: isDark ? "#1E293B" : "#EAF2FF" }}>
            <div className="h-full rounded-full transition-all duration-500" style={{ width: `${dailyProgress}%`, background: "linear-gradient(90deg, #146EF5, #6366F1)" }} />
          </div>
          <div className="flex gap-2">
            {[25, 50, 75, 100].map((val) => (
              <button
                key={val}
                className="flex-1 py-1.5 rounded-lg text-[10px] font-semibold transition-all active:scale-95"
                style={{
                  background: dailyProgress >= val ? "#146EF5" : (isDark ? "#1E293B" : "#EAF2FF"),
                  color: dailyProgress >= val ? "#fff" : textMuted,
                }}
                onClick={() => onDailyProgress(val)}
              >
                {val}%
              </button>
            ))}
          </div>
        </div>
      )}

      {/* New user — no assessment */}
      {!assessmentDone && (
        <div className="rounded-3xl p-5 text-white" style={{ background: "linear-gradient(135deg, #146EF5, #0F172A)" }}>
          <p className="text-xs opacity-70 mb-1">Your journey starts here</p>
          <h2 className="text-lg font-extrabold mb-1">Discover your career direction</h2>
          <p className="text-xs opacity-70 mb-4">Complete your assessment to unlock personalized career recommendations.</p>
          <button
            className="w-full py-3 rounded-xl font-bold text-sm transition-all active:scale-95"
            style={{ background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.3)" }}
            onClick={onAssessment}
          >
            Complete Your Assessment →
          </button>
        </div>
      )}

      {/* Assessment done - Career hero */}
      {assessmentDone && topRec && (
        <div
          className="rounded-3xl p-5"
          style={{ background: `linear-gradient(135deg, ${topRec.color}20, ${topRec.color}08)`, border: `2px solid ${topRec.color}25` }}
        >
          <div className="flex items-start justify-between mb-3">
            <div>
              <p className="text-xs font-semibold mb-0.5" style={{ color: textMuted }}>Top Career Match</p>
              <h2 className="text-lg font-extrabold" style={{ color: textMain }}>{topRec.emoji} {topRec.title}</h2>
              <p className="text-xs" style={{ color: textMuted }}>{topRec.domain}</p>
            </div>
            <div>
              <p className="text-3xl font-extrabold" style={{ color: topRec.color }}>{topRec.matchScore}%</p>
              <p className="text-[10px] text-center" style={{ color: textMuted }}>Match</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              className="flex-1 py-2.5 rounded-xl text-white text-xs font-bold transition-all active:scale-95"
              style={{ background: topRec.color }}
              onClick={() => onCareerDetail(topRec.id)}
            >
              Explore Career
            </button>
            <button
              className="flex-1 py-2.5 rounded-xl text-xs font-bold border transition-all active:scale-95"
              style={{ borderColor: topRec.color, color: topRec.color, background: "transparent" }}
              onClick={onCareerResults}
            >
              All Results
            </button>
          </div>
        </div>
      )}

      {/* Stats row */}
      {assessmentDone && (
        <div className="grid grid-cols-3 gap-3">
          <button
            className="flex flex-col items-center py-4 rounded-2xl transition-all active:scale-95"
            style={{ background: surface }}
            onClick={onSkillGap}
          >
            <span className="text-2xl font-extrabold" style={{ color: "#146EF5" }}>{strongSkills}/{skillGapsTotal}</span>
            <span className="text-[10px] text-center mt-0.5 leading-tight" style={{ color: textMuted }}>Skills Strong</span>
          </button>
          <button
            className="flex flex-col items-center py-4 rounded-2xl transition-all active:scale-95"
            style={{ background: surface }}
            onClick={onRoadmap}
          >
            <span className="text-2xl font-extrabold" style={{ color: "#10B981" }}>{roadmapPct}%</span>
            <span className="text-[10px] text-center mt-0.5 leading-tight" style={{ color: textMuted }}>Roadmap</span>
          </button>
          <button
            className="flex flex-col items-center py-4 rounded-2xl transition-all active:scale-95"
            style={{ background: surface }}
            onClick={onClarityCheck}
          >
            <span className="text-2xl font-extrabold" style={{ color: "#F59E0B" }}>{clarityScore > 0 ? `${clarityScore}%` : "—"}</span>
            <span className="text-[10px] text-center mt-0.5 leading-tight" style={{ color: textMuted }}>Clarity</span>
          </button>
        </div>
      )}

      {/* Roadmap progress */}
      {assessmentDone && roadmapTotal > 0 && (
        <div className="rounded-2xl p-4" style={{ background: surface }}>
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-bold" style={{ color: textMain }}>My Roadmap</p>
            <button className="text-xs font-semibold" style={{ color: "#146EF5" }} onClick={onRoadmap}>View all →</button>
          </div>
          <div className="h-2.5 rounded-full overflow-hidden mb-2" style={{ background: isDark ? "#1E293B" : "#F1F5F9" }}>
            <div className="h-full rounded-full transition-all duration-700 bg-blue-600" style={{ width: `${roadmapPct}%` }} />
          </div>
          <div className="flex justify-between">
            <span className="text-xs" style={{ color: textMuted }}>{completedSteps}/{roadmapTotal} steps</span>
            <span className="text-xs font-semibold" style={{ color: "#146EF5" }}>{roadmapPct}%</span>
          </div>
          <button
            className="w-full mt-3 py-3 rounded-xl text-white text-sm font-bold transition-all active:scale-95"
            style={{ background: "#146EF5" }}
            onClick={onRoadmap}
          >
            Continue My Roadmap →
          </button>
        </div>
      )}

      {/* Quick actions */}
      <div>
        <p className="text-sm font-bold mb-3" style={{ color: textMain }}>Quick Actions</p>
        <div className="grid grid-cols-2 gap-3">
          {[
            { icon: "🎯", label: "Career Results", sub: "View all matches", action: onCareerResults, color: "#146EF5" },
            { icon: "📊", label: "Skill Gap", sub: "Analyse your gaps", action: onSkillGap, color: "#059669" },
            { icon: "🏫", label: "Institutions", sub: "Find your college", action: onInstitutions, color: "#7C3AED" },
            { icon: "📚", label: "Academies", sub: "Online & offline courses", action: onAcademies, color: "#DB2777" },
          ].map((item) => (
            <button
              key={item.label}
              className="flex flex-col gap-1.5 p-4 rounded-2xl text-left transition-all active:scale-95"
              style={{ background: surface, border: `1px solid ${border}` }}
              onClick={item.action}
            >
              <span className="text-2xl">{item.icon}</span>
              <p className="text-xs font-bold" style={{ color: textMain }}>{item.label}</p>
              <p className="text-[10px]" style={{ color: textMuted }}>{item.sub}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Streak banner */}
      {assessmentDone && streak > 0 && (
        <div className="rounded-2xl p-4" style={{ background: "linear-gradient(135deg, #F59E0B20, #F59E0B08)", border: "1px solid #F59E0B30" }}>
          <div className="flex items-center gap-3">
            <span className="text-3xl">🔥</span>
            <div className="flex-1">
              <p className="text-sm font-bold" style={{ color: textMain }}>{streak} Day Streak!</p>
              <p className="text-xs" style={{ color: textMuted }}>Keep it up — you're on a roll!</p>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-lg font-extrabold" style={{ color: "#F59E0B" }}>{streak}</span>
              <span className="text-[9px]" style={{ color: textMuted }}>days</span>
            </div>
          </div>
        </div>
      )}

      {/* Clarity check CTA */}
      {assessmentDone && clarityScore === 0 && (
        <div className="rounded-2xl p-4" style={{ background: isDark ? "#1E293B" : "#EAF2FF" }}>
          <div className="flex items-center gap-3">
            <span className="text-2xl">🧭</span>
            <div className="flex-1">
              <p className="text-sm font-bold" style={{ color: textMain }}>Career Clarity Check</p>
              <p className="text-xs" style={{ color: textMuted }}>How clear are you about your direction?</p>
            </div>
            <button
              className="px-3 py-2 rounded-xl text-white text-xs font-bold shrink-0 transition-all active:scale-95"
              style={{ background: "#146EF5" }}
              onClick={onClarityCheck}
            >
              Take Check
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function ExploreTab({ isDark, surface, textMain, textMuted, border, onCareerDetail, onInstitutions, onAcademies }: any) {
  return (
    <div className="px-5 pt-6 pb-4 space-y-5">
      <h2 className="text-lg font-bold" style={{ color: textMain }}>Explore</h2>

      <div>
        <p className="text-sm font-bold mb-3" style={{ color: textMain }}>All Career Paths</p>
        <div className="space-y-2">
          {CAREERS.map((c) => (
            <button
              key={c.id}
              className="w-full flex items-center gap-3 p-3.5 rounded-xl text-left transition-all active:scale-95"
              style={{ background: surface, border: `1px solid ${border}` }}
              onClick={() => onCareerDetail(c.id)}
            >
              <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl shrink-0" style={{ background: c.color + "20" }}>{c.emoji}</div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-bold" style={{ color: textMain }}>{c.title}</p>
                <p className="text-[10px]" style={{ color: textMuted }}>{c.domain} · {c.avgSalary}</p>
              </div>
              <span
                className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold shrink-0"
                style={{ background: c.color + "15", color: c.color }}
              >
                {c.growth}
              </span>
            </button>
          ))}
        </div>
      </div>

      <div className="flex gap-3">
        <button
          className="flex-1 py-3 rounded-xl text-white text-sm font-bold transition-all active:scale-95"
          style={{ background: "#7C3AED" }}
          onClick={onInstitutions}
        >
          🏫 Institutions
        </button>
        <button
          className="flex-1 py-3 rounded-xl text-white text-sm font-bold transition-all active:scale-95"
          style={{ background: "#DB2777" }}
          onClick={onAcademies}
        >
          📚 Academies
        </button>
      </div>
    </div>
  );
}

function SavedTabInline({ isDark, surface, textMain, textMuted, border, savedCareers, savedInstitutions, savedAcademies, onViewCareer }: any) {
  const [tab, setTab] = useState("careers");
  const savedCareerData = CAREERS.filter((c: any) => savedCareers.includes(c.id));
  const savedInstData = INSTITUTIONS.filter((i: any) => savedInstitutions.includes(i.id));
  const savedAcadData = ACADEMIES.filter((a: any) => savedAcademies.includes(a.id));

  const Empty = ({ label }: { label: string }) => (
    <div className="text-center py-12">
      <p className="text-4xl mb-2">🔖</p>
      <p className="text-sm font-semibold" style={{ color: textMain }}>No saved {label}</p>
      <p className="text-xs mt-1" style={{ color: textMuted }}>Bookmark items while exploring</p>
    </div>
  );

  return (
    <div className="px-5 pt-6 pb-4">
      <h2 className="text-lg font-bold mb-4" style={{ color: textMain }}>Saved Items</h2>
      <div className="flex gap-1 mb-4 p-1 rounded-xl" style={{ background: isDark ? "#1E293B" : "#E2E8F0" }}>
        {[["careers", `Careers (${savedCareers.length})`], ["institutions", `Institutions (${savedInstitutions.length})`], ["academies", `Academies (${savedAcademies.length})`]].map(([id, label]) => (
          <button
            key={id}
            className="flex-1 py-1.5 rounded-lg text-[10px] font-semibold transition-all"
            style={{
              background: tab === id ? (isDark ? "#0F172A" : "#ffffff") : "transparent",
              color: tab === id ? textMain : textMuted,
            }}
            onClick={() => setTab(id)}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "careers" && (savedCareerData.length === 0 ? <Empty label="careers" /> : (
        <div className="space-y-2">
          {savedCareerData.map((c: any) => (
            <button key={c.id} className="w-full flex items-center gap-3 p-3.5 rounded-xl text-left transition-all active:scale-95" style={{ background: surface, border: `1px solid ${border}` }} onClick={() => onViewCareer(c.id)}>
              <div className="w-9 h-9 rounded-xl flex items-center justify-center text-lg" style={{ background: c.color + "20" }}>{c.emoji}</div>
              <div className="flex-1"><p className="text-xs font-bold" style={{ color: textMain }}>{c.title}</p><p className="text-[10px]" style={{ color: textMuted }}>{c.avgSalary}</p></div>
            </button>
          ))}
        </div>
      ))}

      {tab === "institutions" && (savedInstData.length === 0 ? <Empty label="institutions" /> : (
        <div className="space-y-2">
          {savedInstData.map((i: any) => (
            <div key={i.id} className="p-3.5 rounded-xl" style={{ background: surface, border: `1px solid ${border}` }}>
              <p className="text-xs font-bold" style={{ color: textMain }}>{i.name}</p>
              <p className="text-[10px] mt-0.5" style={{ color: textMuted }}>{i.type} · {i.location}</p>
            </div>
          ))}
        </div>
      ))}

      {tab === "academies" && (savedAcadData.length === 0 ? <Empty label="academies" /> : (
        <div className="space-y-2">
          {savedAcadData.map((a: any) => (
            <div key={a.id} className="p-3.5 rounded-xl" style={{ background: surface, border: `1px solid ${border}` }}>
              <p className="text-[10px] font-bold" style={{ color: "#146EF5" }}>{a.name}</p>
              <p className="text-xs font-bold mt-0.5" style={{ color: textMain }}>{a.course}</p>
              <p className="text-[10px]" style={{ color: textMuted }}>{a.mode} · {a.price}</p>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

function RoadmapTabInline({ isDark, surface, surfaceEl, textMain, textMuted, border, bg, assessmentDone, career, roadmapPct, completedSteps, roadmapTotal, onRoadmap, onAssessment }: any) {
  return (
    <div className="px-5 pt-6 pb-4 space-y-5">
      <h2 className="text-lg font-bold" style={{ color: textMain }}>My Roadmap</h2>
      {!assessmentDone ? (
        <div className="rounded-2xl p-6 text-center" style={{ background: surface }}>
          <p className="text-4xl mb-3">🗺️</p>
          <p className="text-sm font-bold mb-1" style={{ color: textMain }}>No roadmap yet</p>
          <p className="text-xs mb-4" style={{ color: textMuted }}>Complete your assessment to generate a personalized roadmap</p>
          <button className="w-full py-3 rounded-xl text-white font-bold text-sm" style={{ background: "#146EF5" }} onClick={onAssessment}>
            Start Assessment
          </button>
        </div>
      ) : (
        <>
          <div className="rounded-2xl p-4" style={{ background: surface }}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl" style={{ background: career.color + "20" }}>{career.emoji}</div>
              <div className="flex-1">
                <p className="text-sm font-bold" style={{ color: textMain }}>{career.title}</p>
                <p className="text-xs" style={{ color: textMuted }}>{completedSteps}/{roadmapTotal} milestones complete</p>
              </div>
              <span className="text-lg font-extrabold" style={{ color: "#146EF5" }}>{roadmapPct}%</span>
            </div>
            <div className="h-3 rounded-full overflow-hidden mb-4" style={{ background: isDark ? "#1E293B" : "#EAF2FF" }}>
              <div className="h-full rounded-full transition-all duration-700" style={{ width: `${roadmapPct}%`, background: "linear-gradient(90deg, #146EF5, #10B981)" }} />
            </div>
            <button className="w-full py-3 rounded-xl text-white font-bold text-sm" style={{ background: "#146EF5" }} onClick={onRoadmap}>
              Continue My Roadmap →
            </button>
          </div>

          <div className="rounded-2xl p-4" style={{ background: surface }}>
            <p className="text-sm font-bold mb-3" style={{ color: textMain }}>Roadmap Steps</p>
            {career.roadmap?.slice(0, 4).map((step: any, i: number) => (
              <div key={i} className="flex items-start gap-3 pb-3 mb-3 last:pb-0 last:mb-0" style={{ borderBottom: i < 3 ? `1px solid ${isDark ? "#1E293B" : "#F1F5F9"}` : "none" }}>
                <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5" style={{ background: "#146EF520", color: "#146EF5" }}>{i + 1}</div>
                <div>
                  <p className="text-xs font-bold" style={{ color: textMain }}>{step.title}</p>
                  <p className="text-[10px] mt-0.5" style={{ color: textMuted }}>{step.duration} · {step.goal}</p>
                </div>
              </div>
            ))}
            {career.roadmap?.length > 4 && (
              <button className="w-full text-xs font-semibold mt-2 py-2" style={{ color: "#146EF5" }} onClick={onRoadmap}>
                View all {career.roadmap.length} steps →
              </button>
            )}
          </div>
        </>
      )}
    </div>
  );
}

function ProgressTabInline({ isDark, surface, surfaceEl, textMain, textMuted, border, bg, assessmentDone, streak, dailyProgress, onDailyProgress, roadmapPct, completedSteps, roadmapTotal, clarityScore, strongSkills, skillGapsTotal, onSkillGap, onClarityCheck }: any) {
  const milestones = [
    { icon: "🎯", label: "Assessment Complete", done: assessmentDone },
    { icon: "📊", label: "Skill Gap Analyzed", done: skillGapsTotal > 0 },
    { icon: "🗺️", label: "Roadmap Started", done: completedSteps > 0 },
    { icon: "🧭", label: "Clarity Check Done", done: clarityScore > 0 },
    { icon: "🔥", label: "7 Day Streak", done: streak >= 7 },
  ];

  return (
    <div className="px-5 pt-6 pb-4 space-y-5">
      <h2 className="text-lg font-bold" style={{ color: textMain }}>Progress</h2>

      {/* Streak card */}
      <div className="rounded-2xl p-4" style={{ background: "linear-gradient(135deg, #F59E0B, #EF4444)", color: "#fff" }}>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs opacity-80">Learning Streak</p>
            <p className="text-3xl font-extrabold">{streak} <span className="text-xl">🔥</span></p>
            <p className="text-xs opacity-80">consecutive days</p>
          </div>
          <div className="flex flex-col items-center">
            {[...Array(7)].map((_, i) => (
              <div key={i} className="w-2.5 h-2.5 rounded-full mb-1" style={{ background: i < streak ? "rgba(255,255,255,0.9)" : "rgba(255,255,255,0.3)" }} />
            ))}
          </div>
        </div>
      </div>

      {/* Daily goal */}
      <div className="rounded-2xl p-4" style={{ background: surface }}>
        <div className="flex items-center justify-between mb-2">
          <p className="text-sm font-bold" style={{ color: textMain }}>Today's Goal</p>
          <span className="text-sm font-extrabold" style={{ color: "#146EF5" }}>{dailyProgress}%</span>
        </div>
        <p className="text-xs mb-3" style={{ color: textMuted }}>Complete Python Functions module</p>
        <div className="h-2.5 rounded-full overflow-hidden mb-3" style={{ background: isDark ? "#1E293B" : "#EAF2FF" }}>
          <div className="h-full rounded-full transition-all duration-500" style={{ width: `${dailyProgress}%`, background: "linear-gradient(90deg, #146EF5, #6366F1)" }} />
        </div>
        <div className="flex gap-2">
          {[25, 50, 75, 100].map((val) => (
            <button
              key={val}
              className="flex-1 py-2 rounded-xl text-xs font-bold transition-all active:scale-95"
              style={{ background: dailyProgress >= val ? "#146EF5" : (isDark ? "#1E293B" : "#EAF2FF"), color: dailyProgress >= val ? "#fff" : textMuted }}
              onClick={() => onDailyProgress(val)}
            >
              {val}%
            </button>
          ))}
        </div>
      </div>

      {/* Overview stats */}
      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-2xl p-4 text-center" style={{ background: surface }}>
          <p className="text-2xl font-extrabold" style={{ color: "#10B981" }}>{roadmapPct}%</p>
          <p className="text-[10px] mt-1" style={{ color: textMuted }}>Roadmap</p>
          <p className="text-[10px]" style={{ color: textMuted }}>{completedSteps}/{roadmapTotal} steps</p>
        </div>
        <div className="rounded-2xl p-4 text-center" style={{ background: surface }}>
          <p className="text-2xl font-extrabold" style={{ color: "#F59E0B" }}>{clarityScore > 0 ? `${clarityScore}%` : "—"}</p>
          <p className="text-[10px] mt-1" style={{ color: textMuted }}>Career Clarity</p>
          <button className="text-[10px] font-semibold mt-1" style={{ color: "#146EF5" }} onClick={onClarityCheck}>
            {clarityScore > 0 ? "Retake" : "Take now"}
          </button>
        </div>
        <div className="rounded-2xl p-4 text-center" style={{ background: surface }}>
          <p className="text-2xl font-extrabold" style={{ color: "#146EF5" }}>{strongSkills}</p>
          <p className="text-[10px] mt-1" style={{ color: textMuted }}>Strong Skills</p>
          <button className="text-[10px] font-semibold mt-1" style={{ color: "#146EF5" }} onClick={onSkillGap}>View gaps</button>
        </div>
        <div className="rounded-2xl p-4 text-center" style={{ background: surface }}>
          <p className="text-2xl font-extrabold" style={{ color: "#6366F1" }}>{dailyProgress}%</p>
          <p className="text-[10px] mt-1" style={{ color: textMuted }}>Today's Progress</p>
        </div>
      </div>

      {/* Milestones */}
      <div className="rounded-2xl p-4" style={{ background: surface }}>
        <p className="text-sm font-bold mb-3" style={{ color: textMain }}>Milestones</p>
        {milestones.map((m, i) => (
          <div key={i} className="flex items-center gap-3 py-2.5" style={{ borderBottom: i < milestones.length - 1 ? `1px solid ${isDark ? "#1E293B" : "#F1F5F9"}` : "none" }}>
            <span className="text-lg">{m.icon}</span>
            <span className="flex-1 text-xs font-medium" style={{ color: m.done ? textMain : textMuted }}>{m.label}</span>
            {m.done ? (
              <span className="text-xs px-2 py-0.5 rounded-full font-semibold" style={{ background: "#DCFCE7", color: "#059669" }}>✓ Done</span>
            ) : (
              <span className="text-xs px-2 py-0.5 rounded-full font-semibold" style={{ background: isDark ? "#1E293B" : "#F1F5F9", color: textMuted }}>Pending</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function ProfileTabInline({ isDark, onToggleDark, surface, textMain, textMuted, border, userName, avatar, assessmentDone, clarityScore, streak, onProfile }: any) {
  return (
    <div className="px-5 pt-6 pb-4 space-y-4">
      <h2 className="text-lg font-bold" style={{ color: textMain }}>Profile</h2>

      {/* Avatar + name */}
      <div className="flex flex-col items-center py-6 rounded-2xl" style={{ background: surface }}>
        <div className="w-20 h-20 rounded-full flex items-center justify-center text-5xl mb-3" style={{ background: avatar.bg }}>
          {avatar.emoji}
        </div>
        <p className="text-base font-bold" style={{ color: textMain }}>{userName || "Explorer"}</p>
        <div className="flex gap-2 mt-3 flex-wrap justify-center">
          <span className="text-xs px-3 py-1 rounded-full" style={{ background: isDark ? "#1E293B" : "#EAF2FF", color: "#146EF5" }}>
            {assessmentDone ? "Assessment ✓" : "Assessment Pending"}
          </span>
          {clarityScore > 0 && (
            <span className="text-xs px-3 py-1 rounded-full" style={{ background: isDark ? "#1E293B" : "#ECFDF5", color: "#10B981" }}>
              Clarity {clarityScore}%
            </span>
          )}
          {streak > 0 && (
            <span className="text-xs px-3 py-1 rounded-full" style={{ background: isDark ? "#1E293B" : "#FFF7ED", color: "#F59E0B" }}>
              🔥 {streak} Day Streak
            </span>
          )}
        </div>
      </div>

      {/* Settings list */}
      <div className="rounded-2xl overflow-hidden" style={{ background: surface }}>
        {[
          { icon: "✏️", label: "Edit Profile", action: onProfile },
          { icon: "🌐", label: "Change Language", action: () => {} },
          { icon: "🔒", label: "Privacy Settings", action: () => {} },
          { icon: "📋", label: "Terms & Conditions", action: () => {} },
        ].map((item, i, arr) => (
          <button
            key={item.label}
            className="w-full flex items-center gap-3 px-4 py-3.5 text-left transition-all active:scale-95"
            style={{ borderBottom: i < arr.length - 1 ? `1px solid ${border}` : "none" }}
            onClick={item.action}
          >
            <span className="text-lg w-7 text-center">{item.icon}</span>
            <span className="flex-1 text-sm" style={{ color: textMain }}>{item.label}</span>
            <span style={{ color: textMuted }}>›</span>
          </button>
        ))}
      </div>

      {/* Dark mode toggle */}
      <div className="flex items-center justify-between px-4 py-3.5 rounded-2xl" style={{ background: surface }}>
        <div className="flex items-center gap-3">
          <span className="text-lg">{isDark ? "☀️" : "🌙"}</span>
          <span className="text-sm" style={{ color: textMain }}>{isDark ? "Light Mode" : "Dark Mode"}</span>
        </div>
        <button
          className="w-12 h-6 rounded-full transition-all duration-300 relative"
          style={{ background: isDark ? "#146EF5" : "#CBD5E1" }}
          onClick={onToggleDark}
        >
          <div
            className="w-5 h-5 bg-white rounded-full absolute top-0.5 transition-all duration-300"
            style={{ left: isDark ? "26px" : "2px" }}
          />
        </button>
      </div>

      <button
        className="w-full py-3.5 rounded-2xl font-bold text-sm transition-all active:scale-95 border"
        style={{ borderColor: "#EF4444", color: "#EF4444", background: "transparent" }}
        onClick={() => window.location.reload()}
      >
        🚪 Log Out
      </button>

      <p className="text-center text-[10px]" style={{ color: textMuted }}>
        SkillBridgeAI — From Confusion to Career Clarity
      </p>
    </div>
  );
}

// ─── Profile / Settings ──────────────────────────────────────────
interface ProfileProps {
  isDark: boolean;
  userName: string;
  email: string;
  language: string;
  userCategory: string;
  onBack: () => void;
}

export function ProfileScreen({ isDark, userName, email, language, userCategory, onBack }: ProfileProps) {
  const [name, setName] = useState(userName);
  const [saved, setSaved] = useState(false);

  const bg = isDark ? "#111827" : "#F5F9FF";
  const surface = isDark ? "#1E293B" : "#ffffff";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const textMuted = isDark ? "#94A3B8" : "#64748B";

  return (
    <div className="flex-1 flex flex-col overflow-y-auto scrollbar-hide" style={{ background: bg }}>
      <div className="px-5 pt-5 pb-2 flex items-center justify-between">
        <button onClick={onBack} className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: isDark ? "#1E293B" : "#ffffff" }}>
          <span style={{ color: textMain }}>←</span>
        </button>
        <h2 className="text-base font-bold" style={{ color: textMain }}>Edit Profile</h2>
        <div className="w-9" />
      </div>

      <div className="px-5 pb-6 space-y-4">
        <div className="rounded-2xl p-4 space-y-3" style={{ background: surface }}>
          <div>
            <p className="text-xs font-semibold mb-1" style={{ color: textMuted }}>Full Name</p>
            <input
              className="w-full px-4 py-3 rounded-xl text-sm border outline-none focus:border-blue-500"
              style={{ background: isDark ? "#0F172A" : "#F5F9FF", borderColor: isDark ? "#334155" : "#E2E8F0", color: textMain }}
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div>
            <p className="text-xs font-semibold mb-1" style={{ color: textMuted }}>Email</p>
            <input
              className="w-full px-4 py-3 rounded-xl text-sm border outline-none"
              style={{ background: isDark ? "#0F172A" : "#F5F9FF", borderColor: isDark ? "#334155" : "#E2E8F0", color: textMuted }}
              value={email}
              readOnly
            />
          </div>
          <div>
            <p className="text-xs font-semibold mb-1" style={{ color: textMuted }}>Language</p>
            <div className="px-4 py-3 rounded-xl text-sm" style={{ background: isDark ? "#0F172A" : "#F5F9FF", color: textMain }}>
              {language || "English"}
            </div>
          </div>
          <div>
            <p className="text-xs font-semibold mb-1" style={{ color: textMuted }}>Category</p>
            <div className="px-4 py-3 rounded-xl text-sm" style={{ background: isDark ? "#0F172A" : "#F5F9FF", color: textMain }}>
              {userCategory || "Not set"}
            </div>
          </div>
        </div>

        {saved && (
          <div className="rounded-xl p-3 text-center" style={{ background: "#DCFCE7" }}>
            <p className="text-xs font-semibold" style={{ color: "#059669" }}>✓ Profile updated successfully</p>
          </div>
        )}

        <button
          className="w-full py-4 rounded-2xl text-white font-bold text-base transition-all active:scale-95"
          style={{ background: "#146EF5" }}
          onClick={() => { setSaved(true); setTimeout(() => setSaved(false), 2000); }}
        >
          Save Changes
        </button>
      </div>
    </div>
  );
}
