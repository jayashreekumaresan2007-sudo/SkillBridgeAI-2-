import { useState } from "react";
import { ASSESSMENT_QUESTIONS } from "../data";
import type { AssessmentAnswers } from "../types";

const TOTAL = ASSESSMENT_QUESTIONS.length;

interface AssessmentProps {
  isDark: boolean;
  answers: AssessmentAnswers;
  currentQ: number;
  onAnswer: (answers: AssessmentAnswers, currentQ: number) => void;
  onComplete: (answers: AssessmentAnswers) => void;
  onBack: () => void;
}

export function AssessmentScreen({ isDark, answers, currentQ, onAnswer, onComplete, onBack }: AssessmentProps) {
  const [localAnswers, setLocalAnswers] = useState<AssessmentAnswers>(answers);
  const [q, setQ] = useState(currentQ);

  const question = ASSESSMENT_QUESTIONS[q];
  const progress = ((q + 1) / TOTAL) * 100;

  const bg = isDark ? "#111827" : "#ffffff";
  const surface = isDark ? "#1E293B" : "#F5F9FF";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const textMuted = isDark ? "#94A3B8" : "#64748B";
  const border = isDark ? "#334155" : "#E2E8F0";

  // helpers
  const isAnswered = () => {
    if (question.type === "multiselect") return localAnswers.interests.length > 0;
    if (question.type === "rating") return (localAnswers.ratings[question.ratingLabel as keyof AssessmentAnswers["ratings"]] ?? 0) > 0;
    if (question.category === "activity") return !!localAnswers.activity;
    if (question.category === "project") return !!localAnswers.projectType;
    if (question.category === "scenario") return !!localAnswers.scenario;
    if (question.category === "goal") return !!localAnswers.goal;
    return false;
  };

  const handleNext = () => {
    onAnswer(localAnswers, q + 1);
    if (q < TOTAL - 1) {
      setQ(q + 1);
    } else {
      onComplete(localAnswers);
    }
  };

  const handleBack = () => {
    if (q === 0) { onBack(); return; }
    onAnswer(localAnswers, q - 1);
    setQ(q - 1);
  };

  // Answer setters
  const toggleInterest = (id: string) => {
    const curr = localAnswers.interests;
    let next: string[];
    if (curr.includes(id)) next = curr.filter((x) => x !== id);
    else if (curr.length < 2) next = [...curr, id];
    else next = [curr[1], id];
    setLocalAnswers({ ...localAnswers, interests: next });
  };

  const setActivity = (id: string) => setLocalAnswers({ ...localAnswers, activity: id });
  const setProjectType = (id: string) => setLocalAnswers({ ...localAnswers, projectType: id });
  const setScenario = (id: string) => setLocalAnswers({ ...localAnswers, scenario: id });
  const setGoal = (id: string) => setLocalAnswers({ ...localAnswers, goal: id });
  const setRating = (key: string, val: number) => setLocalAnswers({ ...localAnswers, ratings: { ...localAnswers.ratings, [key]: val } });

  const renderAnswerArea = () => {
    if (question.type === "multiselect") {
      return (
        <div className="space-y-2.5">
          {question.options?.map((opt) => {
            const sel = localAnswers.interests.includes(opt.id);
            return (
              <button
                key={opt.id}
                className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl border-2 text-left transition-all duration-200 active:scale-[0.98]"
                style={{
                  borderColor: sel ? "#146EF5" : border,
                  background: sel ? "#EAF2FF" : surface,
                }}
                onClick={() => toggleInterest(opt.id)}
              >
                <span className="text-xl w-7 text-center">{opt.emoji}</span>
                <span className="text-sm font-medium flex-1" style={{ color: textMain }}>{opt.label}</span>
                <div
                  className="w-5 h-5 rounded border-2 flex items-center justify-center shrink-0 transition-all"
                  style={{
                    borderColor: sel ? "#146EF5" : isDark ? "#475569" : "#CBD5E1",
                    background: sel ? "#146EF5" : "transparent",
                  }}
                >
                  {sel && <span className="text-white text-[10px] font-bold">✓</span>}
                </div>
              </button>
            );
          })}
          <p className="text-xs text-center mt-1" style={{ color: "#146EF5" }}>
            {localAnswers.interests.length}/2 selected
          </p>
        </div>
      );
    }

    if (question.type === "grid") {
      const curr = question.category === "activity" ? localAnswers.activity : localAnswers.projectType;
      const setter = question.category === "activity" ? setActivity : setProjectType;
      return (
        <div className="grid grid-cols-2 gap-2.5">
          {question.options?.map((opt) => {
            const sel = curr === opt.id;
            return (
              <button
                key={opt.id}
                className="flex flex-col items-center gap-2 px-3 py-4 rounded-xl border-2 text-center transition-all duration-200 active:scale-95"
                style={{
                  borderColor: sel ? "#146EF5" : border,
                  background: sel ? "#EAF2FF" : surface,
                }}
                onClick={() => setter(opt.id)}
              >
                <span className="text-2xl">{opt.emoji}</span>
                <span className="text-xs font-semibold leading-tight" style={{ color: textMain }}>{opt.label}</span>
              </button>
            );
          })}
        </div>
      );
    }

    if (question.type === "single") {
      const curr = question.category === "scenario" ? localAnswers.scenario : localAnswers.goal;
      const setter = question.category === "scenario" ? setScenario : setGoal;
      return (
        <div className="space-y-2.5">
          {question.options?.map((opt) => {
            const sel = curr === opt.id;
            return (
              <button
                key={opt.id}
                className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl border-2 text-left transition-all duration-200 active:scale-[0.98]"
                style={{
                  borderColor: sel ? "#146EF5" : border,
                  background: sel ? "#EAF2FF" : surface,
                }}
                onClick={() => setter(opt.id)}
              >
                {opt.emoji && <span className="text-xl w-7 text-center">{opt.emoji}</span>}
                <span className="text-sm font-medium flex-1" style={{ color: textMain }}>{opt.label}</span>
                <div
                  className="w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0"
                  style={{
                    borderColor: sel ? "#146EF5" : isDark ? "#475569" : "#CBD5E1",
                    background: sel ? "#146EF5" : "transparent",
                  }}
                >
                  {sel && <div className="w-2 h-2 rounded-full bg-white" />}
                </div>
              </button>
            );
          })}
        </div>
      );
    }

    if (question.type === "rating") {
      const key = question.ratingLabel as keyof AssessmentAnswers["ratings"];
      const curr = localAnswers.ratings[key] ?? 0;
      const labels = ["Beginner", "Basic", "Comfortable", "Proficient", "Expert"];
      return (
        <div>
          <div className="flex justify-center gap-3 mb-4">
            {[1, 2, 3, 4, 5].map((val) => (
              <button
                key={val}
                className="w-12 h-12 rounded-xl text-lg font-bold border-2 transition-all duration-200 active:scale-90"
                style={{
                  borderColor: curr >= val ? "#146EF5" : border,
                  background: curr >= val ? "#146EF5" : surface,
                  color: curr >= val ? "#ffffff" : textMuted,
                }}
                onClick={() => setRating(key, val)}
              >
                {val}
              </button>
            ))}
          </div>
          {curr > 0 && (
            <div className="text-center">
              <span
                className="text-sm font-semibold px-4 py-1.5 rounded-full"
                style={{ background: "#EAF2FF", color: "#146EF5" }}
              >
                {labels[curr - 1]}
              </span>
            </div>
          )}
          <div className="flex justify-between mt-4 px-1">
            <span className="text-xs" style={{ color: textMuted }}>Beginner</span>
            <span className="text-xs" style={{ color: textMuted }}>Expert</span>
          </div>
        </div>
      );
    }

    return null;
  };

  return (
    <div className="flex-1 flex flex-col" style={{ background: bg }}>
      {/* Progress bar */}
      <div className="h-1.5 w-full" style={{ background: isDark ? "#1E293B" : "#E2E8F0" }}>
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${progress}%`, background: "#146EF5" }}
        />
      </div>

      {/* Header */}
      <div className="px-5 pt-4 pb-3 flex items-center justify-between">
        <span className="text-xs font-semibold" style={{ color: "#146EF5" }}>
          Question {q + 1} of {TOTAL}
        </span>
        <span className="text-xs px-2.5 py-1 rounded-full" style={{ background: isDark ? "#1E293B" : "#EAF2FF", color: "#146EF5" }}>
          {question.category === "skill" ? "Rate Yourself" :
            question.category === "interest" ? "Interests" :
            question.category === "activity" ? "Activity" :
            question.category === "project" ? "Project Type" :
            question.category === "scenario" ? "Scenario" : "Goal"}
        </span>
      </div>

      {/* Question */}
      <div className="px-5 pb-4">
        <h2 className="text-lg font-bold leading-tight mb-1" style={{ color: textMain }}>
          {question.question}
        </h2>
        <p className="text-xs" style={{ color: textMuted }}>{question.subtitle}</p>
      </div>

      {/* Answer area */}
      <div className="flex-1 px-5 overflow-y-auto scrollbar-hide">
        {renderAnswerArea()}
      </div>

      {/* Navigation */}
      <div className="px-5 pb-8 pt-4 flex gap-3">
        <button
          className="flex-1 py-3.5 rounded-2xl border-2 text-sm font-bold transition-all duration-200 active:scale-95"
          style={{ borderColor: isDark ? "#334155" : "#E2E8F0", color: textMuted }}
          onClick={handleBack}
        >
          ← Back
        </button>
        <button
          className="flex-[2] py-3.5 rounded-2xl text-white font-bold text-sm transition-all duration-200 active:scale-95 disabled:opacity-40"
          style={{ background: "#146EF5" }}
          disabled={!isAnswered()}
          onClick={handleNext}
        >
          {q === TOTAL - 1 ? "Complete Assessment ✓" : "Next →"}
        </button>
      </div>
    </div>
  );
}

interface AssessmentCompleteProps {
  isDark: boolean;
  answers: AssessmentAnswers;
  onViewResults: () => void;
}

export function AssessmentCompleteScreen({ isDark, answers, onViewResults }: AssessmentCompleteProps) {
  const bg = isDark ? "#111827" : "#ffffff";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const textMuted = isDark ? "#94A3B8" : "#64748B";

  const answeredCount = TOTAL;

  return (
    <div className="flex-1 flex flex-col items-center justify-center px-6" style={{ background: bg }}>
      <div className="text-center mb-8">
        {/* Checkmark animation */}
        <div
          className="w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6"
          style={{ background: "#DCFCE7", border: "4px solid #10B981" }}
        >
          <span className="text-5xl">✓</span>
        </div>
        <h1 className="text-2xl font-bold mb-2" style={{ color: textMain }}>
          Assessment Completed!
        </h1>
        <p className="text-sm" style={{ color: textMuted }}>
          Great job! Your profile is now ready.
        </p>
      </div>

      {/* Stats */}
      <div className="w-full grid grid-cols-3 gap-3 mb-8">
        {[
          { value: `${answeredCount}/${TOTAL}`, label: "Questions Answered" },
          { value: "✓", label: "Profile Generated" },
          { value: "3+", label: "Career Matches Ready" },
        ].map((stat) => (
          <div
            key={stat.label}
            className="flex flex-col items-center gap-1 py-4 px-2 rounded-2xl text-center"
            style={{ background: isDark ? "#1E293B" : "#F5F9FF" }}
          >
            <span className="text-2xl font-extrabold" style={{ color: "#146EF5" }}>{stat.value}</span>
            <span className="text-[10px] leading-tight" style={{ color: textMuted }}>{stat.label}</span>
          </div>
        ))}
      </div>

      <div
        className="w-full px-4 py-3 rounded-xl mb-8"
        style={{ background: isDark ? "#1E293B" : "#EAF2FF" }}
      >
        <p className="text-xs text-center" style={{ color: textMuted }}>
          Based on your assessment, SkillBridgeAI will now generate personalized career recommendations. Results are based on your profile and are not scientifically validated predictions.
        </p>
      </div>

      <button
        className="w-full py-4 rounded-2xl text-white font-bold text-base transition-all duration-200 active:scale-95"
        style={{ background: "#146EF5" }}
        onClick={onViewResults}
      >
        View My Results →
      </button>
    </div>
  );
}
