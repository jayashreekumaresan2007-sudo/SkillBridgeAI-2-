import { useState } from "react";
import Logo from "../components/Logo";

// ─── Google Account Selection Modal ────────────────────────────────
const GOOGLE_ACCOUNTS = [
  { name: "Jayashree K", email: "jayashree.k@gmail.com", color: "#4285F4" },
  { name: "Arjun Sharma", email: "arjun.sharma22@gmail.com", color: "#34A853" },
  { name: "Meera Pillai", email: "meerap.work@gmail.com", color: "#DB2777" },
];

function GoogleModal({ onSelect, onClose }: { onSelect: (email: string) => void; onClose: () => void }) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center"
      style={{ background: "rgba(0,0,0,0.5)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-[430px] rounded-t-3xl bg-white pb-8 pt-2"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Handle */}
        <div className="w-10 h-1 bg-gray-200 rounded-full mx-auto mb-5" />

        {/* Google header */}
        <div className="text-center mb-4 px-6">
          <div className="flex justify-center mb-3">
            <svg width="32" height="32" viewBox="0 0 18 18" fill="none">
              <path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.716v2.259h2.908c1.702-1.567 2.684-3.875 2.684-6.615z" fill="#4285F4"/>
              <path d="M9 18c2.43 0 4.467-.806 5.956-2.184l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 009 18z" fill="#34A853"/>
              <path d="M3.964 10.712A5.41 5.41 0 013.682 9c0-.593.102-1.17.282-1.712V4.956H.957A8.996 8.996 0 000 9c0 1.452.348 2.827.957 4.044l3.007-2.332z" fill="#FBBC05"/>
              <path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 00.957 4.956l3.007 2.332C4.672 5.163 6.656 3.58 9 3.58z" fill="#EA4335"/>
            </svg>
          </div>
          <p className="text-base font-bold text-slate-900">Continue with Google</p>
          <p className="text-xs text-slate-500 mt-0.5">Choose an account</p>
        </div>

        <div className="px-4 space-y-2">
          {GOOGLE_ACCOUNTS.map((acc) => (
            <button
              key={acc.email}
              className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl border border-gray-100 hover:bg-gray-50 active:scale-95 transition-all text-left"
              onClick={() => onSelect(acc.email)}
            >
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center text-white text-sm font-bold shrink-0"
                style={{ background: acc.color }}
              >
                {acc.name[0]}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-slate-900 truncate">{acc.name}</p>
                <p className="text-xs text-slate-500 truncate">{acc.email}</p>
              </div>
            </button>
          ))}
          <button
            className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl border border-gray-100 hover:bg-gray-50 active:scale-95 transition-all text-left"
            onClick={() => onSelect("other@gmail.com")}
          >
            <div className="w-10 h-10 rounded-full border-2 border-dashed border-gray-300 flex items-center justify-center shrink-0">
              <span className="text-gray-400 text-lg">+</span>
            </div>
            <p className="text-sm text-slate-600">Use another account</p>
          </button>
        </div>
      </div>
    </div>
  );
}

const inputClass = (isDark: boolean) =>
  `w-full px-4 py-3.5 rounded-xl text-sm border outline-none transition-all duration-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 ${
    isDark
      ? "bg-slate-700 border-slate-600 text-white placeholder-slate-400"
      : "bg-gray-50 border-gray-200 text-slate-900 placeholder-slate-400"
  }`;

const socialBtn = (isDark: boolean) =>
  `flex items-center justify-center gap-3 w-full py-3.5 rounded-xl border text-sm font-medium transition-all duration-200 active:scale-95 ${
    isDark
      ? "border-slate-600 text-slate-200 bg-slate-700 hover:bg-slate-600"
      : "border-gray-200 text-slate-700 bg-white hover:bg-gray-50"
  }`;

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
      <path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.716v2.259h2.908c1.702-1.567 2.684-3.875 2.684-6.615z" fill="#4285F4"/>
      <path d="M9 18c2.43 0 4.467-.806 5.956-2.184l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 009 18z" fill="#34A853"/>
      <path d="M3.964 10.712A5.41 5.41 0 013.682 9c0-.593.102-1.17.282-1.712V4.956H.957A8.996 8.996 0 000 9c0 1.452.348 2.827.957 4.044l3.007-2.332z" fill="#FBBC05"/>
      <path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 00.957 4.956l3.007 2.332C4.672 5.163 6.656 3.58 9 3.58z" fill="#EA4335"/>
    </svg>
  );
}

function MicrosoftIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
      <rect x="0" y="0" width="8.5" height="8.5" fill="#F25022"/>
      <rect x="9.5" y="0" width="8.5" height="8.5" fill="#7FBA00"/>
      <rect x="0" y="9.5" width="8.5" height="8.5" fill="#00A4EF"/>
      <rect x="9.5" y="9.5" width="8.5" height="8.5" fill="#FFB900"/>
    </svg>
  );
}

function TrustBadges({ isDark }: { isDark: boolean }) {
  const items = [
    { icon: "🎓", label: "Personalized Learning Paths", sub: "Just for you" },
    { icon: "📊", label: "Track Your Progress", sub: "Step by Step" },
    { icon: "🤖", label: "AI-Powered Guidance", sub: "Learn smarter" },
    { icon: "🔒", label: "Secure & Private", sub: "Your data is safe" },
  ];
  return (
    <div
      className="px-4 py-5 grid grid-cols-4 gap-2"
      style={{ background: isDark ? "#0A0F1E" : "#EAF2FF" }}
    >
      {items.map((item) => (
        <div key={item.label} className="flex flex-col items-center gap-1 text-center">
          <div
            className="w-10 h-10 rounded-full flex items-center justify-center text-lg"
            style={{ background: isDark ? "#1E3A5F" : "rgba(37,99,235,0.12)" }}
          >
            {item.icon}
          </div>
          <p className="text-[9px] font-semibold leading-tight" style={{ color: isDark ? "#94A3B8" : "#64748B" }}>
            {item.label}
          </p>
          <p className="text-[8px]" style={{ color: isDark ? "#64748B" : "#94A3B8" }}>{item.sub}</p>
        </div>
      ))}
    </div>
  );
}

interface LoginProps {
  onLogin: (email: string) => void;
  onGuest: () => void;
  onRegister: () => void;
  onForgot: () => void;
  isDark: boolean;
}

export function LoginScreen({ onLogin, onGuest, onRegister, onForgot, isDark }: LoginProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [remember, setRemember] = useState(false);
  const [error, setError] = useState("");
  const [showGoogleModal, setShowGoogleModal] = useState(false);

  const bg = isDark ? "#111827" : "#ffffff";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const textMuted = isDark ? "#94A3B8" : "#64748B";

  const handleLogin = () => {
    if (!email.includes("@")) { setError("Please enter a valid email address"); return; }
    if (password.length < 4) { setError("Password must be at least 4 characters"); return; }
    setError("");
    onLogin(email);
  };

  return (
    <div className="flex-1 flex flex-col overflow-y-auto scrollbar-hide" style={{ background: bg }}>
      {/* Guest link */}
      <div className="flex justify-end px-6 pt-5">
        <button
          className="text-sm font-semibold"
          style={{ color: "#146EF5" }}
          onClick={onGuest}
        >
          Explore as Guest
        </button>
      </div>

      {/* Header */}
      <div className="px-6 pt-2 pb-4 flex items-start gap-4">
        <div className="mt-1"><Logo size={36} white={isDark} /></div>
        <div>
          <h1 className="text-3xl font-extrabold leading-tight" style={{ color: textMain }}>
            Welcome<br />
            <span style={{ color: "#146EF5" }}>back!</span>
          </h1>
        </div>
        {/* Illustration */}
        <div className="ml-auto">
          <svg width="90" height="80" viewBox="0 0 90 80" fill="none">
            <ellipse cx="45" cy="72" rx="35" ry="7" fill="#EAF2FF" />
            <ellipse cx="52" cy="30" rx="16" ry="16" fill="#FBBF24" />
            <rect x="36" y="46" width="32" height="26" rx="8" fill="#146EF5" />
            <rect x="22" y="50" width="14" height="8" rx="4" fill="#146EF5" />
            <rect x="68" y="50" width="14" height="8" rx="4" fill="#146EF5" />
            {/* laptop */}
            <rect x="16" y="56" width="40" height="24" rx="4" fill="#1E293B" />
            <rect x="18" y="58" width="36" height="18" rx="3" fill="#334155" />
            <rect x="10" y="80" width="52" height="4" rx="2" fill="#1E293B" />
            {/* shield */}
            <path d="M72 36 L80 40 L80 52 L72 56 L64 52 L64 40 Z" fill="#EAF2FF" stroke="#146EF5" strokeWidth="1.5" />
            <text x="72" y="49" textAnchor="middle" fontSize="10" fill="#146EF5">🔒</text>
          </svg>
        </div>
      </div>

      {/* Blue diagonal divider */}
      <div style={{ position: "relative", height: 40, overflow: "hidden", marginBottom: -1 }}>
        <svg viewBox="0 0 430 40" preserveAspectRatio="none" style={{ width: "100%", height: "100%" }}>
          <path d="M0 40 L430 0 L430 40 Z" fill="#146EF5" />
        </svg>
      </div>

      {/* Form area */}
      <div className="px-6 pb-4 pt-5" style={{ background: "#146EF5" }}>
        <p className="text-center text-sm font-semibold text-white mb-0.5">Login to SkillBridgeAI</p>
        <p className="text-center text-xs text-blue-200 mb-5">Access personalized learning paths and AI guidance.</p>

        <div className="space-y-3">
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">✉</span>
            <input
              className="w-full pl-9 pr-4 py-3.5 rounded-xl text-sm border border-white/20 bg-white text-slate-900 placeholder-slate-400 outline-none focus:ring-2 focus:ring-white/40"
              placeholder="Email address"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">🔒</span>
            <input
              className="w-full pl-9 pr-12 py-3.5 rounded-xl text-sm border border-white/20 bg-white text-slate-900 placeholder-slate-400 outline-none focus:ring-2 focus:ring-white/40"
              placeholder="Password"
              type={showPw ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-xs"
              onClick={() => setShowPw(!showPw)}
            >
              {showPw ? "🙈" : "👁️"}
            </button>
          </div>

          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                className="w-4 h-4 rounded accent-white"
                checked={remember}
                onChange={(e) => setRemember(e.target.checked)}
              />
              <span className="text-xs text-blue-100">Remember me</span>
            </label>
            <button className="text-xs text-blue-100 underline" onClick={onForgot}>
              Forgot password?
            </button>
          </div>

          {error && (
            <p className="text-xs text-red-200 text-center">{error}</p>
          )}

          <button
            className="w-full py-4 rounded-xl text-white font-bold text-base transition-all duration-200 active:scale-95"
            style={{ background: "#0F172A" }}
            onClick={handleLogin}
          >
            Login
          </button>
        </div>

        <div className="flex items-center gap-3 my-4">
          <div className="flex-1 h-px bg-blue-400/40" />
          <span className="text-xs text-blue-200">or continue with</span>
          <div className="flex-1 h-px bg-blue-400/40" />
        </div>

        <div className="space-y-2.5">
          <button className={socialBtn(false)} onClick={() => setShowGoogleModal(true)}>
            <GoogleIcon /> Continue with Google
          </button>
          <button className={socialBtn(false)} onClick={() => onLogin("ms@user.com")}>
            <MicrosoftIcon /> Continue with Microsoft
          </button>
        </div>

        {showGoogleModal && (
          <GoogleModal
            onSelect={(email) => { setShowGoogleModal(false); onLogin(email); }}
            onClose={() => setShowGoogleModal(false)}
          />
        )}

        <p className="text-center text-xs text-blue-100 mt-4">
          New here?{" "}
          <button className="text-white font-semibold underline" onClick={onRegister}>
            Create an account
          </button>
        </p>
      </div>

      <TrustBadges isDark={isDark} />
    </div>
  );
}

interface RegisterProps {
  onRegister: (name: string, email: string) => void;
  onLogin: () => void;
  isDark: boolean;
}

export function RegisterScreen({ onRegister, onLogin, isDark }: RegisterProps) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const bg = isDark ? "#111827" : "#ffffff";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";

  const validate = () => {
    const e: Record<string, string> = {};
    if (!name.trim()) e.name = "Name is required";
    if (!email.includes("@")) e.email = "Enter a valid email";
    if (password.length < 6) e.password = "Password must be at least 6 characters";
    if (password !== confirm) e.confirm = "Passwords do not match";
    if (!agreed) e.agreed = "Please accept the Terms & Privacy Policy";
    return e;
  };

  const handleSubmit = () => {
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length === 0) onRegister(name, email);
  };

  return (
    <div className="flex-1 flex flex-col overflow-y-auto scrollbar-hide" style={{ background: bg }}>
      {/* Header */}
      <div className="px-6 pt-6 pb-2 flex items-start gap-4">
        <div className="mt-1"><Logo size={36} white={isDark} /></div>
        <div>
          <h1 className="text-3xl font-extrabold leading-tight" style={{ color: textMain }}>
            Create your<br />
            <span style={{ color: "#146EF5" }}>account</span>
          </h1>
          <p className="text-sm mt-1" style={{ color: "#64748B" }}>
            Let's set up your account to get you started!
          </p>
        </div>
        <div className="ml-auto">
          <svg width="70" height="70" viewBox="0 0 70 70" fill="none">
            <ellipse cx="35" cy="65" rx="28" ry="6" fill="#EAF2FF" />
            <ellipse cx="35" cy="25" rx="14" ry="14" fill="#FCA5A5" />
            <rect x="21" y="39" width="28" height="22" rx="7" fill="#7C3AED" />
            <rect x="8" y="43" width="12" height="7" rx="3.5" fill="#7C3AED" />
            <rect x="50" y="43" width="12" height="7" rx="3.5" fill="#7C3AED" />
            <circle cx="52" cy="14" r="10" fill="#EAF2FF" stroke="#E2E8F0" strokeWidth="1" />
            <text x="52" y="19" textAnchor="middle" fontSize="10">👋</text>
          </svg>
        </div>
      </div>

      {/* Blue wave */}
      <div style={{ position: "relative", height: 40, overflow: "hidden", marginBottom: -1 }}>
        <svg viewBox="0 0 430 40" preserveAspectRatio="none" style={{ width: "100%", height: "100%" }}>
          <path d="M0 40 L430 0 L430 40 Z" fill="#146EF5" />
        </svg>
      </div>

      <div className="px-6 py-5 space-y-3" style={{ background: "#146EF5" }}>
        {[
          { label: "Full Name", value: name, onChange: setName, type: "text", placeholder: "Full Name", icon: "👤", key: "name" },
          { label: "Email", value: email, onChange: setEmail, type: "email", placeholder: "Email address", icon: "✉", key: "email" },
        ].map((field) => (
          <div key={field.key}>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-sm">{field.icon}</span>
              <input
                className="w-full pl-9 pr-4 py-3.5 rounded-xl text-sm bg-white border border-white/20 text-slate-900 placeholder-slate-400 outline-none focus:ring-2 focus:ring-white/40"
                type={field.type}
                placeholder={field.placeholder}
                value={field.value}
                onChange={(e) => field.onChange(e.target.value)}
              />
            </div>
            {errors[field.key] && <p className="text-xs text-red-200 mt-1">{errors[field.key]}</p>}
          </div>
        ))}

        <div>
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">🔒</span>
            <input
              className="w-full pl-9 pr-12 py-3.5 rounded-xl text-sm bg-white border border-white/20 text-slate-900 placeholder-slate-400 outline-none focus:ring-2 focus:ring-white/40"
              type={showPw ? "text" : "password"}
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-xs" onClick={() => setShowPw(!showPw)}>
              {showPw ? "🙈" : "👁️"}
            </button>
          </div>
          {errors.password && <p className="text-xs text-red-200 mt-1">{errors.password}</p>}
        </div>

        <div>
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">🔒</span>
            <input
              className="w-full pl-9 pr-4 py-3.5 rounded-xl text-sm bg-white border border-white/20 text-slate-900 placeholder-slate-400 outline-none focus:ring-2 focus:ring-white/40"
              type="password"
              placeholder="Confirm Password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
            />
          </div>
          {errors.confirm && <p className="text-xs text-red-200 mt-1">{errors.confirm}</p>}
        </div>

        <div>
          <label className="flex items-start gap-2 cursor-pointer">
            <input
              type="checkbox"
              className="mt-0.5 w-4 h-4 rounded accent-white"
              checked={agreed}
              onChange={(e) => setAgreed(e.target.checked)}
            />
            <span className="text-xs text-blue-100">
              I agree to the{" "}
              <span className="text-white font-semibold underline">Terms of Service</span>{" "}
              and{" "}
              <span className="text-white font-semibold underline">Privacy Policy</span>
            </span>
          </label>
          {errors.agreed && <p className="text-xs text-red-200 mt-1">{errors.agreed}</p>}
        </div>

        <button
          className="w-full py-4 rounded-xl text-white font-bold text-base transition-all duration-200 active:scale-95"
          style={{ background: "#0F172A" }}
          onClick={handleSubmit}
        >
          Create Account
        </button>

        <div className="flex items-center gap-3 my-1">
          <div className="flex-1 h-px bg-blue-400/40" />
          <span className="text-xs text-blue-200">or sign up with</span>
          <div className="flex-1 h-px bg-blue-400/40" />
        </div>

        <div className="space-y-2.5">
          <button className={socialBtn(false)} onClick={() => onRegister("Google User", "google@user.com")}>
            <GoogleIcon /> Continue with Google
          </button>
          <button className={socialBtn(false)} onClick={() => onRegister("Microsoft User", "ms@user.com")}>
            <MicrosoftIcon /> Continue with Microsoft
          </button>
        </div>

        <p className="text-center text-xs text-blue-100 pb-2">
          Already have an account?{" "}
          <button className="text-white font-semibold underline" onClick={onLogin}>
            Login
          </button>
        </p>
      </div>

      <TrustBadges isDark={isDark} />
    </div>
  );
}

interface ForgotPasswordProps {
  onBack: () => void;
  isDark: boolean;
}

export function ForgotPasswordScreen({ onBack, isDark }: ForgotPasswordProps) {
  const [step, setStep] = useState<"email" | "sent" | "reset" | "done">("email");
  const [email, setEmail] = useState("");
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");

  const bg = isDark ? "#111827" : "#ffffff";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const textMuted = isDark ? "#94A3B8" : "#64748B";

  return (
    <div className="flex-1 flex flex-col px-6" style={{ background: bg }}>
      {/* Back */}
      <div className="pt-5 pb-4">
        <button onClick={onBack} className="flex items-center gap-2 text-sm font-medium" style={{ color: "#146EF5" }}>
          ← Back
        </button>
      </div>

      <div className="flex-1 flex flex-col justify-center pb-16">
        {step === "email" && (
          <>
            <div className="text-center mb-8">
              <div className="text-5xl mb-4">🔑</div>
              <h1 className="text-2xl font-bold mb-2" style={{ color: textMain }}>Forgot Password?</h1>
              <p className="text-sm" style={{ color: textMuted }}>Enter your email to receive a reset link</p>
            </div>
            <div className="space-y-4">
              <input
                className={inputClass(isDark)}
                type="email"
                placeholder="Your email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <button
                className="w-full py-4 rounded-xl text-white font-bold text-base active:scale-95 transition-all"
                style={{ background: "#146EF5" }}
                onClick={() => email.includes("@") && setStep("sent")}
              >
                Send Reset Link
              </button>
            </div>
          </>
        )}

        {step === "sent" && (
          <div className="text-center">
            <div className="text-6xl mb-4">📬</div>
            <h2 className="text-xl font-bold mb-2" style={{ color: textMain }}>Check Your Email</h2>
            <p className="text-sm mb-6" style={{ color: textMuted }}>
              We've sent a reset link to <strong>{email}</strong>
            </p>
            <button
              className="w-full py-4 rounded-xl text-white font-bold text-base active:scale-95 transition-all"
              style={{ background: "#146EF5" }}
              onClick={() => setStep("reset")}
            >
              I've Received the Link
            </button>
          </div>
        )}

        {step === "reset" && (
          <>
            <div className="text-center mb-8">
              <div className="text-5xl mb-4">🔐</div>
              <h1 className="text-2xl font-bold mb-2" style={{ color: textMain }}>Create New Password</h1>
              <p className="text-sm" style={{ color: textMuted }}>Must be at least 8 characters</p>
            </div>
            <div className="space-y-4">
              <input
                className={inputClass(isDark)}
                type="password"
                placeholder="New password"
                value={newPw}
                onChange={(e) => setNewPw(e.target.value)}
              />
              <input
                className={inputClass(isDark)}
                type="password"
                placeholder="Confirm new password"
                value={confirmPw}
                onChange={(e) => setConfirmPw(e.target.value)}
              />
              <button
                className="w-full py-4 rounded-xl text-white font-bold text-base active:scale-95 transition-all"
                style={{ background: "#146EF5" }}
                onClick={() => newPw.length >= 6 && newPw === confirmPw && setStep("done")}
              >
                Update Password
              </button>
            </div>
          </>
        )}

        {step === "done" && (
          <div className="text-center">
            <div className="text-6xl mb-4">✅</div>
            <h2 className="text-xl font-bold mb-2" style={{ color: textMain }}>Password Updated!</h2>
            <p className="text-sm mb-8" style={{ color: textMuted }}>
              Your password has been successfully updated.
            </p>
            <button
              className="w-full py-4 rounded-xl text-white font-bold text-base active:scale-95 transition-all"
              style={{ background: "#146EF5" }}
              onClick={onBack}
            >
              Back to Login
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
