import { useState, useEffect } from "react";
import Logo from "../components/Logo";

interface SplashProps {
  onDone: () => void;
}

export function SplashScreen({ onDone }: SplashProps) {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 400);
    const t2 = setTimeout(() => setPhase(2), 1200);
    const t3 = setTimeout(() => onDone(), 2400);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [onDone]);

  return (
    <div
      className="flex-1 flex flex-col items-center justify-center transition-colors duration-700"
      style={{ background: phase >= 2 ? "#102A72" : "#F5F9FF" }}
    >
      <div
        className="flex flex-col items-center gap-4 transition-all duration-500"
        style={{ transform: phase >= 1 ? "scale(1)" : "scale(0.8)", opacity: phase >= 1 ? 1 : 0 }}
      >
        <div
          className="rounded-3xl flex items-center justify-center transition-all duration-500"
          style={{
            width: 80, height: 80,
            background: phase >= 2 ? "rgba(255,255,255,0.1)" : "#EAF2FF",
            boxShadow: phase >= 1 ? "0 0 0 16px rgba(37,99,235,0.12)" : "none",
          }}
        >
          <Logo size={48} white={phase >= 2} />
        </div>
        <div className="text-center" style={{ opacity: phase >= 1 ? 1 : 0, transition: "opacity 0.5s" }}>
          <p
            className="text-lg font-bold tracking-wide"
            style={{ color: phase >= 2 ? "#fff" : "#146EF5" }}
          >
            SkillBridgeAI
          </p>
          <p
            className="text-xs mt-1"
            style={{ color: phase >= 2 ? "rgba(255,255,255,0.5)" : "#64748B" }}
          >
            From Confusion to Career Clarity
          </p>
        </div>
      </div>
    </div>
  );
}

const SLIDES = [
  {
    title: "Understand\nYourself",
    body: "SkillBridgeAI assesses your strengths, interests and thinking style to build a complete picture of who you are.",
    illustration: () => (
      <svg viewBox="0 0 280 200" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full max-w-[280px]">
        <ellipse cx="140" cy="175" rx="90" ry="14" fill="#EAF2FF" />
        {/* Desk */}
        <rect x="60" y="120" width="160" height="8" rx="4" fill="#CBD5E1" />
        <rect x="75" y="128" width="8" height="40" rx="4" fill="#CBD5E1" />
        <rect x="197" y="128" width="8" height="40" rx="4" fill="#CBD5E1" />
        {/* Monitor */}
        <rect x="95" y="60" width="90" height="62" rx="6" fill="#1E293B" />
        <rect x="99" y="64" width="82" height="50" rx="4" fill="#146EF5" />
        <rect x="130" y="122" width="20" height="6" rx="3" fill="#94A3B8" />
        {/* Screen content */}
        <rect x="106" y="70" width="30" height="4" rx="2" fill="rgba(255,255,255,0.5)" />
        <rect x="106" y="78" width="50" height="3" rx="1.5" fill="rgba(255,255,255,0.3)" />
        <rect x="106" y="83" width="40" height="3" rx="1.5" fill="rgba(255,255,255,0.3)" />
        {/* Chart bars on screen */}
        <rect x="106" y="92" width="8" height="16" rx="2" fill="#60A5FA" />
        <rect x="117" y="98" width="8" height="10" rx="2" fill="#34D399" />
        <rect x="128" y="88" width="8" height="20" rx="2" fill="#60A5FA" />
        <rect x="139" y="95" width="8" height="13" rx="2" fill="#34D399" />
        {/* Person */}
        <ellipse cx="85" cy="92" rx="12" ry="12" fill="#FBBF24" />
        <rect x="73" y="104" width="24" height="28" rx="6" fill="#146EF5" />
        <rect x="58" y="108" width="14" height="6" rx="3" fill="#146EF5" />
        <rect x="88" y="108" width="14" height="6" rx="3" fill="#146EF5" />
        <rect x="79" y="132" width="8" height="20" rx="4" fill="#0F3DBF" />
        <rect x="89" y="132" width="8" height="20" rx="4" fill="#0F3DBF" />
        {/* Floating icons */}
        <circle cx="195" cy="65" r="14" fill="#EAF2FF" />
        <text x="195" y="70" textAnchor="middle" fontSize="14">💡</text>
        <circle cx="215" cy="95" r="10" fill="#DCFCE7" />
        <text x="215" y="100" textAnchor="middle" fontSize="10">✓</text>
      </svg>
    ),
  },
  {
    title: "Discover Your\nDirection",
    body: "Our AI analyses your profile and recommends careers, skills and paths that genuinely fit your potential.",
    illustration: () => (
      <svg viewBox="0 0 280 200" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full max-w-[280px]">
        <ellipse cx="140" cy="178" rx="85" ry="12" fill="#EAF2FF" />
        {/* Bar chart */}
        <rect x="60" y="80" width="24" height="90" rx="6" fill="#BFDBFE" />
        <rect x="60" y="100" width="24" height="70" rx="6" fill="#146EF5" />
        <rect x="94" y="60" width="24" height="110" rx="6" fill="#BFDBFE" />
        <rect x="94" y="80" width="24" height="90" rx="6" fill="#146EF5" />
        <rect x="128" y="40" width="24" height="130" rx="6" fill="#BFDBFE" />
        <rect x="128" y="50" width="24" height="120" rx="6" fill="#146EF5" />
        <rect x="162" y="60" width="24" height="110" rx="6" fill="#BFDBFE" />
        <rect x="162" y="70" width="24" height="100" rx="6" fill="#146EF5" />
        <rect x="196" y="90" width="24" height="80" rx="6" fill="#BFDBFE" />
        <rect x="196" y="100" width="24" height="70" rx="6" fill="#146EF5" />
        {/* Up arrow */}
        <path d="M148 20 L160 38 L152 38 L152 56 L144 56 L144 38 L136 38 Z" fill="#10B981" />
        {/* Person on top */}
        <ellipse cx="218" cy="58" rx="12" ry="12" fill="#FBBF24" />
        <rect x="207" y="70" width="22" height="22" rx="6" fill="#146EF5" />
        <text x="218" y="80" textAnchor="middle" fontSize="10" fill="white">🌟</text>
      </svg>
    ),
  },
  {
    title: "Build Your\nPath",
    body: "Get a step-by-step personalized roadmap, skill gap analysis, and institution recommendations — all in one place.",
    illustration: () => (
      <svg viewBox="0 0 280 200" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full max-w-[280px]">
        <ellipse cx="140" cy="178" rx="85" ry="12" fill="#EAF2FF" />
        {/* Central figure */}
        <ellipse cx="140" cy="85" rx="14" ry="14" fill="#FBBF24" />
        <rect x="126" y="99" width="28" height="32" rx="8" fill="#146EF5" />
        <rect x="110" y="104" width="15" height="7" rx="3.5" fill="#146EF5" />
        <rect x="155" y="104" width="15" height="7" rx="3.5" fill="#146EF5" />
        <rect x="130" y="131" width="9" height="22" rx="4" fill="#0F3DBF" />
        <rect x="141" y="131" width="9" height="22" rx="4" fill="#0F3DBF" />
        {/* Left figure */}
        <ellipse cx="78" cy="100" rx="11" ry="11" fill="#FCA5A5" />
        <rect x="67" y="111" width="22" height="26" rx="6" fill="#7C3AED" />
        {/* Right figure */}
        <ellipse cx="202" cy="100" rx="11" ry="11" fill="#6EE7B7" />
        <rect x="191" y="111" width="22" height="26" rx="6" fill="#059669" />
        {/* Connection lines */}
        <line x1="95" y1="110" x2="126" y2="110" stroke="#146EF5" strokeWidth="2" strokeDasharray="4 3" />
        <line x1="191" y1="110" x2="154" y2="110" stroke="#146EF5" strokeWidth="2" strokeDasharray="4 3" />
        {/* Stars */}
        <text x="50" y="75" fontSize="16">⭐</text>
        <text x="215" y="75" fontSize="16">⭐</text>
        <text x="130" y="50" fontSize="16">🎯</text>
        {/* Board */}
        <rect x="95" y="40" width="90" height="35" rx="6" fill="#1E293B" />
        <rect x="99" y="44" width="82" height="27" rx="4" fill="#0F172A" />
        <rect x="104" y="49" width="40" height="4" rx="2" fill="#146EF5" />
        <rect x="104" y="55" width="60" height="3" rx="1.5" fill="#334155" />
        <rect x="104" y="60" width="50" height="3" rx="1.5" fill="#334155" />
      </svg>
    ),
  },
];

interface WalkthroughProps {
  onGetStarted: () => void;
  isDark: boolean;
}

export function WalkthroughScreen({ onGetStarted, isDark }: WalkthroughProps) {
  const [slide, setSlide] = useState(0);
  const bg = isDark ? "#111827" : "#ffffff";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const textSub = isDark ? "#94A3B8" : "#64748B";

  const handleNext = () => {
    if (slide < 2) setSlide(slide + 1);
    else onGetStarted();
  };

  const Illustration = SLIDES[slide].illustration;

  return (
    <div className="flex-1 flex flex-col" style={{ background: bg }}>
      {/* Skip */}
      <div className="flex justify-end px-6 pt-5">
        <button
          className="text-sm font-medium"
          style={{ color: "#146EF5" }}
          onClick={onGetStarted}
        >
          SKIP
        </button>
      </div>

      {/* Illustration */}
      <div className="flex-1 flex items-center justify-center px-8 py-4">
        <div className="w-full flex justify-center">
          <Illustration />
        </div>
      </div>

      {/* Content */}
      <div className="px-8 pb-2">
        <h1
          className="text-2xl font-bold leading-tight mb-3 whitespace-pre-line"
          style={{ color: "#146EF5" }}
        >
          {SLIDES[slide].title}
        </h1>
        <p className="text-sm leading-relaxed" style={{ color: textSub }}>
          {SLIDES[slide].body}
        </p>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between px-8 py-6">
        <button className="text-sm font-medium" style={{ color: "#94A3B8" }} onClick={onGetStarted}>
          SKIP
        </button>

        {/* Dots */}
        <div className="flex gap-2 items-center">
          {SLIDES.map((_, i) => (
            <button
              key={i}
              onClick={() => setSlide(i)}
              className="transition-all duration-300 rounded-full"
              style={{
                width: i === slide ? 20 : 8,
                height: 8,
                background: i === slide ? "#146EF5" : "#CBD5E1",
              }}
            />
          ))}
        </div>

        {slide < 2 ? (
          <button
            className="text-sm font-bold"
            style={{ color: "#146EF5" }}
            onClick={handleNext}
          >
            NEXT
          </button>
        ) : (
          <button
            className="px-5 py-2.5 rounded-full text-sm font-bold text-white"
            style={{ background: "#146EF5" }}
            onClick={onGetStarted}
          >
            GET STARTED
          </button>
        )}
      </div>
    </div>
  );
}
