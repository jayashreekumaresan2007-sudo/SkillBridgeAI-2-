import { useState } from "react";
import Logo from "../components/Logo";
import { LANGUAGES, USER_CATEGORIES, AVATAR_GROUPS, PATHS } from "../data";

interface ScreenProps {
  isDark: boolean;
  onNext: (data: any) => void;
  onBack: () => void;
}

// ─── Language + User Category ─────────────────────────────────────
export function LanguageCategoryScreen({ isDark, onNext, onBack }: ScreenProps) {
  const [language, setLanguage] = useState("English");
  const [category, setCategory] = useState("");

  const bg = isDark ? "#111827" : "#ffffff";
  const surface = isDark ? "#1E293B" : "#F5F9FF";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const border = isDark ? "#334155" : "#E2E8F0";

  const selBg = "#146EF5";
  const selText = "#ffffff";

  return (
    <div className="flex-1 flex flex-col overflow-y-auto scrollbar-hide" style={{ background: bg }}>
      {/* Header */}
      <div className="px-5 pt-6 pb-2 flex items-center gap-3">
        <Logo size={32} white={isDark} />
        <div className="ml-auto" />
        <div className="flex flex-col">
          <svg width="80" height="60" viewBox="0 0 80 60" fill="none">
            <ellipse cx="40" cy="50" rx="32" ry="8" fill="#EAF2FF" />
            <circle cx="20" cy="22" r="10" fill="#FBBF24" />
            <circle cx="40" cy="18" r="12" fill="#FCA5A5" />
            <circle cx="62" cy="22" r="10" fill="#6EE7B7" />
            <rect x="12" y="32" width="16" height="14" rx="4" fill="#146EF5" />
            <rect x="32" y="30" width="16" height="16" rx="4" fill="#7C3AED" />
            <rect x="54" y="32" width="16" height="14" rx="4" fill="#059669" />
            {/* Speech bubbles */}
            <path d="M15 16 L15 10 L28 10 L28 16 L22 16 L20 19 L18 16 Z" fill="#EAF2FF" stroke="#CBD5E1" strokeWidth="0.5" />
            <path d="M52 14 L52 8 L65 8 L65 14 L59 14 L62 17 L57 14 Z" fill="#EAF2FF" stroke="#CBD5E1" strokeWidth="0.5" />
          </svg>
        </div>
      </div>

      <div className="px-5 flex-1">
        {/* Language */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-3">
            <span className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold">1</span>
            <div>
              <p className="text-sm font-bold" style={{ color: textMain }}>Choose your Language</p>
              <p className="text-xs" style={{ color: isDark ? "#94A3B8" : "#64748B" }}>Select the language you want to use</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2.5">
            {LANGUAGES.map((lang) => (
              <button
                key={lang}
                className="py-3 rounded-xl border text-sm font-semibold transition-all duration-200 active:scale-95"
                style={{
                  background: language === lang ? selBg : surface,
                  color: language === lang ? selText : textMain,
                  borderColor: language === lang ? selBg : border,
                }}
                onClick={() => setLanguage(lang)}
              >
                {lang}
              </button>
            ))}
          </div>
        </div>

        {/* Category */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-3">
            <span className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold">2</span>
            <div>
              <p className="text-sm font-bold" style={{ color: textMain }}>What describes you best?</p>
              <p className="text-xs" style={{ color: isDark ? "#94A3B8" : "#64748B" }}>This helps us personalise your experience</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2.5">
            {USER_CATEGORIES.filter((c) => c.id !== "other").map((cat) => (
              <button
                key={cat.id}
                className="flex flex-col items-center gap-1.5 py-4 rounded-xl border transition-all duration-200 active:scale-95 relative"
                style={{
                  background: category === cat.id ? "#EAF2FF" : surface,
                  borderColor: category === cat.id ? "#146EF5" : border,
                }}
                onClick={() => setCategory(cat.id)}
              >
                {category === cat.id && (
                  <span className="absolute top-2 right-2 w-4 h-4 rounded-full bg-blue-600 flex items-center justify-center">
                    <span className="text-white text-[8px]">✓</span>
                  </span>
                )}
                <span className="text-2xl">{cat.emoji}</span>
                <span className="text-xs font-semibold text-center leading-tight" style={{ color: textMain }}>
                  {cat.label}
                </span>
              </button>
            ))}
          </div>
          <button
            className="w-full mt-2.5 py-3 rounded-xl border text-sm font-semibold transition-all duration-200 active:scale-95"
            style={{
              background: category === "other" ? selBg : surface,
              color: category === "other" ? selText : textMain,
              borderColor: category === "other" ? selBg : border,
            }}
            onClick={() => setCategory("other")}
          >
            Other
          </button>
        </div>
      </div>

      <div className="px-5 pb-8">
        <button
          className="w-full py-4 rounded-2xl text-white font-bold text-base transition-all duration-200 active:scale-95 disabled:opacity-40"
          style={{ background: "#146EF5" }}
          disabled={!category}
          onClick={() => onNext({ language, category })}
        >
          Continue
        </button>
      </div>
    </div>
  );
}

// ─── Gender Selection ─────────────────────────────────────────────
export function GenderSelectScreen({ isDark, onNext, onBack }: ScreenProps) {
  const [gender, setGender] = useState<"male" | "female" | "">("");

  const bg = isDark ? "#111827" : "#ffffff";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const textMuted = isDark ? "#94A3B8" : "#64748B";

  return (
    <div className="flex-1 flex flex-col" style={{ background: bg }}>
      <div className="px-5 pt-5">
        <button onClick={onBack} className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: isDark ? "#1E293B" : "#F1F5F9" }}>
          <span style={{ color: textMain }}>←</span>
        </button>
      </div>

      <div className="flex-1 flex flex-col items-center px-6 pt-4">
        {/* Avatar icon */}
        <div className="w-16 h-16 rounded-2xl bg-blue-100 flex items-center justify-center text-3xl mb-5">
          👥
        </div>
        <h1 className="text-xl font-bold mb-1 text-center" style={{ color: textMain }}>
          Let's get to know you
        </h1>
        <p className="text-sm text-center mb-8" style={{ color: textMuted }}>
          This helps us personalise your experience better
        </p>
        <p className="text-lg font-bold mb-6" style={{ color: textMain }}>What's your gender?</p>

        <div className="flex gap-4 w-full">
          {(["male", "female"] as const).map((g) => (
            <button
              key={g}
              className="flex-1 flex flex-col items-center gap-3 py-6 rounded-2xl border-2 transition-all duration-200 active:scale-95"
              style={{
                borderColor: gender === g ? "#146EF5" : isDark ? "#334155" : "#E2E8F0",
                background: gender === g ? "#EAF2FF" : isDark ? "#1E293B" : "#F5F9FF",
              }}
              onClick={() => setGender(g)}
            >
              <span className="text-5xl">{g === "male" ? "👨" : "👩"}</span>
              <span className="text-sm font-semibold capitalize" style={{ color: textMain }}>{g}</span>
            </button>
          ))}
        </div>

        <div className="mt-auto mb-8 w-full">
          <div className="flex items-center gap-2.5 px-4 py-3 rounded-xl mt-8" style={{ background: isDark ? "#1E293B" : "#EAF2FF" }}>
            <span>🛡️</span>
            <div>
              <p className="text-xs font-semibold" style={{ color: textMain }}>We respect your privacy.</p>
              <p className="text-xs" style={{ color: textMuted }}>You can change this later in settings</p>
            </div>
          </div>
          <button
            className="w-full py-4 rounded-2xl text-white font-bold text-base mt-4 transition-all duration-200 active:scale-95 disabled:opacity-40"
            style={{ background: "#146EF5" }}
            disabled={!gender}
            onClick={() => onNext({ gender })}
          >
            Continue
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Avatar Selection ─────────────────────────────────────────────
interface AvatarSelectProps {
  isDark: boolean;
  gender: string;
  onNext: (data: any) => void;
  onBack: () => void;
}

export function AvatarSelectScreen({ isDark, gender, onNext, onBack }: AvatarSelectProps) {
  const avatarGroup = gender === "female" ? AVATAR_GROUPS.female : AVATAR_GROUPS.male;
  const [selected, setSelected] = useState(avatarGroup[0].id);
  const selectedAvatar = avatarGroup.find((a) => a.id === selected) ?? avatarGroup[0];

  const bg = isDark ? "#111827" : "#ffffff";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const textMuted = isDark ? "#94A3B8" : "#64748B";

  return (
    <div className="flex-1 flex flex-col" style={{ background: bg }}>
      <div className="px-5 pt-5">
        <button onClick={onBack} className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: isDark ? "#1E293B" : "#F1F5F9" }}>
          <span style={{ color: textMain }}>←</span>
        </button>
      </div>

      <div className="px-6 pt-4 flex flex-col items-center flex-1">
        <h1 className="text-xl font-bold mb-6" style={{ color: textMain }}>Choose your avatar</h1>

        {/* Featured avatar */}
        <div className="relative mb-6">
          <div
            className="w-32 h-32 rounded-full flex items-center justify-center text-7xl transition-all duration-300"
            style={{ background: selectedAvatar.bg }}
          >
            {selectedAvatar.emoji}
          </div>
          {/* Decorative dots */}
          <div className="absolute -top-2 -left-4 grid grid-cols-3 gap-1">
            {Array.from({ length: 9 }).map((_, i) => (
              <div key={i} className="w-1.5 h-1.5 rounded-full bg-blue-200" />
            ))}
          </div>
          <div className="absolute -top-1 -right-2">
            <span className="text-2xl">✨</span>
          </div>
        </div>

        <p className="text-sm mb-4" style={{ color: textMuted }}>Select your avatar</p>

        {/* Avatar grid */}
        <div className="grid grid-cols-3 gap-3 w-full">
          {avatarGroup.map((avatar) => (
            <button
              key={avatar.id}
              className="flex items-center justify-center py-3 rounded-2xl border-2 text-3xl transition-all duration-200 active:scale-95"
              style={{
                borderColor: selected === avatar.id ? "#146EF5" : isDark ? "#334155" : "#E2E8F0",
                background: selected === avatar.id ? "#EAF2FF" : avatar.bg,
              }}
              onClick={() => setSelected(avatar.id)}
            >
              {avatar.emoji}
            </button>
          ))}
        </div>

        <div className="mt-auto w-full pb-8 pt-4">
          <button
            className="w-full py-4 rounded-2xl text-white font-bold text-base transition-all duration-200 active:scale-95"
            style={{ background: "#146EF5" }}
            onClick={() => onNext({ avatar: selected })}
          >
            Continue
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Path Selection ────────────────────────────────────────────────
export function PathSelectScreen({ isDark, onNext, onBack }: ScreenProps) {
  const [selected, setSelected] = useState("");

  const bg = isDark ? "#111827" : "#ffffff";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const textMuted = isDark ? "#94A3B8" : "#64748B";
  const surface = isDark ? "#1E293B" : "#F5F9FF";
  const border = isDark ? "#334155" : "#E2E8F0";

  return (
    <div className="flex-1 flex flex-col" style={{ background: bg }}>
      <div className="px-5 pt-5">
        <button onClick={onBack} className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: isDark ? "#1E293B" : "#F1F5F9" }}>
          <span style={{ color: textMain }}>←</span>
        </button>
      </div>

      <div className="px-6 pt-4 flex-1 flex flex-col">
        <div className="flex items-start justify-between mb-6">
          <h1 className="text-2xl font-bold" style={{ color: textMain }}>
            What do you need<br />
            <span style={{ color: "#146EF5" }}>help</span> with?
          </h1>
          <div className="text-4xl">🤔</div>
        </div>

        <div className="space-y-3 flex-1">
          {PATHS.map((path) => (
            <button
              key={path.id}
              className="w-full flex items-center gap-4 px-4 py-4 rounded-2xl border-2 transition-all duration-200 active:scale-[0.98] text-left"
              style={{
                borderColor: selected === path.id ? "#146EF5" : border,
                background: selected === path.id ? "#EAF2FF" : surface,
              }}
              onClick={() => setSelected(path.id)}
            >
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center text-xl shrink-0"
                style={{ background: selected === path.id ? "#146EF5" : isDark ? "#334155" : "#E2E8F0" }}
              >
                {path.icon}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold" style={{ color: textMain }}>{path.title}</p>
                <p className="text-xs mt-0.5" style={{ color: textMuted }}>{path.desc}</p>
              </div>
              <div
                className="w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 transition-all"
                style={{
                  borderColor: selected === path.id ? "#146EF5" : isDark ? "#475569" : "#CBD5E1",
                  background: selected === path.id ? "#146EF5" : "transparent",
                }}
              >
                {selected === path.id && <span className="text-white text-[8px]">✓</span>}
              </div>
            </button>
          ))}
        </div>

        {/* Privacy note */}
        <div className="flex items-start gap-3 px-4 py-3 rounded-xl mt-4" style={{ background: isDark ? "#1E293B" : "#EAF2FF" }}>
          <span className="text-xl shrink-0">🛡️</span>
          <div>
            <p className="text-xs font-bold" style={{ color: textMain }}>Your data is safe with us</p>
            <p className="text-xs mt-0.5" style={{ color: textMuted }}>Your responses are private and used only to personalise your journey.</p>
          </div>
        </div>

        <div className="pb-8 pt-4">
          <button
            className="w-full py-4 rounded-2xl text-white font-bold text-base transition-all duration-200 active:scale-95 disabled:opacity-40"
            style={{ background: "#146EF5" }}
            disabled={!selected}
            onClick={() => onNext({ path: selected })}
          >
            Get Started
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Assessment Intro ──────────────────────────────────────────────
export function AssessmentIntroScreen({ isDark, onNext, onBack }: ScreenProps) {
  const bg = isDark ? "#111827" : "#ffffff";
  const textMain = isDark ? "#F1F5F9" : "#0F172A";
  const textMuted = isDark ? "#94A3B8" : "#64748B";
  const surface = isDark ? "#1E293B" : "#F5F9FF";

  const types = [
    { icon: "🎭", label: "Scenario Based", desc: "Real-life situations to understand how you think and make decisions", color: "#EAF2FF", iconBg: "#DBEAFE" },
    { icon: "⭐", label: "Rate Yourself", desc: "Rate your strengths, interests and preferences", color: "#ECFDF5", iconBg: "#D1FAE5" },
    { icon: "❓", label: "Questions", desc: "A series of questions to evaluate your knowledge and mindset", color: "#FFFBEB", iconBg: "#FEF3C7" },
  ];

  return (
    <div className="flex-1 flex flex-col" style={{ background: bg }}>
      <div className="px-5 pt-5">
        <button onClick={onBack} className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: isDark ? "#1E293B" : "#F1F5F9" }}>
          <span style={{ color: textMain }}>←</span>
        </button>
      </div>

      <div className="px-6 flex-1 flex flex-col">
        <div className="flex items-start justify-between mb-4 mt-2">
          <div>
            <h1 className="text-2xl font-bold" style={{ color: textMain }}>
              Your Assessment{" "}
              <span style={{ color: "#146EF5" }}>Journey</span>
            </h1>
            <p className="text-sm mt-2 leading-relaxed" style={{ color: textMuted }}>
              This assessment is designed to understand you better and suggest what's right for you.
            </p>
          </div>
          <div className="ml-2 shrink-0">
            <svg width="80" height="65" viewBox="0 0 80 65" fill="none">
              <rect x="5" y="5" width="50" height="35" rx="5" fill="#DBEAFE" />
              <rect x="8" y="8" width="44" height="29" rx="4" fill="#EAF2FF" />
              <rect x="12" y="12" width="20" height="3" rx="1.5" fill="#146EF5" />
              <rect x="12" y="17" width="32" height="2" rx="1" fill="#CBD5E1" />
              <rect x="12" y="21" width="26" height="2" rx="1" fill="#CBD5E1" />
              <rect x="12" y="25" width="28" height="2" rx="1" fill="#CBD5E1" />
              <circle cx="60" cy="45" r="16" fill="#EAF2FF" stroke="#146EF5" strokeWidth="2" />
              <path d="M54 45 L59 50 L68 40" stroke="#146EF5" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M30 40 L40 55 L70 25" stroke="none" />
            </svg>
          </div>
        </div>

        <p className="text-xs font-semibold mb-3" style={{ color: textMuted }}>Your assessment includes</p>

        <div className="space-y-3 flex-1">
          {types.map((t) => (
            <div
              key={t.label}
              className="flex items-center gap-4 px-4 py-4 rounded-2xl"
              style={{ background: isDark ? surface : t.color }}
            >
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center text-xl shrink-0"
                style={{ background: isDark ? "#334155" : t.iconBg }}
              >
                {t.icon}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold" style={{ color: textMain }}>{t.label}</p>
                <p className="text-xs mt-0.5 leading-relaxed" style={{ color: textMuted }}>{t.desc}</p>
              </div>
              <span style={{ color: textMuted }}>›</span>
            </div>
          ))}
        </div>

        {/* Disclaimer */}
        <div className="flex items-start gap-3 px-4 py-3 rounded-xl mt-4" style={{ background: isDark ? "#1E293B" : "#EAF2FF" }}>
          <span>✅</span>
          <div>
            <p className="text-xs font-bold" style={{ color: textMain }}>No right or wrong answers</p>
            <p className="text-xs mt-0.5" style={{ color: textMuted }}>
              Be honest and take your time. It helps us give you accurate results.
            </p>
          </div>
        </div>

        <div className="pb-8 pt-4">
          <button
            className="w-full py-4 rounded-2xl text-white font-bold text-base transition-all duration-200 active:scale-95"
            style={{ background: "#146EF5" }}
            onClick={() => onNext({})}
          >
            Start Assessment
          </button>
        </div>
      </div>
    </div>
  );
}
